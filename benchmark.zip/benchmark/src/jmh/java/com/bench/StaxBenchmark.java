package com.bench;

import com.bench.stax.*;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;
import org.openjdk.jmh.infra.BenchmarkParams;

import java.io.IOException;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

/**
 * B3 (XML bytes -> POJO), B6 (POJO -> XML bytes) and a combined round trip, for each of the 4
 * message types at each of the 5 sample sizes. All sample XMLs are loaded into memory in
 * @Setup (not timed); for B6 the POJO is also pre-built in @Setup so only writing is timed.
 *
 * <p>GC is reported two ways: JMH's own {@code -prof gc} (which itself reads
 * {@code GarbageCollectorMXBean} / {@code MemoryPoolMXBean} deltas around each measurement
 * iteration -- the standard, authoritative source), and a supplementary manual
 * {@code GarbageCollectorMXBean} delta captured in {@code @Setup}/{@code @TearDown(Level.Iteration)}
 * and appended to {@code results/gc_manual.csv}, for transparency and as a fallback when
 * {@code -prof gc} isn't used. Both are JVM-fork-level counters: they include any GC activity
 * from JIT warmup, JMH's own bookkeeping, or other code running in that same fork, not only the
 * benchmarked method -- they are not forced inside timed methods and are not claimed to be
 * attributable exclusively to one operation.</p>
 */
@State(Scope.Benchmark)
@BenchmarkMode({Mode.AverageTime, Mode.Throughput})
@OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(iterations = 5)
@Measurement(iterations = 5)
@Fork(2)
public class StaxBenchmark {

    @Param({"capa_seev035", "capa_supl009", "caco_seev036", "caco_supl011"})
    public String type;

    @Param({"small", "medium", "large", "xlarge", "xxl"})
    public String size;

    private Function<byte[], Object> reader;
    private Function<Object, byte[]> writer;
    private byte[] xmlBytes;
    private Object prebuiltPojo;

    private static final Map<String, Function<byte[], Object>> READERS = Map.of(
            "capa_seev035", bytes -> unchecked(() -> CapaSeev035StaxReader.read(bytes)),
            "capa_supl009", bytes -> unchecked(() -> CapaSupl009StaxReader.read(bytes)),
            "caco_seev036", bytes -> unchecked(() -> CacoSeev036StaxReader.read(bytes)),
            "caco_supl011", bytes -> unchecked(() -> CacoSupl011StaxReader.read(bytes))
    );

    private static final Map<String, Function<Object, byte[]>> WRITERS = Map.of(
            "capa_seev035", obj -> unchecked(() -> CapaSeev035StaxWriter.write((com.bench.capa.seev035.Document) obj)),
            "capa_supl009", obj -> unchecked(() -> CapaSupl009StaxWriter.write((com.bench.capa.supl009.Document) obj)),
            "caco_seev036", obj -> unchecked(() -> CacoSeev036StaxWriter.write((com.bench.caco.seev036.Document) obj)),
            "caco_supl011", obj -> unchecked(() -> CacoSupl011StaxWriter.write((com.bench.caco.supl011.Document) obj))
    );

    @Setup(Level.Trial)
    public void setup() throws IOException {
        reader = READERS.get(type);
        writer = WRITERS.get(type);
        Path file = Path.of("samples", type, size, "sample_1.xml");
        xmlBytes = Files.readAllBytes(file);
        prebuiltPojo = reader.apply(xmlBytes);
    }

    // --- Supplementary manual GC delta, captured around each iteration (warmup + measurement) ---

    private static final List<GarbageCollectorMXBean> GC_BEANS = ManagementFactory.getGarbageCollectorMXBeans();
    private static final Object GC_CSV_LOCK = new Object();

    private long gcCountAtIterationStart;
    private long gcTimeAtIterationStart;

    @Setup(Level.Iteration)
    public void setupIteration() {
        gcCountAtIterationStart = totalGcCount();
        gcTimeAtIterationStart = totalGcTimeMs();
    }

    @TearDown(Level.Iteration)
    public void teardownIteration(BenchmarkParams params) throws IOException {
        long countDelta = totalGcCount() - gcCountAtIterationStart;
        long timeDelta = totalGcTimeMs() - gcTimeAtIterationStart;
        appendGcRecord(params.getBenchmark(), type, size, countDelta, timeDelta);
    }

    private static long totalGcCount() {
        long sum = 0;
        for (GarbageCollectorMXBean bean : GC_BEANS) {
            long c = bean.getCollectionCount();
            if (c >= 0) sum += c;
        }
        return sum;
    }

    private static long totalGcTimeMs() {
        long sum = 0;
        for (GarbageCollectorMXBean bean : GC_BEANS) {
            long t = bean.getCollectionTime();
            if (t >= 0) sum += t;
        }
        return sum;
    }

    private static void appendGcRecord(String benchmark, String type, String size, long gcCountDelta, long gcTimeMsDelta)
            throws IOException {
        synchronized (GC_CSV_LOCK) {
            Path path = Path.of("results", "gc_manual.csv");
            Files.createDirectories(path.getParent());
            boolean isNew = !Files.exists(path);
            try (var w = Files.newBufferedWriter(path, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                if (isNew) {
                    w.write("benchmark,type,size,gcCountDelta,gcTimeMsDelta\n");
                }
                w.write(benchmark + "," + type + "," + size + "," + gcCountDelta + "," + gcTimeMsDelta + "\n");
            }
        }
    }

    @Benchmark
    public void b3_xmlToPojo(Blackhole bh) {
        bh.consume(reader.apply(xmlBytes));
    }

    @Benchmark
    public void b6_pojoToXml(Blackhole bh) {
        bh.consume(writer.apply(prebuiltPojo));
    }

    @Benchmark
    public void roundTrip(Blackhole bh) {
        Object pojo = reader.apply(xmlBytes);
        bh.consume(writer.apply(pojo));
    }

    private interface ThrowingSupplier<T> {
        T get() throws Exception;
    }

    private static <T> T unchecked(ThrowingSupplier<T> supplier) {
        try {
            return supplier.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
