# What This Project Does (Explained Simply)

This project answers one question:

**"How fast can a computer read an XML file into Java objects, and write Java objects back into an XML file?"**

That's it. Everything else in this project exists just to test that, fairly and honestly.

---

## 1. The basic building blocks (explained like you're new to this)

### What is XML?
XML is just text that stores data with labels, like a filled-in form.

```xml
<Payment>
  <Amount>100.50</Amount>
  <Currency>USD</Currency>
</Payment>
```

This says: "there is a Payment, its Amount is 100.50, its Currency is USD."

### What is an XSD?
An XSD is the **rulebook** for an XML file. It says things like:
- "Amount must be a number."
- "Currency must be exactly 3 letters."
- "You must always include a Payment, but the Comment is optional."

Think of it like a form template that says which boxes are required and what kind of answer goes in each box.

This project has **4 XSD rulebooks** (4 kinds of forms), because it's testing 4 real-world financial messages used by banks (things like "a payment confirmation" and "a payment preview").

### What is a POJO?
POJO means "Plain Old Java Object." It's just a simple Java box that holds data in memory.

If the XML says `<Amount>100.50</Amount>`, the matching Java box (POJO) has a field like:
```java
BigDecimal amount = 100.50;
```

So: **XML is the text version. POJO is the "in Java's memory" version.** They hold the same information, just in different shapes.

### What is xjc?
`xjc` is a tool that **reads an XSD rulebook and auto-generates the Java boxes (POJOs) for you**, so you don't have to type them by hand. This project has 4 XSDs, so xjc created 4 sets of Java boxes — about 280 Java classes in total.

### What does "read XML into a POJO" mean?
It means: take the text file, understand it, and fill in the matching Java boxes with the right values.

### What does "write a POJO into XML" mean?
It's the reverse: take the filled-in Java boxes, and write out the matching text file.

### What is StAX?
StAX is a way of reading/writing XML **one little piece at a time**, like reading a book one word at a time with your finger, instead of photographing the whole page at once.

This matters for big files: if a file is 10 MB, you don't want to load the *whole* thing into memory as one blob before you even start — StAX lets you process it piece by piece, which uses less memory.

There's another common way to handle XML called JAXB, which can automatically read/write XML using "reflection" (a slower, more automatic, more magical approach). This project deliberately does **not** use that for the actual speed test — it uses **hand-style StAX code** instead, because hand-written code is usually faster. (More on how that code was created, below.)

---

## 2. What was actually built, step by step

### Step 1 — Turn the 4 rulebooks (XSDs) into Java boxes (POJOs)
Using `xjc`, automatically, at build time. No one typed these 280 classes by hand.

### Step 2 — Create fake-but-realistic sample XML files to test with
We didn't have any real XML files lying around, so a small program was written that:
- Reads each XSD rulebook.
- Makes up realistic-looking data that **obeys every rule** in that rulebook (right date formats, real currency codes like USD/EUR, valid ID patterns, etc.) — not just random junk.
- Saves the result as an XML file.
- Double-checks the XML file actually follows the rulebook (this is called "validation").

This was done for **5 different file sizes** (tiny ~10 KB, medium ~100 KB, big ~1 MB, bigger ~5 MB, huge ~10 MB), 4 message types, 5 copies of each = **100 sample XML files total.**

> Fun fact: making a file hit an exact target size (like "exactly 5 MB") is harder than it sounds, because XML files have lists inside lists inside lists, and each list can repeat. The first version of this size-control logic actually ran out of computer memory trying to build a 5 MB file, because it guessed the wrong repeat count and the file size exploded way past what was asked. This got fixed by having the program "learn" from 2 small test attempts first (figure out the real growth pattern), instead of blindly guessing.

### Step 3 & 4 — Write the actual "reader" and "writer" code
This is the important part: the code that actually converts **XML → Java boxes** (the reader) and **Java boxes → XML** (the writer), using StAX, by hand style, with no shortcuts (no reflection, no auto-magic tools) in the part that gets timed.

Writing this by hand for 280 Java classes would take forever and be very error-prone. So instead, a **one-time helper tool** was built that:
- Looks at the already-generated Java boxes (from Step 1).
- Figures out, automatically, what each box's fields are called and what type they are.
- Writes out plain, ordinary-looking Java code that reads/writes each box, field by field.

This helper tool is only used **once**, like a one-time favor, to save a huge amount of typing. The actual code it produces — the code that gets *timed* in the speed test — is plain, boring, hand-style Java. No shortcuts are used while the clock is running.

### Correctness check (very important — never skip this!)
Before trusting any speed numbers, we have to make sure the reading/writing code is actually **correct**. So for every one of the 100 sample files, we do:

1. Read the XML into Java boxes.
2. Write those boxes back out to XML.
3. Check: does this new XML still follow the rulebook? (validate again)
4. Read that new XML into Java boxes again (a second time).
5. Compare: do the "first time" boxes and the "second time" boxes contain exactly the same data?

If all 5 steps succeed for all 100 files, we know the reader and writer are trustworthy. **All 100 passed.**

### Step 5 — The actual speed test (benchmarking)
This uses a tool called **JMH** (Java Microbenchmark Harness) — basically a very careful stopwatch for code, built specifically because a normal stopwatch would give you wrong/misleading numbers for things this fast.

Why not just use `System.currentTimeMillis()` yourself? Because:
- The first few times code runs, Java is still "warming up" (compiling itself to be faster) — timing that gives you a lie.
- A smart compiler might notice "this result is never used" and skip the work entirely, making it look impossibly fast.

JMH handles both problems automatically. It runs the code many times, throws away the "still warming up" runs, and makes sure results are actually used (via something literally called a "Blackhole" — you feed it the result so nothing gets thrown away early).

Three things get timed:
1. **Reading** XML into Java boxes.
2. **Writing** Java boxes into XML.
3. **Both together** (read then write).

...for each of the 4 message types, at each of the 5 sizes. That's 20 combinations, times 3 timed things = 60 separate speed tests.

### What gets measured
- **Average time** — how many microseconds does one read (or write) take, on average?
- **Throughput** — how many messages per second can we process?
- **Memory garbage created** — processing XML creates lots of small temporary Java objects that need cleanup later. We measure how much "trash" gets created per message.
- **Garbage collection (GC) count & time** — Java has a built-in "cleaning crew" (the Garbage Collector) that automatically cleans up memory you're no longer using. We count how often the cleaning crew had to run, and how long cleaning took. (If cleaning runs a lot, that can slow things down.)
- **Peak memory (heap) usage** — if you process 10,000 messages back-to-back, what's the most memory that was ever in use at one time?
- **File sizes** — how big is the XML text file, versus how big is the same data once it's sitting in Java's memory as objects? (Usually bigger in memory than as compressed text.)

### Turning numbers into a readable report
All these measurements get saved as computer-readable files (JSON/CSV). A small script then reads all of that and prints out neat, simple tables — so a human doesn't have to dig through raw data files.

---

## 3. Why this is trustworthy (not just made-up numbers)

- Every sample XML file is checked against its rulebook (XSD) — twice.
- Every read/write round-trip is checked for exact data match.
- The reading/writing code itself never uses the JAXB automatic-magic tool, and never uses reflection — only plain, hand-style code, matching what a careful human engineer would write.
- The timing uses JMH, the standard professional tool for this exact job, not a hand-rolled stopwatch.
- The memory-cleanup (GC) numbers are measured **two separate ways** that agree with each other, for extra confidence.
- Nothing is estimated or guessed — every number in the report comes from an actual run that really happened on this machine.

---

## 4. One-sentence summary of every file

| File | One-sentence job |
|---|---|
| `xsd/*.xsd` | The 4 rulebooks for the 4 message types. |
| `com.bench.generator` | Makes 100 realistic, rule-following sample XML files. |
| `com.bench.codegen.StaxCodeGenerator` | A one-time helper that writes the reader/writer code for us, so we don't type 280 classes by hand. |
| `com.bench.stax.*` | The actual hand-style reader & writer code that gets speed-tested. |
| `com.bench.check.RoundTripCheck` | Makes sure the reader/writer are correct before we trust any speed number. |
| `com.bench.load.SpaceReport` | Measures file size vs. in-memory size. |
| `com.bench.load.PeakHeapLoadTest` | Measures the most memory ever used while processing 10,000 messages. |
| `StaxBenchmark` (JMH) | The actual stopwatch test: how fast is reading, writing, and both together? |
| `scripts/summarize_results.py` | Turns raw measurement files into easy-to-read tables. |

---

## 5. The simplest possible one-paragraph version

We have 4 kinds of financial message "forms" (XSDs). We taught the computer to fill out 100 fake-but-valid sample forms. We wrote (mostly by having a helper tool write it for us) plain, careful Java code that can turn those forms into Java objects and back into forms, without using any slow automatic shortcuts. We checked, very carefully, that converting back and forth never loses or changes any data. Then we used a professional timing tool to measure exactly how fast all of this is, how much temporary memory garbage it creates, and how much memory it uses at its peak — and saved all of that into clear, simple tables.
