package com.bench.load;

import com.bench.stax.*;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Function;

/**
 * Processes 10,000 messages per type (read -> write round trip, using the "medium" sample) and
 * records peak heap usage via MemoryPoolMXBean. Run as its own JVM process per type/size if you
 * want a clean peak-usage baseline (this main processes all 4 types in one JVM run, each after
 * resetting the peak-usage counters).
 */
public final class PeakHeapLoadTest {

    private static final int MESSAGE_COUNT = 10_000;
    private static final String SIZE = "medium";

    private record TypeBinding(String typeKey, Function<byte[], Object> read, Function<Object, byte[]> write) {
    }

    private static final List<TypeBinding> BINDINGS = List.of(
            new TypeBinding("capa_seev035",
                    bytes -> unchecked(() -> CapaSeev035StaxReader.read(bytes)),
                    obj -> unchecked(() -> CapaSeev035StaxWriter.write((com.bench.capa.seev035.Document) obj))),
            new TypeBinding("capa_supl009",
                    bytes -> unchecked(() -> CapaSupl009StaxReader.read(bytes)),
                    obj -> unchecked(() -> CapaSupl009StaxWriter.write((com.bench.capa.supl009.Document) obj))),
            new TypeBinding("caco_seev036",
                    bytes -> unchecked(() -> CacoSeev036StaxReader.read(bytes)),
                    obj -> unchecked(() -> CacoSeev036StaxWriter.write((com.bench.caco.seev036.Document) obj))),
            new TypeBinding("caco_supl011",
                    bytes -> unchecked(() -> CacoSupl011StaxReader.read(bytes)),
                    obj -> unchecked(() -> CacoSupl011StaxWriter.write((com.bench.caco.supl011.Document) obj)))
    );

    public static void main(String[] args) throws Exception {
        StringBuilder json = new StringBuilder("[\n");
        boolean first = true;

        System.out.println("Type           Messages   PeakHeapMB");
        System.out.println("----           --------   ----------");

        for (TypeBinding binding : BINDINGS) {
            Path file = Path.of("samples", binding.typeKey(), SIZE, "sample_1.xml");
            byte[] xml = Files.readAllBytes(file);

            resetPeakUsage();
            System.gc();
            resetPeakUsage();

            for (int i = 0; i < MESSAGE_COUNT; i++) {
                Object pojo = binding.read().apply(xml);
                byte[] out = binding.write().apply(pojo);
                if (out.length == 0) {
                    throw new AssertionError("empty output");
                }
            }

            double peakMB = peakHeapUsedMB();
            System.out.printf("%-14s %-10d %-10.2f%n", binding.typeKey(), MESSAGE_COUNT, peakMB);

            if (!first) json.append(",\n");
            first = false;
            json.append(String.format(java.util.Locale.ROOT,
                    "  {\"type\": \"%s\", \"size\": \"%s\", \"messages\": %d, \"peakHeapMB\": %.3f}",
                    binding.typeKey(), SIZE, MESSAGE_COUNT, peakMB));
        }
        json.append("\n]\n");

        new java.io.File("results").mkdirs();
        Files.writeString(Path.of("results", "heap.json"), json.toString());
        System.out.println("\nWritten to results/heap.json");
    }

    private static void resetPeakUsage() {
        for (MemoryPoolMXBean pool : ManagementFactory.getMemoryPoolMXBeans()) {
            if (pool.getType() == MemoryType.HEAP) {
                pool.resetPeakUsage();
            }
        }
    }

    private static double peakHeapUsedMB() {
        long total = 0;
        for (MemoryPoolMXBean pool : ManagementFactory.getMemoryPoolMXBeans()) {
            if (pool.getType() == MemoryType.HEAP) {
                total += pool.getPeakUsage().getUsed();
            }
        }
        return total / (1024.0 * 1024.0);
    }

    private interface ThrowingSupplier<T> {
        T get() throws Exception;
    }

    private static <T> T unchecked(ThrowingSupplier<T> supplier) {
        try {
            return supplier.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
