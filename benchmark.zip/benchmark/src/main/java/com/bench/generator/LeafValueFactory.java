package com.bench.generator;

import com.sun.xml.xsom.XSFacet;
import com.sun.xml.xsom.XSSimpleType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

/**
 * Produces a single leaf text value (element text or attribute value) that is guaranteed to
 * satisfy the facets (enumeration, pattern, length, digits) of the given XSD simple type.
 */
final class LeafValueFactory {

    private static final String[] CURRENCIES = {"USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD"};
    private static final String[] COUNTRIES = {"US", "GB", "DE", "FR", "JP", "CA", "AU", "CH"};
    private static final String[] PERSON_NAMES = {
            "JOHN SMITH", "MARIA GARCIA", "WEI ZHANG", "EMMA JOHNSON", "LIAM BROWN", "OLIVIA DAVIES"
    };
    private static final String[] ORG_NAMES = {
            "GLOBAL CUSTODY BANK NA", "ACME CAPITAL LLC", "ATLAS SECURITIES SERVICES",
            "NORTHBRIDGE ASSET MANAGEMENT", "PACIFIC TRUST COMPANY", "DTCC SETTLEMENT SERVICES"
    };
    private static final String[] NARRATIVE_WORDS = {
            "DIVIDEND", "PAYMENT", "INTEREST", "REDEMPTION", "PROCEEDS", "ADJUSTMENT", "CASH",
            "DISTRIBUTION", "CORPORATE", "ACTION", "MOVEMENT", "CONFIRMATION", "PRINCIPAL",
            "WITHHOLDING", "TAX", "SETTLEMENT", "EVENT", "NOTICE", "ACCOUNT", "BALANCE",
            "POSITION", "SECURITY", "TRANSACTION", "ADVICE", "PRELIMINARY", "FINAL"
    };

    private LeafValueFactory() {
    }

    /** Placeholder text for xs:any wildcard content, which has no XSD-defined type to drive generation. */
    static String wildcardText(Random rnd) {
        return narrativeText(60, "info", rnd);
    }

    static String generate(XSSimpleType type, String nameHint, Random rnd) {
        List<XSFacet> enumFacets = type.getFacets(XSFacet.FACET_ENUMERATION);
        if (enumFacets != null && !enumFacets.isEmpty()) {
            return enumFacets.get(rnd.nextInt(enumFacets.size())).getValue().value;
        }

        XSFacet patternFacet = type.getFacet(XSFacet.FACET_PATTERN);
        if (patternFacet != null) {
            return fromPattern(patternFacet.getValue().value, type, nameHint, rnd);
        }

        XSSimpleType primitive = type.getPrimitiveType();
        String primitiveName = primitive != null ? primitive.getName() : null;
        if (primitiveName == null) {
            primitiveName = "string";
        }

        switch (primitiveName) {
            case "boolean":
                return rnd.nextBoolean() ? "true" : "false";
            case "date":
                return isoDate(rnd);
            case "dateTime":
                return isoDateTime(rnd);
            case "decimal":
            case "integer":
            case "nonNegativeInteger":
            case "positiveInteger":
                return decimalValue(type, nameHint, rnd);
            default:
                return stringValue(type, nameHint, rnd);
        }
    }

    private static String fromPattern(String pattern, XSSimpleType type, String nameHint, Random rnd) {
        switch (pattern) {
            case "([0-9a-zA-Z\\-\\?:\\(\\)\\.,'\\+ ]([0-9a-zA-Z\\-\\?:\\(\\)\\.,'\\+ ]*(/[0-9a-zA-Z\\-\\?:\\(\\)\\.,'\\+ ])?)*)": {
                Integer maxLen = facetInt(type, XSFacet.FACET_MAXLENGTH);
                return narrativeText(maxLen != null ? maxLen : 16, nameHint, rnd);
            }
            case "[A-Z]{3,3}":
                return CURRENCIES[rnd.nextInt(CURRENCIES.length)];
            case "[A-Z]{2,2}[A-Z0-9]{9,9}[0-9]{1,1}":
                return isin(rnd);
            case "XX|TS":
                return rnd.nextBoolean() ? "XX" : "TS";
            case "[0-9]{3}":
                return digits(3, 3, rnd);
            case "[0-9]{1,3}":
                return digits(1, 3, rnd);
            case "[0-9]{1,5}":
                return digits(1, 5, rnd);
            case "[0-9]{1,10}":
                return digits(1, 10, rnd);
            case "[a-zA-Z0-9]{4}":
                return alnumCode(4, 4, rnd);
            case "[a-zA-Z0-9]{1,4}":
                return alnumCode(1, 4, rnd);
            case "[a-zA-Z0-9]{32}":
                return alnumCode(32, 32, rnd);
            case "[0-9a-zA-Z/\\-\\?:\\(\\)\\.,'\\+ ]{1,31}":
                return narrativeText(31, nameHint, rnd);
            case "[0-9a-zA-Z/\\-\\?:\\(\\)\\.,'\\+ ]{1,35}":
                return narrativeText(35, nameHint, rnd);
            case "[0-9a-zA-Z/\\-\\?:\\(\\)\\.\\n\\r,'\\+ ]{1,140}":
                return narrativeText(140, nameHint, rnd);
            case "[0-9a-zA-Z/\\-\\?:\\(\\)\\.\\n\\r,'\\+ ]{1,350}":
                return narrativeText(350, nameHint, rnd);
            default:
                return genericFromPattern(pattern, rnd);
        }
    }

    /**
     * Very small fallback for any pattern not already special-cased above: handles a
     * concatenation of "[charclass]{m,n}" (or "{m}") groups, which covers every form actually
     * used across these 4 XSDs. Not a general regex generator.
     */
    private static String genericFromPattern(String pattern, Random rnd) {
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < pattern.length()) {
            if (pattern.charAt(i) == '[') {
                int close = pattern.indexOf(']', i);
                String charClass = pattern.substring(i + 1, close);
                int braceOpen = pattern.indexOf('{', close);
                int min = 1, max = 1;
                int next = close + 1;
                if (braceOpen == close + 1) {
                    int braceClose = pattern.indexOf('}', braceOpen);
                    String spec = pattern.substring(braceOpen + 1, braceClose);
                    String[] parts = spec.split(",");
                    min = Integer.parseInt(parts[0].trim());
                    max = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : min;
                    next = braceClose + 1;
                }
                int len = min + (max > min ? rnd.nextInt(max - min + 1) : 0);
                for (int k = 0; k < len; k++) {
                    out.append(randomFromCharClass(charClass, rnd));
                }
                i = next;
            } else {
                out.append(pattern.charAt(i));
                i++;
            }
        }
        return out.length() > 0 ? out.toString() : "A";
    }

    private static char randomFromCharClass(String charClass, Random rnd) {
        if (charClass.contains("A-Z") && rnd.nextBoolean()) {
            return (char) ('A' + rnd.nextInt(26));
        }
        if (charClass.contains("0-9")) {
            return (char) ('0' + rnd.nextInt(10));
        }
        return 'X';
    }

    private static String digits(int min, int max, Random rnd) {
        int len = min + (max > min ? rnd.nextInt(max - min + 1) : 0);
        StringBuilder sb = new StringBuilder();
        sb.append(1 + rnd.nextInt(9));
        for (int i = 1; i < len; i++) {
            sb.append(rnd.nextInt(10));
        }
        return sb.toString();
    }

    private static String alnumCode(int min, int max, Random rnd) {
        int len = min + (max > min ? rnd.nextInt(max - min + 1) : 0);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append(rnd.nextBoolean() ? (char) ('A' + rnd.nextInt(26)) : (char) ('0' + rnd.nextInt(10)));
        }
        return sb.toString();
    }

    private static String isin(Random rnd) {
        String country = COUNTRIES[rnd.nextInt(COUNTRIES.length)];
        StringBuilder sb = new StringBuilder(country);
        for (int i = 0; i < 9; i++) {
            sb.append(rnd.nextBoolean() ? (char) ('A' + rnd.nextInt(26)) : (char) ('0' + rnd.nextInt(10)));
        }
        sb.append(rnd.nextInt(10));
        return sb.toString();
    }

    private static String narrativeText(int maxLen, String nameHint, Random rnd) {
        String hint = nameHint == null ? "" : nameHint.toLowerCase();
        String text;
        if (hint.contains("nm") || hint.contains("nam")) {
            text = hint.contains("org") || hint.contains("pty") || rnd.nextBoolean()
                    ? ORG_NAMES[rnd.nextInt(ORG_NAMES.length)]
                    : PERSON_NAMES[rnd.nextInt(PERSON_NAMES.length)];
        } else {
            StringBuilder sb = new StringBuilder();
            int words = 2 + rnd.nextInt(4);
            for (int i = 0; i < words; i++) {
                if (sb.length() > 0) {
                    sb.append(' ');
                }
                sb.append(NARRATIVE_WORDS[rnd.nextInt(NARRATIVE_WORDS.length)]);
            }
            text = sb.toString();
        }
        return text.length() > maxLen ? text.substring(0, maxLen) : text;
    }

    private static String stringValue(XSSimpleType type, String nameHint, Random rnd) {
        Integer maxLen = facetInt(type, XSFacet.FACET_MAXLENGTH);
        Integer minLen = facetInt(type, XSFacet.FACET_MINLENGTH);
        int bound = maxLen != null ? maxLen : 35;
        String text = narrativeText(bound, nameHint, rnd);
        if (minLen != null && text.length() < minLen) {
            StringBuilder sb = new StringBuilder(text);
            while (sb.length() < minLen) {
                sb.append('X');
            }
            text = sb.toString();
        }
        return text;
    }

    private static String decimalValue(XSSimpleType type, String nameHint, Random rnd) {
        String hint = nameHint == null ? "" : nameHint.toLowerCase();
        Integer fractionDigits = facetInt(type, XSFacet.FACET_FRACTIONDIGITS);
        int decimals = fractionDigits != null ? Math.min(2, fractionDigits) : 2;

        double value;
        if (hint.contains("rate") || hint.contains("pctg") || hint.contains("rt")) {
            value = rnd.nextDouble() * 25.0;
        } else if (hint.contains("qty") || hint.contains("nb") || hint.contains("nmb")) {
            value = 1 + rnd.nextInt(10_000);
            decimals = 0;
        } else {
            value = 100 + rnd.nextDouble() * 999_900;
        }
        return String.format(java.util.Locale.ROOT, "%." + decimals + "f", value);
    }

    private static String isoDate(Random rnd) {
        LocalDate base = LocalDate.of(2026, 3, 16);
        LocalDate date = base.plusDays(rnd.nextInt(365) - 180);
        return date.toString();
    }

    private static final java.time.format.DateTimeFormatter DATE_TIME_FORMAT =
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

    private static String isoDateTime(Random rnd) {
        LocalDateTime base = LocalDateTime.of(2026, 3, 16, 10, 30, 0);
        LocalDateTime dt = base.plusMinutes(rnd.nextInt(10_000) - 5_000);
        return dt.format(DATE_TIME_FORMAT);
    }

    private static Integer facetInt(XSSimpleType type, String facetName) {
        XSFacet f = type.getFacet(facetName);
        if (f == null) {
            return null;
        }
        try {
            return Integer.parseInt(f.getValue().value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
