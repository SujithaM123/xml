package com.bench.generator;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

/**
 * Generates 5 valid sample XMLs per (message type x size) into samples/<type>/<size>/,
 * then validates every generated file against its own XSD and prints a pass/fail summary.
 */
public final class GenerateSamples {

    private static final int VARIANTS_PER_SIZE = 5;

    public static void main(String[] args) throws Exception {
        File xsdDir = new File("xsd");
        File samplesDir = new File("samples");

        int totalPassed = 0;
        int totalFailed = 0;
        StringBuilder manifest = new StringBuilder("[\n");
        boolean firstManifestRow = true;

        System.out.println("Type           Size     File                Bytes       TargetBytes  Diff%    Valid");
        System.out.println("----           ----     ----                -----       -----------  -----    -----");

        for (MessageSpec spec : MessageSpec.ALL) {
            SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = schemaFactory.newSchema(new File(xsdDir, spec.xsdFileName()));

            SampleXmlGenerator generator = new SampleXmlGenerator(xsdDir, spec);

            for (SizeTier tier : SizeTier.values()) {
                Path tierDir = samplesDir.toPath().resolve(spec.typeKey()).resolve(tier.folderName);
                Files.createDirectories(tierDir);

                for (int variant = 1; variant <= VARIANTS_PER_SIZE; variant++) {
                    Random rnd = new Random(seed(spec.typeKey(), tier.folderName, variant));
                    byte[] xml = generator.generateForTier(tier, rnd);

                    String fileName = "sample_" + variant + ".xml";
                    Path file = tierDir.resolve(fileName);
                    Files.write(file, xml);

                    boolean valid = validate(schema, xml);
                    if (valid) {
                        totalPassed++;
                    } else {
                        totalFailed++;
                    }

                    double diffPct = 100.0 * (xml.length - tier.targetBytes) / tier.targetBytes;
                    System.out.printf("%-14s %-8s %-19s %-11d %-12d %-8.1f %s%n",
                            spec.typeKey(), tier.folderName, fileName, xml.length, tier.targetBytes, diffPct,
                            valid ? "PASS" : "FAIL");

                    if (!firstManifestRow) manifest.append(",\n");
                    firstManifestRow = false;
                    manifest.append(String.format(java.util.Locale.ROOT,
                            "  {\"type\": \"%s\", \"size\": \"%s\", \"file\": \"%s\", \"actualBytes\": %d, "
                                    + "\"targetBytes\": %d, \"diffPct\": %.2f, \"valid\": %b}",
                            spec.typeKey(), tier.folderName, fileName, xml.length, tier.targetBytes, diffPct, valid));
                }
            }
        }
        manifest.append("\n]\n");
        Files.createDirectories(Path.of("results"));
        Files.writeString(Path.of("results", "sample_manifest.json"), manifest.toString());

        System.out.println();
        System.out.println("Total passed: " + totalPassed + ", failed: " + totalFailed);
        System.out.println("Per-file sizes and target-vs-actual differences recorded in results/sample_manifest.json");
        if (totalFailed > 0) {
            System.exit(1);
        }
    }

    private static long seed(String typeKey, String size, int variant) {
        return (long) typeKey.hashCode() * 31 + size.hashCode() * 17 + variant;
    }

    private static boolean validate(Schema schema, byte[] xml) {
        try {
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(new ByteArrayInputStream(xml)));
            return true;
        } catch (Exception e) {
            System.err.println("  validation error: " + e.getMessage());
            return false;
        }
    }
}
