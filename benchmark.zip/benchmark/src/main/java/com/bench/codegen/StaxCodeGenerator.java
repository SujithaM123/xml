package com.bench.codegen;

import jakarta.xml.bind.annotation.XmlAnyElement;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;
import jakarta.xml.bind.annotation.XmlValue;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * Build-time tool (not part of the benchmarked path): reflects once on the already-compiled
 * xjc POJOs to emit plain, hand-written-style StAX reader/writer .java source files -- one
 * reader + one writer per message type, with zero reflection and zero JAXB marshal/unmarshal
 * calls in the generated code itself.
 *
 * <p>Run after `mvn compile` (needs the xjc classes on the classpath), before the main
 * compile that will pick up its output under src/main/java/com/bench/stax/.</p>
 */
public final class StaxCodeGenerator {

    private static final Path OUT_DIR = Path.of("src/main/java/com/bench/stax");

    public static void main(String[] args) throws Exception {
        Files.createDirectories(OUT_DIR);
        generate("com.bench.capa.seev035", "CapaSeev035", "urn:iso:std:iso:20022:tech:xsd:seev.035.001.16");
        generate("com.bench.capa.supl009", "CapaSupl009", "urn:iso:std:iso:20022:tech:xsd:supl.009.001.11");
        generate("com.bench.caco.seev036", "CacoSeev036", "urn:iso:std:iso:20022:tech:xsd:seev.036.001.16");
        generate("com.bench.caco.supl011", "CacoSupl011", "urn:iso:std:iso:20022:tech:xsd:supl.011.001.11");
        System.out.println("StAX reader/writer source generated into " + OUT_DIR);
    }

    private static void generate(String pojoPackage, String prefix, String namespace) throws Exception {
        Class<?> documentClass = Class.forName(pojoPackage + ".Document");

        Set<Class<?>> types = new LinkedHashSet<>();
        collectTypes(documentClass, pojoPackage, types);

        String reader = generateReader(prefix, pojoPackage, types, namespace);
        String writer = generateWriter(prefix, pojoPackage, types, namespace);

        Files.writeString(OUT_DIR.resolve(prefix + "StaxReader.java"), reader);
        Files.writeString(OUT_DIR.resolve(prefix + "StaxWriter.java"), writer);
    }

    // ---- Discovery ----------------------------------------------------------------------

    private static void collectTypes(Class<?> clazz, String pojoPackage, Set<Class<?>> seen) {
        if (clazz.isEnum() || !seen.add(clazz)) {
            return;
        }
        for (Field f : clazz.getDeclaredFields()) {
            Class<?> elementType = List.class.isAssignableFrom(f.getType()) ? listElementType(f) : f.getType();
            if (elementType != null && elementType.getName().startsWith(pojoPackage)) {
                collectTypes(elementType, pojoPackage, seen);
            }
        }
    }

    private static Class<?> listElementType(Field f) {
        if (f.getGenericType() instanceof ParameterizedType pt) {
            return (Class<?>) pt.getActualTypeArguments()[0];
        }
        return null;
    }

    private static List<Field> propOrderFields(Class<?> c) {
        XmlType xmlType = c.getAnnotation(XmlType.class);
        List<Field> fields = new java.util.ArrayList<>();
        if (xmlType != null) {
            for (String name : xmlType.propOrder()) {
                if (name.isEmpty() || name.equals("##default")) {
                    continue;
                }
                try {
                    fields.add(c.getDeclaredField(name));
                } catch (NoSuchFieldException e) {
                    throw new IllegalStateException("propOrder field not found: " + name + " on " + c, e);
                }
            }
        }
        return fields;
    }

    private static List<Field> attributeFields(Class<?> c) {
        List<Field> fields = new java.util.ArrayList<>();
        for (Field f : c.getDeclaredFields()) {
            if (f.isAnnotationPresent(XmlAttribute.class)) {
                fields.add(f);
            }
        }
        return fields;
    }

    private static String xmlElementName(Field f) {
        XmlElement ann = f.getAnnotation(XmlElement.class);
        if (ann != null && !ann.name().equals("##default")) {
            return ann.name();
        }
        return capitalize(f.getName());
    }

    private static String xmlAttributeName(Field f) {
        return f.getAnnotation(XmlAttribute.class).name();
    }

    private static String capitalize(String s) {
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    /**
     * xjc names the getter/setter after the original XML name verbatim (e.g. field "isin" but
     * {@code getISIN()}; field "rdpRefNb" but {@code getRDPRefNb()}) -- not by re-capitalizing
     * the decapitalized field name. @XmlValue ("value") and @XmlAnyElement ("any") fields have
     * no XML element name, so those fall back to capitalizing the field name itself.
     */
    private static String accessorSuffix(Field f) {
        if (f.isAnnotationPresent(XmlAttribute.class)) {
            return xmlAttributeName(f);
        }
        XmlElement ann = f.getAnnotation(XmlElement.class);
        if (ann != null && !ann.name().equals("##default")) {
            return ann.name();
        }
        return capitalize(f.getName());
    }

    private static String getterPrefix(Class<?> type) {
        return (type == boolean.class || type == Boolean.class) ? "is" : "get";
    }

    private static boolean isAnyElement(Field f) {
        return f.isAnnotationPresent(XmlAnyElement.class);
    }

    // ---- Reader generation ---------------------------------------------------------------

    private static String generateReader(String prefix, String pojoPackage, Set<Class<?>> types, String namespace) {
        StringBuilder sb = new StringBuilder();
        sb.append("package com.bench.stax;\n\n");
        sb.append("import ").append(pojoPackage).append(".*;\n");
        sb.append("import javax.xml.stream.XMLInputFactory;\n");
        sb.append("import javax.xml.stream.XMLStreamConstants;\n");
        sb.append("import javax.xml.stream.XMLStreamException;\n");
        sb.append("import javax.xml.stream.XMLStreamReader;\n");
        sb.append("import javax.xml.datatype.DatatypeFactory;\n");
        sb.append("import java.io.ByteArrayInputStream;\n");
        sb.append("import java.math.BigDecimal;\n");
        sb.append("import java.math.BigInteger;\n\n");
        sb.append("/** Hand-written-style StAX reader for ").append(prefix).append(" (generated once from the xjc POJOs; no reflection or JAXB unmarshalling at runtime). */\n");
        sb.append("public final class ").append(prefix).append("StaxReader {\n\n");
        sb.append("    private static final XMLInputFactory INPUT_FACTORY = XMLInputFactory.newFactory();\n");
        sb.append("    private static final DatatypeFactory DATATYPE_FACTORY;\n");
        sb.append("    static {\n");
        sb.append("        try {\n");
        sb.append("            DATATYPE_FACTORY = DatatypeFactory.newInstance();\n");
        sb.append("        } catch (Exception e) {\n");
        sb.append("            throw new ExceptionInInitializerError(e);\n");
        sb.append("        }\n");
        sb.append("    }\n\n");
        sb.append("    private ").append(prefix).append("StaxReader() {\n    }\n\n");

        sb.append("    public static Document read(byte[] xml) throws XMLStreamException {\n");
        sb.append("        XMLStreamReader r = INPUT_FACTORY.createXMLStreamReader(new ByteArrayInputStream(xml));\n");
        sb.append("        r.nextTag();\n");
        sb.append("        Document doc = read_Document(r);\n");
        sb.append("        r.close();\n");
        sb.append("        return doc;\n");
        sb.append("    }\n\n");

        for (Class<?> c : types) {
            appendReaderMethod(sb, c);
        }

        sb.append("    private static void skip(XMLStreamReader r) throws XMLStreamException {\n");
        sb.append("        int depth = 1;\n");
        sb.append("        while (depth > 0) {\n");
        sb.append("            int ev = r.next();\n");
        sb.append("            if (ev == XMLStreamConstants.START_ELEMENT) depth++;\n");
        sb.append("            else if (ev == XMLStreamConstants.END_ELEMENT) depth--;\n");
        sb.append("        }\n");
        sb.append("    }\n");

        sb.append("}\n");
        return sb.toString();
    }

    private static void appendReaderMethod(StringBuilder sb, Class<?> c) {
        String cn = c.getSimpleName();
        List<Field> attrs = attributeFields(c);
        List<Field> allProps = propOrderFields(c);
        Field anyElement = allProps.stream().filter(StaxCodeGenerator::isAnyElement).findFirst().orElse(null);
        List<Field> props = allProps.stream().filter(f -> !isAnyElement(f)).toList();
        boolean simpleContent = props.size() == 1 && props.get(0).isAnnotationPresent(XmlValue.class);

        sb.append("    private static ").append(cn).append(" read_").append(cn).append("(XMLStreamReader r) throws XMLStreamException {\n");
        sb.append("        ").append(cn).append(" obj = new ").append(cn).append("();\n");
        for (Field a : attrs) {
            sb.append("        obj.set").append(accessorSuffix(a)).append('(')
                    .append(leafFromText(a.getType(), "r.getAttributeValue(null, \"" + xmlAttributeName(a) + "\")"))
                    .append(");\n");
        }
        if (simpleContent) {
            Field v = props.get(0);
            sb.append("        obj.set").append(accessorSuffix(v)).append('(')
                    .append(leafFromText(v.getType(), "r.getElementText()"))
                    .append(");\n");
            sb.append("        return obj;\n");
        } else {
            sb.append("        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {\n");
            sb.append("            if (ev != XMLStreamConstants.START_ELEMENT) continue;\n");
            sb.append("            switch (r.getLocalName()) {\n");
            for (Field p : props) {
                String xmlName = xmlElementName(p);
                boolean isList = List.class.isAssignableFrom(p.getType());
                if (isList) {
                    Class<?> elem = listElementType(p);
                    sb.append("                case \"").append(xmlName).append("\": obj.get").append(accessorSuffix(p))
                            .append("().add(").append(readCallFor(elem, "r")).append("); break;\n");
                } else {
                    sb.append("                case \"").append(xmlName).append("\": obj.set").append(accessorSuffix(p))
                            .append('(').append(readCallFor(p.getType(), "r")).append("); break;\n");
                }
            }
            if (anyElement != null) {
                sb.append("                default: obj.set").append(accessorSuffix(anyElement)).append("(r.getElementText()); break;\n");
            } else {
                sb.append("                default: skip(r); break;\n");
            }
            sb.append("            }\n");
            sb.append("        }\n");
            sb.append("        return obj;\n");
        }
        sb.append("    }\n\n");
    }

    private static String readCallFor(Class<?> type, String readerVar) {
        if (type.isEnum()) {
            return leafFromText(type, readerVar + ".getElementText()");
        }
        if (isKnownLeaf(type)) {
            return leafFromText(type, readerVar + ".getElementText()");
        }
        return "read_" + type.getSimpleName() + "(" + readerVar + ")";
    }

    private static String leafFromText(Class<?> type, String textExpr) {
        if (type == String.class) {
            return textExpr;
        }
        if (type == BigDecimal.class) {
            return "new BigDecimal(" + textExpr + ")";
        }
        if (type == BigInteger.class) {
            return "new BigInteger(" + textExpr + ")";
        }
        if (type == Boolean.class || type == boolean.class) {
            return "Boolean.parseBoolean(" + textExpr + ")";
        }
        if (type == XMLGregorianCalendar.class) {
            return "DATATYPE_FACTORY.newXMLGregorianCalendar(" + textExpr + ")";
        }
        if (type.isEnum()) {
            return type.getSimpleName() + ".fromValue(" + textExpr + ")";
        }
        return textExpr;
    }

    // ---- Writer generation ---------------------------------------------------------------

    private static String generateWriter(String prefix, String pojoPackage, Set<Class<?>> types, String namespace) {
        StringBuilder sb = new StringBuilder();
        sb.append("package com.bench.stax;\n\n");
        sb.append("import ").append(pojoPackage).append(".*;\n");
        sb.append("import javax.xml.stream.XMLOutputFactory;\n");
        sb.append("import javax.xml.stream.XMLStreamException;\n");
        sb.append("import javax.xml.stream.XMLStreamWriter;\n");
        sb.append("import java.io.ByteArrayOutputStream;\n\n");
        sb.append("/** Hand-written-style StAX writer for ").append(prefix).append(" (generated once from the xjc POJOs; no reflection or JAXB marshalling at runtime). */\n");
        sb.append("public final class ").append(prefix).append("StaxWriter {\n\n");
        sb.append("    private static final XMLOutputFactory OUTPUT_FACTORY = XMLOutputFactory.newFactory();\n\n");
        sb.append("    private ").append(prefix).append("StaxWriter() {\n    }\n\n");

        sb.append("    public static byte[] write(Document doc) throws XMLStreamException {\n");
        sb.append("        ByteArrayOutputStream out = new ByteArrayOutputStream();\n");
        sb.append("        XMLStreamWriter w = OUTPUT_FACTORY.createXMLStreamWriter(out, \"UTF-8\");\n");
        sb.append("        w.writeStartDocument(\"UTF-8\", \"1.0\");\n");
        sb.append("        write_Document(w, \"Document\", doc);\n");
        sb.append("        w.writeEndDocument();\n");
        sb.append("        w.flush();\n");
        sb.append("        w.close();\n");
        sb.append("        return out.toByteArray();\n");
        sb.append("    }\n\n");

        for (Class<?> c : types) {
            appendWriterMethod(sb, c, c.getSimpleName().equals("Document") ? namespace : null);
        }

        sb.append("    private static void writeLeaf(XMLStreamWriter w, String tag, String text) throws XMLStreamException {\n");
        sb.append("        w.writeStartElement(tag);\n");
        sb.append("        w.writeCharacters(text);\n");
        sb.append("        w.writeEndElement();\n");
        sb.append("    }\n");

        sb.append("}\n");
        return sb.toString();
    }

    private static void appendWriterMethod(StringBuilder sb, Class<?> c, String namespaceIfRoot) {
        String cn = c.getSimpleName();
        List<Field> attrs = attributeFields(c);
        List<Field> allProps = propOrderFields(c);
        Field anyElement = allProps.stream().filter(StaxCodeGenerator::isAnyElement).findFirst().orElse(null);
        List<Field> props = allProps.stream().filter(f -> !isAnyElement(f)).toList();
        boolean simpleContent = props.size() == 1 && props.get(0).isAnnotationPresent(XmlValue.class);

        sb.append("    private static void write_").append(cn).append("(XMLStreamWriter w, String tag, ").append(cn).append(" obj) throws XMLStreamException {\n");
        sb.append("        w.writeStartElement(tag);\n");
        if (namespaceIfRoot != null) {
            sb.append("        w.writeDefaultNamespace(\"").append(namespaceIfRoot).append("\");\n");
        }
        for (Field a : attrs) {
            String getter = "obj." + getterPrefix(a.getType()) + accessorSuffix(a) + "()";
            sb.append("        if (").append(getter).append(" != null) w.writeAttribute(\"").append(xmlAttributeName(a))
                    .append("\", ").append(leafToText(a.getType(), getter)).append(");\n");
        }
        if (simpleContent) {
            Field v = props.get(0);
            String getter = "obj." + getterPrefix(v.getType()) + accessorSuffix(v) + "()";
            sb.append("        w.writeCharacters(").append(leafToText(v.getType(), getter)).append(");\n");
        } else {
            for (Field p : props) {
                String xmlName = xmlElementName(p);
                boolean isList = List.class.isAssignableFrom(p.getType());
                if (isList) {
                    Class<?> elem = listElementType(p);
                    String getter = "obj.get" + accessorSuffix(p) + "()";
                    sb.append("        for (").append(elem.getSimpleName()).append(" item : ").append(getter).append(") ")
                            .append(writeCallFor(elem, "\"" + xmlName + "\"", "item")).append(";\n");
                } else {
                    String getter = "obj." + getterPrefix(p.getType()) + accessorSuffix(p) + "()";
                    String call = writeCallFor(p.getType(), "\"" + xmlName + "\"", getter);
                    if (p.getType().isPrimitive()) {
                        sb.append("        ").append(call).append(";\n"); // primitive: no minOccurs=0, always present
                    } else {
                        sb.append("        if (").append(getter).append(" != null) ").append(call).append(";\n");
                    }
                }
            }
            if (anyElement != null) {
                String getter = "obj.get" + accessorSuffix(anyElement) + "()";
                sb.append("        if (").append(getter).append(" != null) writeLeaf(w, \"SplmtryInfo\", String.valueOf(").append(getter).append("));\n");
            }
        }
        sb.append("        w.writeEndElement();\n");
        sb.append("    }\n\n");
    }

    private static String writeCallFor(Class<?> type, String tagExpr, String valueExpr) {
        if (!type.isEnum() && !isKnownLeaf(type)) {
            return "write_" + type.getSimpleName() + "(w, " + tagExpr + ", " + valueExpr + ")";
        }
        return "writeLeaf(w, " + tagExpr + ", " + leafToText(type, valueExpr) + ")";
    }

    private static String leafToText(Class<?> type, String valueExpr) {
        if (type == String.class) {
            return valueExpr;
        }
        if (type == BigDecimal.class || type == BigInteger.class) {
            return valueExpr + ".toString()";
        }
        if (type == Boolean.class || type == boolean.class) {
            return "String.valueOf(" + valueExpr + ")";
        }
        if (type == XMLGregorianCalendar.class) {
            return valueExpr + ".toXMLFormat()";
        }
        if (type.isEnum()) {
            return valueExpr + ".value()";
        }
        return "String.valueOf(" + valueExpr + ")";
    }

    private static boolean isKnownLeaf(Class<?> type) {
        return type == String.class || type == BigDecimal.class || type == BigInteger.class
                || type == Boolean.class || type == boolean.class || type == XMLGregorianCalendar.class;
    }
}
