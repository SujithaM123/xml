package com.bench.stax;

import com.bench.caco.supl011.*;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.ByteArrayOutputStream;

/** Hand-written-style StAX writer for CacoSupl011 (generated once from the xjc POJOs; no reflection or JAXB marshalling at runtime). */
public final class CacoSupl011StaxWriter {

    private static final XMLOutputFactory OUTPUT_FACTORY = XMLOutputFactory.newFactory();

    private CacoSupl011StaxWriter() {
    }

    public static byte[] write(Document doc) throws XMLStreamException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        XMLStreamWriter w = OUTPUT_FACTORY.createXMLStreamWriter(out, "UTF-8");
        w.writeStartDocument("UTF-8", "1.0");
        write_Document(w, "Document", doc);
        w.writeEndDocument();
        w.flush();
        w.close();
        return out.toByteArray();
    }

    private static void write_Document(XMLStreamWriter w, String tag, Document obj) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeDefaultNamespace("urn:iso:std:iso:20022:tech:xsd:supl.011.001.11");
        if (obj.getDTCCCACOSD1() != null) write_DTCCCACOSD1V11(w, "DTCCCACOSD1", obj.getDTCCCACOSD1());
        w.writeEndElement();
    }

    private static void write_DTCCCACOSD1V11(XMLStreamWriter w, String tag, DTCCCACOSD1V11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCorpActnGnlInf() != null) write_CorporateActionGeneralInformationSD60(w, "CorpActnGnlInf", obj.getCorpActnGnlInf());
        if (obj.getUndrlygScty() != null) write_FinancialInstrumentAttributesSD21(w, "UndrlygScty", obj.getUndrlygScty());
        if (obj.getCorpActnDtls() != null) write_CorporateActionSD20(w, "CorpActnDtls", obj.getCorpActnDtls());
        for (AccountBalanceSD14 item : obj.getAcctBal()) write_AccountBalanceSD14(w, "AcctBal", item);
        if (obj.getCorpActnConfDtls() != null) write_CorporateActionConfirmationDetailsSD2(w, "CorpActnConfDtls", obj.getCorpActnConfDtls());
        for (CorporateActionConfirmationSecuritiesMovementDetailsSD6 item : obj.getCorpActnConfSctiesMvmntDtls()) write_CorporateActionConfirmationSecuritiesMovementDetailsSD6(w, "CorpActnConfSctiesMvmntDtls", item);
        for (CorporateActionConfirmationCashMovementDetailsSD5 item : obj.getCorpActnConfCshMvmntDtls()) write_CorporateActionConfirmationCashMovementDetailsSD5(w, "CorpActnConfCshMvmntDtls", item);
        for (OptionTransactionSD6 item : obj.getOptnTxDtls()) write_OptionTransactionSD6(w, "OptnTxDtls", item);
        w.writeEndElement();
    }

    private static void write_CorporateActionGeneralInformationSD60(XMLStreamWriter w, String tag, CorporateActionGeneralInformationSD60 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getEvtGrp() != null) writeLeaf(w, "EvtGrp", obj.getEvtGrp().value());
        if (obj.getEvtTp() != null) writeLeaf(w, "EvtTp", obj.getEvtTp().value());
        if (obj.getSubEvtTp() != null) writeLeaf(w, "SubEvtTp", obj.getSubEvtTp().value());
        if (obj.getRedId() != null) writeLeaf(w, "RedId", obj.getRedId());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentAttributesSD21(XMLStreamWriter w, String tag, FinancialInstrumentAttributesSD21 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getOrgtgSctyId() != null) write_OtherIdentification2(w, "OrgtgSctyId", obj.getOrgtgSctyId());
        if (obj.isMnyMktInstrmFlg() != null) writeLeaf(w, "MnyMktInstrmFlg", String.valueOf(obj.isMnyMktInstrmFlg()));
        w.writeEndElement();
    }

    private static void write_OtherIdentification2(XMLStreamWriter w, String tag, OtherIdentification2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        if (obj.getSfx() != null) writeLeaf(w, "Sfx", obj.getSfx());
        if (obj.getTp() != null) write_IdentificationSource4Choice(w, "Tp", obj.getTp());
        w.writeEndElement();
    }

    private static void write_IdentificationSource4Choice(XMLStreamWriter w, String tag, IdentificationSource4Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd());
        if (obj.getPrtry() != null) writeLeaf(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_CorporateActionSD20(XMLStreamWriter w, String tag, CorporateActionSD20 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getLtrySeqNb() != null) writeLeaf(w, "LtrySeqNb", obj.getLtrySeqNb());
        if (obj.getLtryDt() != null) writeLeaf(w, "LtryDt", obj.getLtryDt().toXMLFormat());
        if (obj.getPrcToDt() != null) writeLeaf(w, "PrcToDt", obj.getPrcToDt().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_AccountBalanceSD14(XMLStreamWriter w, String tag, AccountBalanceSD14 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getOrgnlBal() != null) write_SignedQuantityFormat9(w, "OrgnlBal", obj.getOrgnlBal());
        if (obj.getUpldgBal() != null) write_SignedQuantityFormat9(w, "UpldgBal", obj.getUpldgBal());
        if (obj.getInvstmtUpldgBal() != null) write_SignedQuantityFormat9(w, "InvstmtUpldgBal", obj.getInvstmtUpldgBal());
        if (obj.getInvstmtPldgBal() != null) write_SignedQuantityFormat9(w, "InvstmtPldgBal", obj.getInvstmtPldgBal());
        if (obj.getOvrsbcptBal() != null) write_SignedQuantityFormat9(w, "OvrsbcptBal", obj.getOvrsbcptBal());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat9(XMLStreamWriter w, String tag, SignedQuantityFormat9 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQty() != null) write_FinancialInstrumentQuantity15Choice(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity15Choice(XMLStreamWriter w, String tag, FinancialInstrumentQuantity15Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        if (obj.getAmtsdVal() != null) writeLeaf(w, "AmtsdVal", obj.getAmtsdVal().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionConfirmationDetailsSD2(XMLStreamWriter w, String tag, CorporateActionConfirmationDetailsSD2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getPrratnRndgInd() != null) writeLeaf(w, "PrratnRndgInd", obj.getPrratnRndgInd().value());
        if (obj.getPrratnFrctn() != null) writeLeaf(w, "PrratnFrctn", obj.getPrratnFrctn().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionConfirmationSecuritiesMovementDetailsSD6(XMLStreamWriter w, String tag, CorporateActionConfirmationSecuritiesMovementDetailsSD6 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getPyoutTp() != null) writeLeaf(w, "PyoutTp", obj.getPyoutTp().value());
        if (obj.getTxQty() != null) write_FinancialInstrumentQuantity15Choice(w, "TxQty", obj.getTxQty());
        if (obj.getRsnCd() != null) writeLeaf(w, "RsnCd", obj.getRsnCd().value());
        if (obj.getSubRsnCd() != null) writeLeaf(w, "SubRsnCd", obj.getSubRsnCd().value());
        if (obj.getContraPtcptNb() != null) writeLeaf(w, "ContraPtcptNb", obj.getContraPtcptNb());
        if (obj.getMtrtyDt() != null) writeLeaf(w, "MtrtyDt", obj.getMtrtyDt().toXMLFormat());
        if (obj.getPstngDt() != null) write_DateFormat48Choice(w, "PstngDt", obj.getPstngDt());
        if (obj.getTaxAdjstmntRate() != null) writeLeaf(w, "TaxAdjstmntRate", obj.getTaxAdjstmntRate().toString());
        if (obj.getRDPRefNb() != null) writeLeaf(w, "RDPRefNb", obj.getRDPRefNb());
        if (obj.getRndgFctr() != null) writeLeaf(w, "RndgFctr", obj.getRndgFctr().toString());
        w.writeEndElement();
    }

    private static void write_DateFormat48Choice(XMLStreamWriter w, String tag, DateFormat48Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) write_DateAndDateTime2Choice(w, "Dt", obj.getDt());
        if (obj.getDtCd() != null) writeLeaf(w, "DtCd", obj.getDtCd().value());
        w.writeEndElement();
    }

    private static void write_DateAndDateTime2Choice(XMLStreamWriter w, String tag, DateAndDateTime2Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) writeLeaf(w, "Dt", obj.getDt().toXMLFormat());
        if (obj.getDtTm() != null) writeLeaf(w, "DtTm", obj.getDtTm().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_CorporateActionConfirmationCashMovementDetailsSD5(XMLStreamWriter w, String tag, CorporateActionConfirmationCashMovementDetailsSD5 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getPyoutTp() != null) writeLeaf(w, "PyoutTp", obj.getPyoutTp().value());
        if (obj.getTxAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "TxAmt", obj.getTxAmt());
        if (obj.getRsnCd() != null) writeLeaf(w, "RsnCd", obj.getRsnCd().value());
        if (obj.getSubRsnCd() != null) writeLeaf(w, "SubRsnCd", obj.getSubRsnCd().value());
        if (obj.getContraPtcptNb() != null) writeLeaf(w, "ContraPtcptNb", obj.getContraPtcptNb());
        if (obj.getPstngDt() != null) write_DateFormat48Choice(w, "PstngDt", obj.getPstngDt());
        if (obj.getTaxAdjstmntRate() != null) writeLeaf(w, "TaxAdjstmntRate", obj.getTaxAdjstmntRate().toString());
        if (obj.getRDPRefNb() != null) writeLeaf(w, "RDPRefNb", obj.getRDPRefNb());
        if (obj.getTxQty() != null) write_FinancialInstrumentQuantity15Choice(w, "TxQty", obj.getTxQty());
        w.writeEndElement();
    }

    private static void write_RestrictedFINActiveCurrencyAndAmount(XMLStreamWriter w, String tag, RestrictedFINActiveCurrencyAndAmount obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCcy() != null) w.writeAttribute("Ccy", obj.getCcy());
        w.writeCharacters(obj.getValue().toString());
        w.writeEndElement();
    }

    private static void write_OptionTransactionSD6(XMLStreamWriter w, String tag, OptionTransactionSD6 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getTxId() != null) writeLeaf(w, "TxId", obj.getTxId());
        if (obj.getTxSeqNb() != null) writeLeaf(w, "TxSeqNb", obj.getTxSeqNb());
        if (obj.getTxIdDt() != null) writeLeaf(w, "TxIdDt", obj.getTxIdDt().toXMLFormat());
        if (obj.getTxIdQty() != null) write_FinancialInstrumentQuantity15Choice(w, "TxIdQty", obj.getTxIdQty());
        if (obj.getTxIdOvrsbcptQty() != null) write_FinancialInstrumentQuantity15Choice(w, "TxIdOvrsbcptQty", obj.getTxIdOvrsbcptQty());
        if (obj.getAccptdQty() != null) write_FinancialInstrumentQuantity15Choice(w, "AccptdQty", obj.getAccptdQty());
        if (obj.getUaccptdQty() != null) write_FinancialInstrumentQuantity15Choice(w, "UaccptdQty", obj.getUaccptdQty());
        if (obj.getEntitldAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "EntitldAmt", obj.getEntitldAmt());
        if (obj.getEntitldQty() != null) write_FinancialInstrumentQuantity15Choice(w, "EntitldQty", obj.getEntitldQty());
        if (obj.getEntitldOvrsbcptQty() != null) write_FinancialInstrumentQuantity15Choice(w, "EntitldOvrsbcptQty", obj.getEntitldOvrsbcptQty());
        if (obj.getSbcptAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "SbcptAmt", obj.getSbcptAmt());
        if (obj.getOvrsbcptAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "OvrsbcptAmt", obj.getOvrsbcptAmt());
        if (obj.getCshInLieuOfShr() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "CshInLieuOfShr", obj.getCshInLieuOfShr());
        if (obj.getCstmrRefId() != null) writeLeaf(w, "CstmrRefId", obj.getCstmrRefId());
        if (obj.getAgtNtrdQty() != null) write_FinancialInstrumentQuantity15Choice(w, "AgtNtrdQty", obj.getAgtNtrdQty());
        if (obj.getInstrCmnts() != null) writeLeaf(w, "InstrCmnts", obj.getInstrCmnts());
        if (obj.getAdjstdSbcptAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "AdjstdSbcptAmt", obj.getAdjstdSbcptAmt());
        if (obj.getRfnddSbcptAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "RfnddSbcptAmt", obj.getRfnddSbcptAmt());
        w.writeEndElement();
    }

    private static void writeLeaf(XMLStreamWriter w, String tag, String text) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeCharacters(text);
        w.writeEndElement();
    }
}
