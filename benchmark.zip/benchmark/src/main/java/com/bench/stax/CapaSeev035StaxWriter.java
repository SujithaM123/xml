package com.bench.stax;

import com.bench.capa.seev035.*;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.ByteArrayOutputStream;

/** Hand-written-style StAX writer for CapaSeev035 (generated once from the xjc POJOs; no reflection or JAXB marshalling at runtime). */
public final class CapaSeev035StaxWriter {

    private static final XMLOutputFactory OUTPUT_FACTORY = XMLOutputFactory.newFactory();

    private CapaSeev035StaxWriter() {
    }

    public static byte[] write(Document doc) throws XMLStreamException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        XMLStreamWriter w = OUTPUT_FACTORY.createXMLStreamWriter(out, "UTF-8");
        w.writeStartDocument("UTF-8", "1.0");
        write_Document(w, "Document", doc);
        w.writeEndDocument();
        w.flush();
        w.close();
        return out.toByteArray();
    }

    private static void write_Document(XMLStreamWriter w, String tag, Document obj) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeDefaultNamespace("urn:iso:std:iso:20022:tech:xsd:seev.035.001.16");
        if (obj.getCorpActnMvmntPrlimryAdvc() != null) write_CorporateActionMovementPreliminaryAdviceV16(w, "CorpActnMvmntPrlimryAdvc", obj.getCorpActnMvmntPrlimryAdvc());
        w.writeEndElement();
    }

    private static void write_CorporateActionMovementPreliminaryAdviceV16(XMLStreamWriter w, String tag, CorporateActionMovementPreliminaryAdviceV16 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPgntn() != null) write_Pagination1(w, "Pgntn", obj.getPgntn());
        if (obj.getMvmntPrlimryAdvcGnlInf() != null) write_CorporateActionPreliminaryAdviceType41(w, "MvmntPrlimryAdvcGnlInf", obj.getMvmntPrlimryAdvcGnlInf());
        if (obj.getPrvsMvmntPrlimryAdvcId() != null) write_DocumentIdentification311(w, "PrvsMvmntPrlimryAdvcId", obj.getPrvsMvmntPrlimryAdvcId());
        if (obj.getMvmntConfId() != null) write_DocumentIdentification311(w, "MvmntConfId", obj.getMvmntConfId());
        if (obj.getRvslRsn() != null) write_CorporateActionReversalReason81(w, "RvslRsn", obj.getRvslRsn());
        if (obj.getCorpActnGnlInf() != null) write_CorporateActionGeneralInformation1781(w, "CorpActnGnlInf", obj.getCorpActnGnlInf());
        if (obj.getAcctDtls() != null) write_AccountIdentification70Choice1(w, "AcctDtls", obj.getAcctDtls());
        if (obj.getCorpActnDtls() != null) write_CorporateAction691(w, "CorpActnDtls", obj.getCorpActnDtls());
        for (CorporateActionOption2321 item : obj.getCorpActnMvmntDtls()) write_CorporateActionOption2321(w, "CorpActnMvmntDtls", item);
        if (obj.getAddtlInf() != null) write_CorporateActionNarrative561(w, "AddtlInf", obj.getAddtlInf());
        for (SupplementaryData11 item : obj.getSplmtryData()) write_SupplementaryData11(w, "SplmtryData", item);
        w.writeEndElement();
    }

    private static void write_Pagination1(XMLStreamWriter w, String tag, Pagination1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPgNb() != null) writeLeaf(w, "PgNb", obj.getPgNb());
        writeLeaf(w, "LastPgInd", String.valueOf(obj.isLastPgInd()));
        w.writeEndElement();
    }

    private static void write_CorporateActionPreliminaryAdviceType41(XMLStreamWriter w, String tag, CorporateActionPreliminaryAdviceType41 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getMvmntPrlimryAdvcId() != null) writeLeaf(w, "MvmntPrlimryAdvcId", obj.getMvmntPrlimryAdvcId());
        if (obj.getTp() != null) writeLeaf(w, "Tp", obj.getTp().value());
        if (obj.getFctn() != null) writeLeaf(w, "Fctn", obj.getFctn().value());
        w.writeEndElement();
    }

    private static void write_DocumentIdentification311(XMLStreamWriter w, String tag, DocumentIdentification311 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        w.writeEndElement();
    }

    private static void write_CorporateActionReversalReason81(XMLStreamWriter w, String tag, CorporateActionReversalReason81 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRsn() != null) write_CorporateActionReversalReason10Choice1(w, "Rsn", obj.getRsn());
        w.writeEndElement();
    }

    private static void write_CorporateActionReversalReason10Choice1(XMLStreamWriter w, String tag, CorporateActionReversalReason10Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionGeneralInformation1781(XMLStreamWriter w, String tag, CorporateActionGeneralInformation1781 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCorpActnEvtId() != null) writeLeaf(w, "CorpActnEvtId", obj.getCorpActnEvtId());
        if (obj.getOffclCorpActnEvtId() != null) writeLeaf(w, "OffclCorpActnEvtId", obj.getOffclCorpActnEvtId());
        if (obj.getEvtPrcgTp() != null) write_CorporateActionEventProcessingType2Choice1(w, "EvtPrcgTp", obj.getEvtPrcgTp());
        if (obj.getEvtTp() != null) write_CorporateActionEventType108Choice1(w, "EvtTp", obj.getEvtTp());
        if (obj.getMndtryVlntryEvtTp() != null) write_CorporateActionMandatoryVoluntary3Choice1(w, "MndtryVlntryEvtTp", obj.getMndtryVlntryEvtTp());
        if (obj.getUndrlygScty() != null) write_FinancialInstrumentAttributes1281(w, "UndrlygScty", obj.getUndrlygScty());
        w.writeEndElement();
    }

    private static void write_CorporateActionEventProcessingType2Choice1(XMLStreamWriter w, String tag, CorporateActionEventProcessingType2Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionEventType108Choice1(XMLStreamWriter w, String tag, CorporateActionEventType108Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionMandatoryVoluntary3Choice1(XMLStreamWriter w, String tag, CorporateActionMandatoryVoluntary3Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentAttributes1281(XMLStreamWriter w, String tag, FinancialInstrumentAttributes1281 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getFinInstrmId() != null) write_SecurityIdentification191(w, "FinInstrmId", obj.getFinInstrmId());
        w.writeEndElement();
    }

    private static void write_SecurityIdentification191(XMLStreamWriter w, String tag, SecurityIdentification191 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getISIN() != null) writeLeaf(w, "ISIN", obj.getISIN());
        if (obj.getOthrId() != null) write_OtherIdentification11(w, "OthrId", obj.getOthrId());
        if (obj.getDesc() != null) writeLeaf(w, "Desc", obj.getDesc());
        w.writeEndElement();
    }

    private static void write_OtherIdentification11(XMLStreamWriter w, String tag, OtherIdentification11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        if (obj.getTp() != null) write_IdentificationSource3Choice1(w, "Tp", obj.getTp());
        w.writeEndElement();
    }

    private static void write_IdentificationSource3Choice1(XMLStreamWriter w, String tag, IdentificationSource3Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd());
        if (obj.getPrtry() != null) writeLeaf(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_AccountIdentification70Choice1(XMLStreamWriter w, String tag, AccountIdentification70Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAcctsListAndBalDtls() != null) write_AccountAndBalance591(w, "AcctsListAndBalDtls", obj.getAcctsListAndBalDtls());
        w.writeEndElement();
    }

    private static void write_AccountAndBalance591(XMLStreamWriter w, String tag, AccountAndBalance591 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getSfkpgAcct() != null) writeLeaf(w, "SfkpgAcct", obj.getSfkpgAcct());
        if (obj.getBal() != null) write_CorporateActionBalanceDetails431(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_CorporateActionBalanceDetails431(XMLStreamWriter w, String tag, CorporateActionBalanceDetails431 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getTtlElgblBal() != null) write_TotalEligibleBalanceFormat101(w, "TtlElgblBal", obj.getTtlElgblBal());
        if (obj.getBrrwdBal() != null) write_BalanceFormat11Choice1(w, "BrrwdBal", obj.getBrrwdBal());
        if (obj.getCollInBal() != null) write_BalanceFormat11Choice1(w, "CollInBal", obj.getCollInBal());
        if (obj.getCollOutBal() != null) write_BalanceFormat11Choice1(w, "CollOutBal", obj.getCollOutBal());
        if (obj.getOnLnBal() != null) write_BalanceFormat11Choice1(w, "OnLnBal", obj.getOnLnBal());
        if (obj.getPdgDlvryBal() != null) write_BalanceFormat12Choice1(w, "PdgDlvryBal", obj.getPdgDlvryBal());
        if (obj.getPdgRctBal() != null) write_BalanceFormat12Choice1(w, "PdgRctBal", obj.getPdgRctBal());
        if (obj.getSttlmPosBal() != null) write_BalanceFormat12Choice1(w, "SttlmPosBal", obj.getSttlmPosBal());
        if (obj.getOblgtdBal() != null) write_BalanceFormat11Choice1(w, "OblgtdBal", obj.getOblgtdBal());
        if (obj.getUinstdBal() != null) write_BalanceFormat11Choice2(w, "UinstdBal", obj.getUinstdBal());
        if (obj.getInstdBal() != null) write_BalanceFormat11Choice3(w, "InstdBal", obj.getInstdBal());
        if (obj.getAfctdBal() != null) write_BalanceFormat11Choice4(w, "AfctdBal", obj.getAfctdBal());
        if (obj.getUafctdBal() != null) write_BalanceFormat11Choice4(w, "UafctdBal", obj.getUafctdBal());
        w.writeEndElement();
    }

    private static void write_TotalEligibleBalanceFormat101(XMLStreamWriter w, String tag, TotalEligibleBalanceFormat101 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_Quantity49Choice1(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_Quantity49Choice1(XMLStreamWriter w, String tag, Quantity49Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQtyChc() != null) write_Quantity50Choice1(w, "QtyChc", obj.getQtyChc());
        w.writeEndElement();
    }

    private static void write_Quantity50Choice1(XMLStreamWriter w, String tag, Quantity50Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getSgndQty() != null) write_SignedQuantityFormat101(w, "SgndQty", obj.getSgndQty());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat101(XMLStreamWriter w, String tag, SignedQuantityFormat101 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity33Choice1(XMLStreamWriter w, String tag, FinancialInstrumentQuantity33Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        w.writeEndElement();
    }

    private static void write_BalanceFormat11Choice1(XMLStreamWriter w, String tag, BalanceFormat11Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat111(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat111(XMLStreamWriter w, String tag, SignedQuantityFormat111 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQtyChc() != null) write_Quantity48Choice1(w, "QtyChc", obj.getQtyChc());
        w.writeEndElement();
    }

    private static void write_Quantity48Choice1(XMLStreamWriter w, String tag, Quantity48Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_BalanceFormat12Choice1(XMLStreamWriter w, String tag, BalanceFormat12Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat111(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_BalanceFormat11Choice2(XMLStreamWriter w, String tag, BalanceFormat11Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat112(w, "Bal", obj.getBal());
        if (obj.getElgblBal() != null) write_SignedQuantityFormat101(w, "ElgblBal", obj.getElgblBal());
        if (obj.getNotElgblBal() != null) write_SignedQuantityFormat102(w, "NotElgblBal", obj.getNotElgblBal());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat112(XMLStreamWriter w, String tag, SignedQuantityFormat112 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQtyChc() != null) write_Quantity48Choice2(w, "QtyChc", obj.getQtyChc());
        w.writeEndElement();
    }

    private static void write_Quantity48Choice2(XMLStreamWriter w, String tag, Quantity48Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "Qty", obj.getQty());
        if (obj.getPrtryQty() != null) write_ProprietaryQuantity81(w, "PrtryQty", obj.getPrtryQty());
        w.writeEndElement();
    }

    private static void write_ProprietaryQuantity81(XMLStreamWriter w, String tag, ProprietaryQuantity81 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty() != null) writeLeaf(w, "Qty", obj.getQty().toString());
        if (obj.getQtyTp() != null) writeLeaf(w, "QtyTp", obj.getQtyTp());
        if (obj.getIssr() != null) writeLeaf(w, "Issr", obj.getIssr());
        if (obj.getSchmeNm() != null) writeLeaf(w, "SchmeNm", obj.getSchmeNm());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat102(XMLStreamWriter w, String tag, SignedQuantityFormat102 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice2(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity33Choice2(XMLStreamWriter w, String tag, FinancialInstrumentQuantity33Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        if (obj.getAmtsdVal() != null) writeLeaf(w, "AmtsdVal", obj.getAmtsdVal().toString());
        if (obj.getDgtlTknUnit() != null) writeLeaf(w, "DgtlTknUnit", obj.getDgtlTknUnit().toString());
        w.writeEndElement();
    }

    private static void write_BalanceFormat11Choice3(XMLStreamWriter w, String tag, BalanceFormat11Choice3 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat112(w, "Bal", obj.getBal());
        if (obj.getElgblBal() != null) write_SignedQuantityFormat101(w, "ElgblBal", obj.getElgblBal());
        if (obj.getNotElgblBal() != null) write_SignedQuantityFormat101(w, "NotElgblBal", obj.getNotElgblBal());
        w.writeEndElement();
    }

    private static void write_BalanceFormat11Choice4(XMLStreamWriter w, String tag, BalanceFormat11Choice4 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat113(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat113(XMLStreamWriter w, String tag, SignedQuantityFormat113 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQtyChc() != null) write_Quantity48Choice1(w, "QtyChc", obj.getQtyChc());
        w.writeEndElement();
    }

    private static void write_CorporateAction691(XMLStreamWriter w, String tag, CorporateAction691 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDtDtls() != null) write_CorporateActionDate851(w, "DtDtls", obj.getDtDtls());
        if (obj.getSctiesQty() != null) write_CorporateActionQuantity121(w, "SctiesQty", obj.getSctiesQty());
        if (obj.getEvtStag() != null) write_CorporateActionEventStageFormat14Choice1(w, "EvtStag", obj.getEvtStag());
        for (AdditionalBusinessProcessFormat18Choice1 item : obj.getAddtlBizPrcInd()) write_AdditionalBusinessProcessFormat18Choice1(w, "AddtlBizPrcInd", item);
        if (obj.getIntrmdtSctiesDstrbtnTp() != null) write_IntermediateSecuritiesDistributionTypeFormat15Choice1(w, "IntrmdtSctiesDstrbtnTp", obj.getIntrmdtSctiesDstrbtnTp());
        if (obj.getLtryTp() != null) write_LotteryTypeFormat4Choice1(w, "LtryTp", obj.getLtryTp());
        w.writeEndElement();
    }

    private static void write_CorporateActionDate851(XMLStreamWriter w, String tag, CorporateActionDate851 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRcrdDt() != null) write_DateFormat30Choice1(w, "RcrdDt", obj.getRcrdDt());
        if (obj.getExDvddDt() != null) write_DateFormat30Choice1(w, "ExDvddDt", obj.getExDvddDt());
        if (obj.getLtryDt() != null) write_DateFormat30Choice2(w, "LtryDt", obj.getLtryDt());
        w.writeEndElement();
    }

    private static void write_DateFormat30Choice1(XMLStreamWriter w, String tag, DateFormat30Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) writeLeaf(w, "Dt", obj.getDt().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_DateFormat30Choice2(XMLStreamWriter w, String tag, DateFormat30Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) writeLeaf(w, "Dt", obj.getDt().toXMLFormat());
        if (obj.getDtCd() != null) write_DateCode19Choice1(w, "DtCd", obj.getDtCd());
        w.writeEndElement();
    }

    private static void write_DateCode19Choice1(XMLStreamWriter w, String tag, DateCode19Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionQuantity121(XMLStreamWriter w, String tag, CorporateActionQuantity121 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBaseDnmtn() != null) write_FinancialInstrumentQuantity35Choice1(w, "BaseDnmtn", obj.getBaseDnmtn());
        if (obj.getIncrmtlDnmtn() != null) write_FinancialInstrumentQuantity35Choice1(w, "IncrmtlDnmtn", obj.getIncrmtlDnmtn());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity35Choice1(XMLStreamWriter w, String tag, FinancialInstrumentQuantity35Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionEventStageFormat14Choice1(XMLStreamWriter w, String tag, CorporateActionEventStageFormat14Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_AdditionalBusinessProcessFormat18Choice1(XMLStreamWriter w, String tag, AdditionalBusinessProcessFormat18Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_IntermediateSecuritiesDistributionTypeFormat15Choice1(XMLStreamWriter w, String tag, IntermediateSecuritiesDistributionTypeFormat15Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        if (obj.getPrtry() != null) write_GenericIdentification301(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_GenericIdentification301(XMLStreamWriter w, String tag, GenericIdentification301 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        if (obj.getIssr() != null) writeLeaf(w, "Issr", obj.getIssr());
        if (obj.getSchmeNm() != null) writeLeaf(w, "SchmeNm", obj.getSchmeNm());
        w.writeEndElement();
    }

    private static void write_LotteryTypeFormat4Choice1(XMLStreamWriter w, String tag, LotteryTypeFormat4Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionOption2321(XMLStreamWriter w, String tag, CorporateActionOption2321 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getOptnNb() != null) writeLeaf(w, "OptnNb", obj.getOptnNb());
        if (obj.getOptnTp() != null) write_CorporateActionOption37Choice1(w, "OptnTp", obj.getOptnTp());
        if (obj.getCcyOptn() != null) writeLeaf(w, "CcyOptn", obj.getCcyOptn());
        if (obj.getDfltPrcgOrStgInstr() != null) write_DefaultProcessingOrStandingInstruction2Choice1(w, "DfltPrcgOrStgInstr", obj.getDfltPrcgOrStgInstr());
        for (SecuritiesOption1181 item : obj.getSctiesMvmntDtls()) write_SecuritiesOption1181(w, "SctiesMvmntDtls", item);
        for (CashOption1041 item : obj.getCshMvmntDtls()) write_CashOption1041(w, "CshMvmntDtls", item);
        if (obj.getAddtlInf() != null) write_CorporateActionNarrative571(w, "AddtlInf", obj.getAddtlInf());
        w.writeEndElement();
    }

    private static void write_CorporateActionOption37Choice1(XMLStreamWriter w, String tag, CorporateActionOption37Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_DefaultProcessingOrStandingInstruction2Choice1(XMLStreamWriter w, String tag, DefaultProcessingOrStandingInstruction2Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.isDfltOptnInd() != null) writeLeaf(w, "DfltOptnInd", String.valueOf(obj.isDfltOptnInd()));
        w.writeEndElement();
    }

    private static void write_SecuritiesOption1181(XMLStreamWriter w, String tag, SecuritiesOption1181 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getSctyDtls() != null) write_FinancialInstrumentAttributes1291(w, "SctyDtls", obj.getSctyDtls());
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getTempFinInstrmInd() != null) write_TemporaryFinancialInstrumentIndicator3Choice1(w, "TempFinInstrmInd", obj.getTempFinInstrmInd());
        if (obj.getNewSctiesIssncInd() != null) writeLeaf(w, "NewSctiesIssncInd", obj.getNewSctiesIssncInd().value());
        if (obj.getEntitldQty() != null) write_Quantity51Choice1(w, "EntitldQty", obj.getEntitldQty());
        if (obj.getDtDtls() != null) write_SecurityDate201(w, "DtDtls", obj.getDtDtls());
        if (obj.getRateDtls() != null) write_CorporateActionRate1231(w, "RateDtls", obj.getRateDtls());
        if (obj.getPricDtls() != null) write_CorporateActionPrice821(w, "PricDtls", obj.getPricDtls());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentAttributes1291(XMLStreamWriter w, String tag, FinancialInstrumentAttributes1291 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getFinInstrmId() != null) write_SecurityIdentification192(w, "FinInstrmId", obj.getFinInstrmId());
        if (obj.getMtrtyDt() != null) writeLeaf(w, "MtrtyDt", obj.getMtrtyDt().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_SecurityIdentification192(XMLStreamWriter w, String tag, SecurityIdentification192 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getISIN() != null) writeLeaf(w, "ISIN", obj.getISIN());
        for (OtherIdentification11 item : obj.getOthrId()) write_OtherIdentification11(w, "OthrId", item);
        if (obj.getDesc() != null) writeLeaf(w, "Desc", obj.getDesc());
        w.writeEndElement();
    }

    private static void write_TemporaryFinancialInstrumentIndicator3Choice1(XMLStreamWriter w, String tag, TemporaryFinancialInstrumentIndicator3Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.isTempInd() != null) writeLeaf(w, "TempInd", String.valueOf(obj.isTempInd()));
        w.writeEndElement();
    }

    private static void write_Quantity51Choice1(XMLStreamWriter w, String tag, Quantity51Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_SecurityDate201(XMLStreamWriter w, String tag, SecurityDate201 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPmtDt() != null) write_DateFormat30Choice3(w, "PmtDt", obj.getPmtDt());
        if (obj.getEarlstPmtDt() != null) write_DateFormat30Choice2(w, "EarlstPmtDt", obj.getEarlstPmtDt());
        w.writeEndElement();
    }

    private static void write_DateFormat30Choice3(XMLStreamWriter w, String tag, DateFormat30Choice3 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) writeLeaf(w, "Dt", obj.getDt().toXMLFormat());
        if (obj.getDtCd() != null) write_DateCode19Choice2(w, "DtCd", obj.getDtCd());
        w.writeEndElement();
    }

    private static void write_DateCode19Choice2(XMLStreamWriter w, String tag, DateCode19Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionRate1231(XMLStreamWriter w, String tag, CorporateActionRate1231 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAddtlQtyForExstgScties() != null) write_RatioFormat17Choice1(w, "AddtlQtyForExstgScties", obj.getAddtlQtyForExstgScties());
        if (obj.getNewToOd() != null) write_RatioFormat18Choice1(w, "NewToOd", obj.getNewToOd());
        w.writeEndElement();
    }

    private static void write_RatioFormat17Choice1(XMLStreamWriter w, String tag, RatioFormat17Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQtyToQty() != null) write_QuantityToQuantityRatio11(w, "QtyToQty", obj.getQtyToQty());
        if (obj.getNotSpcfdRate() != null) writeLeaf(w, "NotSpcfdRate", obj.getNotSpcfdRate().value());
        if (obj.getAmtToAmt() != null) write_AmountToAmountRatio21(w, "AmtToAmt", obj.getAmtToAmt());
        w.writeEndElement();
    }

    private static void write_QuantityToQuantityRatio11(XMLStreamWriter w, String tag, QuantityToQuantityRatio11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty1() != null) writeLeaf(w, "Qty1", obj.getQty1().toString());
        if (obj.getQty2() != null) writeLeaf(w, "Qty2", obj.getQty2().toString());
        w.writeEndElement();
    }

    private static void write_AmountToAmountRatio21(XMLStreamWriter w, String tag, AmountToAmountRatio21 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt1() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt1", obj.getAmt1());
        if (obj.getAmt2() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt2", obj.getAmt2());
        w.writeEndElement();
    }

    private static void write_RestrictedFINActiveCurrencyAnd13DecimalAmount(XMLStreamWriter w, String tag, RestrictedFINActiveCurrencyAnd13DecimalAmount obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCcy() != null) w.writeAttribute("Ccy", obj.getCcy());
        w.writeCharacters(obj.getValue().toString());
        w.writeEndElement();
    }

    private static void write_RatioFormat18Choice1(XMLStreamWriter w, String tag, RatioFormat18Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQtyToQty() != null) write_QuantityToQuantityRatio11(w, "QtyToQty", obj.getQtyToQty());
        if (obj.getNotSpcfdRate() != null) writeLeaf(w, "NotSpcfdRate", obj.getNotSpcfdRate().value());
        if (obj.getAmtToAmt() != null) write_AmountToAmountRatio21(w, "AmtToAmt", obj.getAmtToAmt());
        if (obj.getAmtToQty() != null) write_AmountAndQuantityRatio41(w, "AmtToQty", obj.getAmtToQty());
        if (obj.getQtyToAmt() != null) write_AmountAndQuantityRatio41(w, "QtyToAmt", obj.getQtyToAmt());
        w.writeEndElement();
    }

    private static void write_AmountAndQuantityRatio41(XMLStreamWriter w, String tag, AmountAndQuantityRatio41 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        if (obj.getQty() != null) writeLeaf(w, "Qty", obj.getQty().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionPrice821(XMLStreamWriter w, String tag, CorporateActionPrice821 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCshInLieuOfShrPric() != null) write_PriceFormat74Choice1(w, "CshInLieuOfShrPric", obj.getCshInLieuOfShrPric());
        w.writeEndElement();
    }

    private static void write_PriceFormat74Choice1(XMLStreamWriter w, String tag, PriceFormat74Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPric() != null) write_AmountPrice31(w, "AmtPric", obj.getAmtPric());
        if (obj.getNotSpcfdPric() != null) writeLeaf(w, "NotSpcfdPric", obj.getNotSpcfdPric().value());
        w.writeEndElement();
    }

    private static void write_AmountPrice31(XMLStreamWriter w, String tag, AmountPrice31 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricTp() != null) writeLeaf(w, "AmtPricTp", obj.getAmtPricTp().value());
        if (obj.getPricVal() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "PricVal", obj.getPricVal());
        w.writeEndElement();
    }

    private static void write_CashOption1041(XMLStreamWriter w, String tag, CashOption1041 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getAmtDtls() != null) write_CorporateActionAmounts721(w, "AmtDtls", obj.getAmtDtls());
        if (obj.getDtDtls() != null) write_CorporateActionDate841(w, "DtDtls", obj.getDtDtls());
        if (obj.getRateAndAmtDtls() != null) write_Rate421(w, "RateAndAmtDtls", obj.getRateAndAmtDtls());
        if (obj.getPricDtls() != null) write_PriceDetails381(w, "PricDtls", obj.getPricDtls());
        w.writeEndElement();
    }

    private static void write_CorporateActionAmounts721(XMLStreamWriter w, String tag, CorporateActionAmounts721 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getNetAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "NetAmt", obj.getNetAmt());
        if (obj.getSlctnFees() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "SlctnFees", obj.getSlctnFees());
        if (obj.getCshInLieuOfShr() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "CshInLieuOfShr", obj.getCshInLieuOfShr());
        if (obj.getCptlGn() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "CptlGn", obj.getCptlGn());
        if (obj.getIntrstAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "IntrstAmt", obj.getIntrstAmt());
        if (obj.getEntitldAmt() != null) write_RestrictedFINActiveCurrencyAndAmount1(w, "EntitldAmt", obj.getEntitldAmt());
        if (obj.getAcrdIntrstAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "AcrdIntrstAmt", obj.getAcrdIntrstAmt());
        if (obj.getDmdAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "DmdAmt", obj.getDmdAmt());
        w.writeEndElement();
    }

    private static void write_RestrictedFINActiveCurrencyAndAmount(XMLStreamWriter w, String tag, RestrictedFINActiveCurrencyAndAmount obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCcy() != null) w.writeAttribute("Ccy", obj.getCcy());
        w.writeCharacters(obj.getValue().toString());
        w.writeEndElement();
    }

    private static void write_RestrictedFINActiveCurrencyAndAmount1(XMLStreamWriter w, String tag, RestrictedFINActiveCurrencyAndAmount1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCcy() != null) w.writeAttribute("Ccy", obj.getCcy());
        w.writeCharacters(obj.getValue().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionDate841(XMLStreamWriter w, String tag, CorporateActionDate841 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPmtDt() != null) write_DateFormat30Choice3(w, "PmtDt", obj.getPmtDt());
        if (obj.getEarlstPmtDt() != null) write_DateFormat30Choice2(w, "EarlstPmtDt", obj.getEarlstPmtDt());
        w.writeEndElement();
    }

    private static void write_Rate421(XMLStreamWriter w, String tag, Rate421 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        for (GrossDividendRateFormat38Choice1 item : obj.getGrssDstrbtnRate()) write_GrossDividendRateFormat38Choice1(w, "GrssDstrbtnRate", item);
        for (InterestRateUsedForPaymentFormat11Choice1 item : obj.getGrssIntrstRateUsdForPmt()) write_InterestRateUsedForPaymentFormat11Choice1(w, "GrssIntrstRateUsdForPmt", item);
        for (NetDividendRateFormat39Choice1 item : obj.getNetDstrbtnRate()) write_NetDividendRateFormat39Choice1(w, "NetDstrbtnRate", item);
        if (obj.getTaxCdtRate() != null) write_RateFormat26Choice1(w, "TaxCdtRate", obj.getTaxCdtRate());
        for (RateAndAmountFormat61Choice1 item : obj.getDmdRate()) write_RateAndAmountFormat61Choice1(w, "DmdRate", item);
        w.writeEndElement();
    }

    private static void write_GrossDividendRateFormat38Choice1(XMLStreamWriter w, String tag, GrossDividendRateFormat38Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTpAndAmtAndRateSts() != null) write_RateTypeAndAmountAndStatus571(w, "RateTpAndAmtAndRateSts", obj.getRateTpAndAmtAndRateSts());
        if (obj.getNotSpcfdRate() != null) writeLeaf(w, "NotSpcfdRate", obj.getNotSpcfdRate().value());
        w.writeEndElement();
    }

    private static void write_RateTypeAndAmountAndStatus571(XMLStreamWriter w, String tag, RateTypeAndAmountAndStatus571 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTp() != null) write_RateType78Choice1(w, "RateTp", obj.getRateTp());
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_RateType78Choice1(XMLStreamWriter w, String tag, RateType78Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_InterestRateUsedForPaymentFormat11Choice1(XMLStreamWriter w, String tag, InterestRateUsedForPaymentFormat11Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTpAndAmtAndRateSts() != null) write_RateTypeAndAmountAndStatus241(w, "RateTpAndAmtAndRateSts", obj.getRateTpAndAmtAndRateSts());
        if (obj.getNotSpcfdRate() != null) writeLeaf(w, "NotSpcfdRate", obj.getNotSpcfdRate().value());
        w.writeEndElement();
    }

    private static void write_RateTypeAndAmountAndStatus241(XMLStreamWriter w, String tag, RateTypeAndAmountAndStatus241 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTp() != null) write_RateType33Choice1(w, "RateTp", obj.getRateTp());
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_RateType33Choice1(XMLStreamWriter w, String tag, RateType33Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_NetDividendRateFormat39Choice1(XMLStreamWriter w, String tag, NetDividendRateFormat39Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        if (obj.getNotSpcfdRate() != null) writeLeaf(w, "NotSpcfdRate", obj.getNotSpcfdRate().value());
        w.writeEndElement();
    }

    private static void write_RateFormat26Choice1(XMLStreamWriter w, String tag, RateFormat26Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRate() != null) writeLeaf(w, "Rate", obj.getRate().toString());
        if (obj.getNotSpcfdRate() != null) writeLeaf(w, "NotSpcfdRate", obj.getNotSpcfdRate().value());
        w.writeEndElement();
    }

    private static void write_RateAndAmountFormat61Choice1(XMLStreamWriter w, String tag, RateAndAmountFormat61Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        if (obj.getNotSpcfdRate() != null) writeLeaf(w, "NotSpcfdRate", obj.getNotSpcfdRate().value());
        w.writeEndElement();
    }

    private static void write_PriceDetails381(XMLStreamWriter w, String tag, PriceDetails381 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getGncCshPricPdPerPdct() != null) write_PriceFormat73Choice1(w, "GncCshPricPdPerPdct", obj.getGncCshPricPdPerPdct());
        if (obj.getGncCshPricRcvdPerPdct() != null) write_PriceFormat72Choice1(w, "GncCshPricRcvdPerPdct", obj.getGncCshPricRcvdPerPdct());
        w.writeEndElement();
    }

    private static void write_PriceFormat73Choice1(XMLStreamWriter w, String tag, PriceFormat73Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPric() != null) write_AmountPrice31(w, "AmtPric", obj.getAmtPric());
        if (obj.getNotSpcfdPric() != null) writeLeaf(w, "NotSpcfdPric", obj.getNotSpcfdPric().value());
        w.writeEndElement();
    }

    private static void write_PriceFormat72Choice1(XMLStreamWriter w, String tag, PriceFormat72Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getNotSpcfdPric() != null) writeLeaf(w, "NotSpcfdPric", obj.getNotSpcfdPric().value());
        if (obj.getAmtPricPerFinInstrmQty() != null) write_AmountPricePerFinancialInstrumentQuantity101(w, "AmtPricPerFinInstrmQty", obj.getAmtPricPerFinInstrmQty());
        w.writeEndElement();
    }

    private static void write_AmountPricePerFinancialInstrumentQuantity101(XMLStreamWriter w, String tag, AmountPricePerFinancialInstrumentQuantity101 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricTp() != null) writeLeaf(w, "AmtPricTp", obj.getAmtPricTp().value());
        if (obj.getPricVal() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "PricVal", obj.getPricVal());
        if (obj.getFinInstrmQty() != null) write_FinancialInstrumentQuantity33Choice3(w, "FinInstrmQty", obj.getFinInstrmQty());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity33Choice3(XMLStreamWriter w, String tag, FinancialInstrumentQuantity33Choice3 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        if (obj.getDgtlTknUnit() != null) writeLeaf(w, "DgtlTknUnit", obj.getDgtlTknUnit().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionNarrative571(XMLStreamWriter w, String tag, CorporateActionNarrative571 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAddtlTxt() != null) write_UpdatedAdditionalInformation181(w, "AddtlTxt", obj.getAddtlTxt());
        if (obj.getNrrtvVrsn() != null) write_UpdatedAdditionalInformation181(w, "NrrtvVrsn", obj.getNrrtvVrsn());
        if (obj.getInfConds() != null) write_UpdatedAdditionalInformation171(w, "InfConds", obj.getInfConds());
        if (obj.getInfToCmplyWth() != null) write_UpdatedAdditionalInformation171(w, "InfToCmplyWth", obj.getInfToCmplyWth());
        if (obj.getSctyRstrctn() != null) write_UpdatedAdditionalInformation171(w, "SctyRstrctn", obj.getSctyRstrctn());
        if (obj.getTaxtnConds() != null) write_UpdatedAdditionalInformation171(w, "TaxtnConds", obj.getTaxtnConds());
        if (obj.getDsclmr() != null) write_UpdatedAdditionalInformation171(w, "Dsclmr", obj.getDsclmr());
        if (obj.getCertfctnBrkdwn() != null) write_UpdatedAdditionalInformation171(w, "CertfctnBrkdwn", obj.getCertfctnBrkdwn());
        w.writeEndElement();
    }

    private static void write_UpdatedAdditionalInformation181(XMLStreamWriter w, String tag, UpdatedAdditionalInformation181 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAddtlInf() != null) writeLeaf(w, "AddtlInf", obj.getAddtlInf());
        w.writeEndElement();
    }

    private static void write_UpdatedAdditionalInformation171(XMLStreamWriter w, String tag, UpdatedAdditionalInformation171 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        for (String item : obj.getAddtlInf()) writeLeaf(w, "AddtlInf", item);
        w.writeEndElement();
    }

    private static void write_CorporateActionNarrative561(XMLStreamWriter w, String tag, CorporateActionNarrative561 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAddtlTxt() != null) write_UpdatedAdditionalInformation171(w, "AddtlTxt", obj.getAddtlTxt());
        if (obj.getNrrtvVrsn() != null) write_UpdatedAdditionalInformation171(w, "NrrtvVrsn", obj.getNrrtvVrsn());
        if (obj.getPrcgTxtForNxtIntrmy() != null) write_UpdatedAdditionalInformation171(w, "PrcgTxtForNxtIntrmy", obj.getPrcgTxtForNxtIntrmy());
        w.writeEndElement();
    }

    private static void write_SupplementaryData11(XMLStreamWriter w, String tag, SupplementaryData11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getEnvlp() != null) write_SupplementaryDataEnvelope1(w, "Envlp", obj.getEnvlp());
        w.writeEndElement();
    }

    private static void write_SupplementaryDataEnvelope1(XMLStreamWriter w, String tag, SupplementaryDataEnvelope1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAny() != null) writeLeaf(w, "SplmtryInfo", String.valueOf(obj.getAny()));
        w.writeEndElement();
    }

    private static void writeLeaf(XMLStreamWriter w, String tag, String text) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeCharacters(text);
        w.writeEndElement();
    }
}
