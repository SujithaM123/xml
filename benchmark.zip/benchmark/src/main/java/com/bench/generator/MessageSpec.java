package com.bench.generator;

/**
 * Describes one of the 4 benchmark message types: its XSD file, target namespace, root
 * payload element, and the short key used for sample folders / JMH @Param values.
 */
public record MessageSpec(String typeKey, String xsdFileName, String targetNamespace, String rootElementLocalName) {

    public static final MessageSpec CAPA_SEEV035 = new MessageSpec(
            "capa_seev035", "SR_2025_Corporate_Action_CAPA_seev_035_001_16.xsd",
            "urn:iso:std:iso:20022:tech:xsd:seev.035.001.16", "Document");

    public static final MessageSpec CAPA_SUPL009 = new MessageSpec(
            "capa_supl009", "SR_2025_Corporate_Action_CAPA_Extension_supl_009_001_11.xsd",
            "urn:iso:std:iso:20022:tech:xsd:supl.009.001.11", "Document");

    public static final MessageSpec CACO_SEEV036 = new MessageSpec(
            "caco_seev036", "SR_2025_Corporate_Action_CACO_seev_036_001_16.xsd",
            "urn:iso:std:iso:20022:tech:xsd:seev.036.001.16", "Document");

    public static final MessageSpec CACO_SUPL011 = new MessageSpec(
            "caco_supl011", "SR_2025_Corporate_Action_CACO_Extension_supl_011_001_11.xsd",
            "urn:iso:std:iso:20022:tech:xsd:supl.011.001.11", "Document");

    public static final MessageSpec[] ALL = {CAPA_SEEV035, CAPA_SUPL009, CACO_SEEV036, CACO_SUPL011};
}
