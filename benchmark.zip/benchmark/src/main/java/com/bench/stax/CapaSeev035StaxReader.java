package com.bench.stax;

import com.bench.capa.seev035.*;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.datatype.DatatypeFactory;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.BigInteger;

/** Hand-written-style StAX reader for CapaSeev035 (generated once from the xjc POJOs; no reflection or JAXB unmarshalling at runtime). */
public final class CapaSeev035StaxReader {

    private static final XMLInputFactory INPUT_FACTORY = XMLInputFactory.newFactory();
    private static final DatatypeFactory DATATYPE_FACTORY;
    static {
        try {
            DATATYPE_FACTORY = DatatypeFactory.newInstance();
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private CapaSeev035StaxReader() {
    }

    public static Document read(byte[] xml) throws XMLStreamException {
        XMLStreamReader r = INPUT_FACTORY.createXMLStreamReader(new ByteArrayInputStream(xml));
        r.nextTag();
        Document doc = read_Document(r);
        r.close();
        return doc;
    }

    private static Document read_Document(XMLStreamReader r) throws XMLStreamException {
        Document obj = new Document();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CorpActnMvmntPrlimryAdvc": obj.setCorpActnMvmntPrlimryAdvc(read_CorporateActionMovementPreliminaryAdviceV16(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionMovementPreliminaryAdviceV16 read_CorporateActionMovementPreliminaryAdviceV16(XMLStreamReader r) throws XMLStreamException {
        CorporateActionMovementPreliminaryAdviceV16 obj = new CorporateActionMovementPreliminaryAdviceV16();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Pgntn": obj.setPgntn(read_Pagination1(r)); break;
                case "MvmntPrlimryAdvcGnlInf": obj.setMvmntPrlimryAdvcGnlInf(read_CorporateActionPreliminaryAdviceType41(r)); break;
                case "PrvsMvmntPrlimryAdvcId": obj.setPrvsMvmntPrlimryAdvcId(read_DocumentIdentification311(r)); break;
                case "MvmntConfId": obj.setMvmntConfId(read_DocumentIdentification311(r)); break;
                case "RvslRsn": obj.setRvslRsn(read_CorporateActionReversalReason81(r)); break;
                case "CorpActnGnlInf": obj.setCorpActnGnlInf(read_CorporateActionGeneralInformation1781(r)); break;
                case "AcctDtls": obj.setAcctDtls(read_AccountIdentification70Choice1(r)); break;
                case "CorpActnDtls": obj.setCorpActnDtls(read_CorporateAction691(r)); break;
                case "CorpActnMvmntDtls": obj.getCorpActnMvmntDtls().add(read_CorporateActionOption2321(r)); break;
                case "AddtlInf": obj.setAddtlInf(read_CorporateActionNarrative561(r)); break;
                case "SplmtryData": obj.getSplmtryData().add(read_SupplementaryData11(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Pagination1 read_Pagination1(XMLStreamReader r) throws XMLStreamException {
        Pagination1 obj = new Pagination1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PgNb": obj.setPgNb(r.getElementText()); break;
                case "LastPgInd": obj.setLastPgInd(Boolean.parseBoolean(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionPreliminaryAdviceType41 read_CorporateActionPreliminaryAdviceType41(XMLStreamReader r) throws XMLStreamException {
        CorporateActionPreliminaryAdviceType41 obj = new CorporateActionPreliminaryAdviceType41();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "MvmntPrlimryAdvcId": obj.setMvmntPrlimryAdvcId(r.getElementText()); break;
                case "Tp": obj.setTp(CorporateActionPreliminaryAdviceType1Code.fromValue(r.getElementText())); break;
                case "Fctn": obj.setFctn(CorporateActionMovementPreliminaryAdviceFunction1Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DocumentIdentification311 read_DocumentIdentification311(XMLStreamReader r) throws XMLStreamException {
        DocumentIdentification311 obj = new DocumentIdentification311();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Id": obj.setId(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionReversalReason81 read_CorporateActionReversalReason81(XMLStreamReader r) throws XMLStreamException {
        CorporateActionReversalReason81 obj = new CorporateActionReversalReason81();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Rsn": obj.setRsn(read_CorporateActionReversalReason10Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionReversalReason10Choice1 read_CorporateActionReversalReason10Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionReversalReason10Choice1 obj = new CorporateActionReversalReason10Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionReversalReason3Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionGeneralInformation1781 read_CorporateActionGeneralInformation1781(XMLStreamReader r) throws XMLStreamException {
        CorporateActionGeneralInformation1781 obj = new CorporateActionGeneralInformation1781();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CorpActnEvtId": obj.setCorpActnEvtId(r.getElementText()); break;
                case "OffclCorpActnEvtId": obj.setOffclCorpActnEvtId(r.getElementText()); break;
                case "EvtPrcgTp": obj.setEvtPrcgTp(read_CorporateActionEventProcessingType2Choice1(r)); break;
                case "EvtTp": obj.setEvtTp(read_CorporateActionEventType108Choice1(r)); break;
                case "MndtryVlntryEvtTp": obj.setMndtryVlntryEvtTp(read_CorporateActionMandatoryVoluntary3Choice1(r)); break;
                case "UndrlygScty": obj.setUndrlygScty(read_FinancialInstrumentAttributes1281(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionEventProcessingType2Choice1 read_CorporateActionEventProcessingType2Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionEventProcessingType2Choice1 obj = new CorporateActionEventProcessingType2Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionEventProcessingType1Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionEventType108Choice1 read_CorporateActionEventType108Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionEventType108Choice1 obj = new CorporateActionEventType108Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionEventType36Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionMandatoryVoluntary3Choice1 read_CorporateActionMandatoryVoluntary3Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionMandatoryVoluntary3Choice1 obj = new CorporateActionMandatoryVoluntary3Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionMandatoryVoluntary1Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentAttributes1281 read_FinancialInstrumentAttributes1281(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentAttributes1281 obj = new FinancialInstrumentAttributes1281();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "FinInstrmId": obj.setFinInstrmId(read_SecurityIdentification191(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SecurityIdentification191 read_SecurityIdentification191(XMLStreamReader r) throws XMLStreamException {
        SecurityIdentification191 obj = new SecurityIdentification191();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ISIN": obj.setISIN(r.getElementText()); break;
                case "OthrId": obj.setOthrId(read_OtherIdentification11(r)); break;
                case "Desc": obj.setDesc(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static OtherIdentification11 read_OtherIdentification11(XMLStreamReader r) throws XMLStreamException {
        OtherIdentification11 obj = new OtherIdentification11();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Id": obj.setId(r.getElementText()); break;
                case "Tp": obj.setTp(read_IdentificationSource3Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static IdentificationSource3Choice1 read_IdentificationSource3Choice1(XMLStreamReader r) throws XMLStreamException {
        IdentificationSource3Choice1 obj = new IdentificationSource3Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(r.getElementText()); break;
                case "Prtry": obj.setPrtry(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AccountIdentification70Choice1 read_AccountIdentification70Choice1(XMLStreamReader r) throws XMLStreamException {
        AccountIdentification70Choice1 obj = new AccountIdentification70Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AcctsListAndBalDtls": obj.setAcctsListAndBalDtls(read_AccountAndBalance591(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AccountAndBalance591 read_AccountAndBalance591(XMLStreamReader r) throws XMLStreamException {
        AccountAndBalance591 obj = new AccountAndBalance591();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "SfkpgAcct": obj.setSfkpgAcct(r.getElementText()); break;
                case "Bal": obj.setBal(read_CorporateActionBalanceDetails431(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionBalanceDetails431 read_CorporateActionBalanceDetails431(XMLStreamReader r) throws XMLStreamException {
        CorporateActionBalanceDetails431 obj = new CorporateActionBalanceDetails431();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "TtlElgblBal": obj.setTtlElgblBal(read_TotalEligibleBalanceFormat101(r)); break;
                case "BrrwdBal": obj.setBrrwdBal(read_BalanceFormat11Choice1(r)); break;
                case "CollInBal": obj.setCollInBal(read_BalanceFormat11Choice1(r)); break;
                case "CollOutBal": obj.setCollOutBal(read_BalanceFormat11Choice1(r)); break;
                case "OnLnBal": obj.setOnLnBal(read_BalanceFormat11Choice1(r)); break;
                case "PdgDlvryBal": obj.setPdgDlvryBal(read_BalanceFormat12Choice1(r)); break;
                case "PdgRctBal": obj.setPdgRctBal(read_BalanceFormat12Choice1(r)); break;
                case "SttlmPosBal": obj.setSttlmPosBal(read_BalanceFormat12Choice1(r)); break;
                case "OblgtdBal": obj.setOblgtdBal(read_BalanceFormat11Choice1(r)); break;
                case "UinstdBal": obj.setUinstdBal(read_BalanceFormat11Choice2(r)); break;
                case "InstdBal": obj.setInstdBal(read_BalanceFormat11Choice3(r)); break;
                case "AfctdBal": obj.setAfctdBal(read_BalanceFormat11Choice4(r)); break;
                case "UafctdBal": obj.setUafctdBal(read_BalanceFormat11Choice4(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static TotalEligibleBalanceFormat101 read_TotalEligibleBalanceFormat101(XMLStreamReader r) throws XMLStreamException {
        TotalEligibleBalanceFormat101 obj = new TotalEligibleBalanceFormat101();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_Quantity49Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity49Choice1 read_Quantity49Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity49Choice1 obj = new Quantity49Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "QtyChc": obj.setQtyChc(read_Quantity50Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity50Choice1 read_Quantity50Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity50Choice1 obj = new Quantity50Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "SgndQty": obj.setSgndQty(read_SignedQuantityFormat101(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat101 read_SignedQuantityFormat101(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat101 obj = new SignedQuantityFormat101();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code.fromValue(r.getElementText())); break;
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentQuantity33Choice1 read_FinancialInstrumentQuantity33Choice1(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentQuantity33Choice1 obj = new FinancialInstrumentQuantity33Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Unit": obj.setUnit(new BigDecimal(r.getElementText())); break;
                case "FaceAmt": obj.setFaceAmt(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat11Choice1 read_BalanceFormat11Choice1(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat11Choice1 obj = new BalanceFormat11Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat111(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat111 read_SignedQuantityFormat111(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat111 obj = new SignedQuantityFormat111();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code.fromValue(r.getElementText())); break;
                case "QtyChc": obj.setQtyChc(read_Quantity48Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity48Choice1 read_Quantity48Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity48Choice1 obj = new Quantity48Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat12Choice1 read_BalanceFormat12Choice1(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat12Choice1 obj = new BalanceFormat12Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat111(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat11Choice2 read_BalanceFormat11Choice2(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat11Choice2 obj = new BalanceFormat11Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat112(r)); break;
                case "ElgblBal": obj.setElgblBal(read_SignedQuantityFormat101(r)); break;
                case "NotElgblBal": obj.setNotElgblBal(read_SignedQuantityFormat102(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat112 read_SignedQuantityFormat112(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat112 obj = new SignedQuantityFormat112();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code.fromValue(r.getElementText())); break;
                case "QtyChc": obj.setQtyChc(read_Quantity48Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity48Choice2 read_Quantity48Choice2(XMLStreamReader r) throws XMLStreamException {
        Quantity48Choice2 obj = new Quantity48Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                case "PrtryQty": obj.setPrtryQty(read_ProprietaryQuantity81(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static ProprietaryQuantity81 read_ProprietaryQuantity81(XMLStreamReader r) throws XMLStreamException {
        ProprietaryQuantity81 obj = new ProprietaryQuantity81();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty": obj.setQty(new BigDecimal(r.getElementText())); break;
                case "QtyTp": obj.setQtyTp(r.getElementText()); break;
                case "Issr": obj.setIssr(r.getElementText()); break;
                case "SchmeNm": obj.setSchmeNm(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat102 read_SignedQuantityFormat102(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat102 obj = new SignedQuantityFormat102();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code.fromValue(r.getElementText())); break;
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentQuantity33Choice2 read_FinancialInstrumentQuantity33Choice2(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentQuantity33Choice2 obj = new FinancialInstrumentQuantity33Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Unit": obj.setUnit(new BigDecimal(r.getElementText())); break;
                case "FaceAmt": obj.setFaceAmt(new BigDecimal(r.getElementText())); break;
                case "AmtsdVal": obj.setAmtsdVal(new BigDecimal(r.getElementText())); break;
                case "DgtlTknUnit": obj.setDgtlTknUnit(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat11Choice3 read_BalanceFormat11Choice3(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat11Choice3 obj = new BalanceFormat11Choice3();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat112(r)); break;
                case "ElgblBal": obj.setElgblBal(read_SignedQuantityFormat101(r)); break;
                case "NotElgblBal": obj.setNotElgblBal(read_SignedQuantityFormat101(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat11Choice4 read_BalanceFormat11Choice4(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat11Choice4 obj = new BalanceFormat11Choice4();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat113(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat113 read_SignedQuantityFormat113(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat113 obj = new SignedQuantityFormat113();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code1.fromValue(r.getElementText())); break;
                case "QtyChc": obj.setQtyChc(read_Quantity48Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateAction691 read_CorporateAction691(XMLStreamReader r) throws XMLStreamException {
        CorporateAction691 obj = new CorporateAction691();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "DtDtls": obj.setDtDtls(read_CorporateActionDate851(r)); break;
                case "SctiesQty": obj.setSctiesQty(read_CorporateActionQuantity121(r)); break;
                case "EvtStag": obj.setEvtStag(read_CorporateActionEventStageFormat14Choice1(r)); break;
                case "AddtlBizPrcInd": obj.getAddtlBizPrcInd().add(read_AdditionalBusinessProcessFormat18Choice1(r)); break;
                case "IntrmdtSctiesDstrbtnTp": obj.setIntrmdtSctiesDstrbtnTp(read_IntermediateSecuritiesDistributionTypeFormat15Choice1(r)); break;
                case "LtryTp": obj.setLtryTp(read_LotteryTypeFormat4Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionDate851 read_CorporateActionDate851(XMLStreamReader r) throws XMLStreamException {
        CorporateActionDate851 obj = new CorporateActionDate851();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RcrdDt": obj.setRcrdDt(read_DateFormat30Choice1(r)); break;
                case "ExDvddDt": obj.setExDvddDt(read_DateFormat30Choice1(r)); break;
                case "LtryDt": obj.setLtryDt(read_DateFormat30Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateFormat30Choice1 read_DateFormat30Choice1(XMLStreamReader r) throws XMLStreamException {
        DateFormat30Choice1 obj = new DateFormat30Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Dt": obj.setDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateFormat30Choice2 read_DateFormat30Choice2(XMLStreamReader r) throws XMLStreamException {
        DateFormat30Choice2 obj = new DateFormat30Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Dt": obj.setDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                case "DtCd": obj.setDtCd(read_DateCode19Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateCode19Choice1 read_DateCode19Choice1(XMLStreamReader r) throws XMLStreamException {
        DateCode19Choice1 obj = new DateCode19Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(DateType8Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionQuantity121 read_CorporateActionQuantity121(XMLStreamReader r) throws XMLStreamException {
        CorporateActionQuantity121 obj = new CorporateActionQuantity121();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "BaseDnmtn": obj.setBaseDnmtn(read_FinancialInstrumentQuantity35Choice1(r)); break;
                case "IncrmtlDnmtn": obj.setIncrmtlDnmtn(read_FinancialInstrumentQuantity35Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentQuantity35Choice1 read_FinancialInstrumentQuantity35Choice1(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentQuantity35Choice1 obj = new FinancialInstrumentQuantity35Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Unit": obj.setUnit(new BigDecimal(r.getElementText())); break;
                case "FaceAmt": obj.setFaceAmt(new BigDecimal(r.getElementText())); break;
                case "Cd": obj.setCd(Quantity5Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionEventStageFormat14Choice1 read_CorporateActionEventStageFormat14Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionEventStageFormat14Choice1 obj = new CorporateActionEventStageFormat14Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionEventStage4Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AdditionalBusinessProcessFormat18Choice1 read_AdditionalBusinessProcessFormat18Choice1(XMLStreamReader r) throws XMLStreamException {
        AdditionalBusinessProcessFormat18Choice1 obj = new AdditionalBusinessProcessFormat18Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(AdditionalBusinessProcess10Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static IntermediateSecuritiesDistributionTypeFormat15Choice1 read_IntermediateSecuritiesDistributionTypeFormat15Choice1(XMLStreamReader r) throws XMLStreamException {
        IntermediateSecuritiesDistributionTypeFormat15Choice1 obj = new IntermediateSecuritiesDistributionTypeFormat15Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(IntermediateSecurityDistributionType5Code1.fromValue(r.getElementText())); break;
                case "Prtry": obj.setPrtry(read_GenericIdentification301(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static GenericIdentification301 read_GenericIdentification301(XMLStreamReader r) throws XMLStreamException {
        GenericIdentification301 obj = new GenericIdentification301();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Id": obj.setId(r.getElementText()); break;
                case "Issr": obj.setIssr(r.getElementText()); break;
                case "SchmeNm": obj.setSchmeNm(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static LotteryTypeFormat4Choice1 read_LotteryTypeFormat4Choice1(XMLStreamReader r) throws XMLStreamException {
        LotteryTypeFormat4Choice1 obj = new LotteryTypeFormat4Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(LotteryType1Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionOption2321 read_CorporateActionOption2321(XMLStreamReader r) throws XMLStreamException {
        CorporateActionOption2321 obj = new CorporateActionOption2321();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "OptnNb": obj.setOptnNb(r.getElementText()); break;
                case "OptnTp": obj.setOptnTp(read_CorporateActionOption37Choice1(r)); break;
                case "CcyOptn": obj.setCcyOptn(r.getElementText()); break;
                case "DfltPrcgOrStgInstr": obj.setDfltPrcgOrStgInstr(read_DefaultProcessingOrStandingInstruction2Choice1(r)); break;
                case "SctiesMvmntDtls": obj.getSctiesMvmntDtls().add(read_SecuritiesOption1181(r)); break;
                case "CshMvmntDtls": obj.getCshMvmntDtls().add(read_CashOption1041(r)); break;
                case "AddtlInf": obj.setAddtlInf(read_CorporateActionNarrative571(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionOption37Choice1 read_CorporateActionOption37Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionOption37Choice1 obj = new CorporateActionOption37Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionOption15Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DefaultProcessingOrStandingInstruction2Choice1 read_DefaultProcessingOrStandingInstruction2Choice1(XMLStreamReader r) throws XMLStreamException {
        DefaultProcessingOrStandingInstruction2Choice1 obj = new DefaultProcessingOrStandingInstruction2Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "DfltOptnInd": obj.setDfltOptnInd(Boolean.parseBoolean(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SecuritiesOption1181 read_SecuritiesOption1181(XMLStreamReader r) throws XMLStreamException {
        SecuritiesOption1181 obj = new SecuritiesOption1181();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "SctyDtls": obj.setSctyDtls(read_FinancialInstrumentAttributes1291(r)); break;
                case "CdtDbtInd": obj.setCdtDbtInd(CreditDebitCode.fromValue(r.getElementText())); break;
                case "TempFinInstrmInd": obj.setTempFinInstrmInd(read_TemporaryFinancialInstrumentIndicator3Choice1(r)); break;
                case "NewSctiesIssncInd": obj.setNewSctiesIssncInd(NewSecuritiesIssuanceType5Code1.fromValue(r.getElementText())); break;
                case "EntitldQty": obj.setEntitldQty(read_Quantity51Choice1(r)); break;
                case "DtDtls": obj.setDtDtls(read_SecurityDate201(r)); break;
                case "RateDtls": obj.setRateDtls(read_CorporateActionRate1231(r)); break;
                case "PricDtls": obj.setPricDtls(read_CorporateActionPrice821(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentAttributes1291 read_FinancialInstrumentAttributes1291(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentAttributes1291 obj = new FinancialInstrumentAttributes1291();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "FinInstrmId": obj.setFinInstrmId(read_SecurityIdentification192(r)); break;
                case "MtrtyDt": obj.setMtrtyDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SecurityIdentification192 read_SecurityIdentification192(XMLStreamReader r) throws XMLStreamException {
        SecurityIdentification192 obj = new SecurityIdentification192();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ISIN": obj.setISIN(r.getElementText()); break;
                case "OthrId": obj.getOthrId().add(read_OtherIdentification11(r)); break;
                case "Desc": obj.setDesc(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static TemporaryFinancialInstrumentIndicator3Choice1 read_TemporaryFinancialInstrumentIndicator3Choice1(XMLStreamReader r) throws XMLStreamException {
        TemporaryFinancialInstrumentIndicator3Choice1 obj = new TemporaryFinancialInstrumentIndicator3Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "TempInd": obj.setTempInd(Boolean.parseBoolean(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity51Choice1 read_Quantity51Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity51Choice1 obj = new Quantity51Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SecurityDate201 read_SecurityDate201(XMLStreamReader r) throws XMLStreamException {
        SecurityDate201 obj = new SecurityDate201();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PmtDt": obj.setPmtDt(read_DateFormat30Choice3(r)); break;
                case "EarlstPmtDt": obj.setEarlstPmtDt(read_DateFormat30Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateFormat30Choice3 read_DateFormat30Choice3(XMLStreamReader r) throws XMLStreamException {
        DateFormat30Choice3 obj = new DateFormat30Choice3();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Dt": obj.setDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                case "DtCd": obj.setDtCd(read_DateCode19Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateCode19Choice2 read_DateCode19Choice2(XMLStreamReader r) throws XMLStreamException {
        DateCode19Choice2 obj = new DateCode19Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(DateType8Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionRate1231 read_CorporateActionRate1231(XMLStreamReader r) throws XMLStreamException {
        CorporateActionRate1231 obj = new CorporateActionRate1231();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AddtlQtyForExstgScties": obj.setAddtlQtyForExstgScties(read_RatioFormat17Choice1(r)); break;
                case "NewToOd": obj.setNewToOd(read_RatioFormat18Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RatioFormat17Choice1 read_RatioFormat17Choice1(XMLStreamReader r) throws XMLStreamException {
        RatioFormat17Choice1 obj = new RatioFormat17Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "QtyToQty": obj.setQtyToQty(read_QuantityToQuantityRatio11(r)); break;
                case "NotSpcfdRate": obj.setNotSpcfdRate(RateValueType7Code.fromValue(r.getElementText())); break;
                case "AmtToAmt": obj.setAmtToAmt(read_AmountToAmountRatio21(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static QuantityToQuantityRatio11 read_QuantityToQuantityRatio11(XMLStreamReader r) throws XMLStreamException {
        QuantityToQuantityRatio11 obj = new QuantityToQuantityRatio11();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty1": obj.setQty1(new BigDecimal(r.getElementText())); break;
                case "Qty2": obj.setQty2(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountToAmountRatio21 read_AmountToAmountRatio21(XMLStreamReader r) throws XMLStreamException {
        AmountToAmountRatio21 obj = new AmountToAmountRatio21();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt1": obj.setAmt1(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "Amt2": obj.setAmt2(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RestrictedFINActiveCurrencyAnd13DecimalAmount read_RestrictedFINActiveCurrencyAnd13DecimalAmount(XMLStreamReader r) throws XMLStreamException {
        RestrictedFINActiveCurrencyAnd13DecimalAmount obj = new RestrictedFINActiveCurrencyAnd13DecimalAmount();
        obj.setCcy(r.getAttributeValue(null, "Ccy"));
        obj.setValue(new BigDecimal(r.getElementText()));
        return obj;
    }

    private static RatioFormat18Choice1 read_RatioFormat18Choice1(XMLStreamReader r) throws XMLStreamException {
        RatioFormat18Choice1 obj = new RatioFormat18Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "QtyToQty": obj.setQtyToQty(read_QuantityToQuantityRatio11(r)); break;
                case "NotSpcfdRate": obj.setNotSpcfdRate(RateValueType7Code.fromValue(r.getElementText())); break;
                case "AmtToAmt": obj.setAmtToAmt(read_AmountToAmountRatio21(r)); break;
                case "AmtToQty": obj.setAmtToQty(read_AmountAndQuantityRatio41(r)); break;
                case "QtyToAmt": obj.setQtyToAmt(read_AmountAndQuantityRatio41(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountAndQuantityRatio41 read_AmountAndQuantityRatio41(XMLStreamReader r) throws XMLStreamException {
        AmountAndQuantityRatio41 obj = new AmountAndQuantityRatio41();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "Qty": obj.setQty(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionPrice821 read_CorporateActionPrice821(XMLStreamReader r) throws XMLStreamException {
        CorporateActionPrice821 obj = new CorporateActionPrice821();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CshInLieuOfShrPric": obj.setCshInLieuOfShrPric(read_PriceFormat74Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat74Choice1 read_PriceFormat74Choice1(XMLStreamReader r) throws XMLStreamException {
        PriceFormat74Choice1 obj = new PriceFormat74Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPric": obj.setAmtPric(read_AmountPrice31(r)); break;
                case "NotSpcfdPric": obj.setNotSpcfdPric(PriceValueType10Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountPrice31 read_AmountPrice31(XMLStreamReader r) throws XMLStreamException {
        AmountPrice31 obj = new AmountPrice31();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricTp": obj.setAmtPricTp(AmountPriceType1Code1.fromValue(r.getElementText())); break;
                case "PricVal": obj.setPricVal(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CashOption1041 read_CashOption1041(XMLStreamReader r) throws XMLStreamException {
        CashOption1041 obj = new CashOption1041();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CdtDbtInd": obj.setCdtDbtInd(CreditDebitCode.fromValue(r.getElementText())); break;
                case "AmtDtls": obj.setAmtDtls(read_CorporateActionAmounts721(r)); break;
                case "DtDtls": obj.setDtDtls(read_CorporateActionDate841(r)); break;
                case "RateAndAmtDtls": obj.setRateAndAmtDtls(read_Rate421(r)); break;
                case "PricDtls": obj.setPricDtls(read_PriceDetails381(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionAmounts721 read_CorporateActionAmounts721(XMLStreamReader r) throws XMLStreamException {
        CorporateActionAmounts721 obj = new CorporateActionAmounts721();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "NetAmt": obj.setNetAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "SlctnFees": obj.setSlctnFees(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "CshInLieuOfShr": obj.setCshInLieuOfShr(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "CptlGn": obj.setCptlGn(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "IntrstAmt": obj.setIntrstAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "EntitldAmt": obj.setEntitldAmt(read_RestrictedFINActiveCurrencyAndAmount1(r)); break;
                case "AcrdIntrstAmt": obj.setAcrdIntrstAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "DmdAmt": obj.setDmdAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RestrictedFINActiveCurrencyAndAmount read_RestrictedFINActiveCurrencyAndAmount(XMLStreamReader r) throws XMLStreamException {
        RestrictedFINActiveCurrencyAndAmount obj = new RestrictedFINActiveCurrencyAndAmount();
        obj.setCcy(r.getAttributeValue(null, "Ccy"));
        obj.setValue(new BigDecimal(r.getElementText()));
        return obj;
    }

    private static RestrictedFINActiveCurrencyAndAmount1 read_RestrictedFINActiveCurrencyAndAmount1(XMLStreamReader r) throws XMLStreamException {
        RestrictedFINActiveCurrencyAndAmount1 obj = new RestrictedFINActiveCurrencyAndAmount1();
        obj.setCcy(r.getAttributeValue(null, "Ccy"));
        obj.setValue(new BigDecimal(r.getElementText()));
        return obj;
    }

    private static CorporateActionDate841 read_CorporateActionDate841(XMLStreamReader r) throws XMLStreamException {
        CorporateActionDate841 obj = new CorporateActionDate841();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PmtDt": obj.setPmtDt(read_DateFormat30Choice3(r)); break;
                case "EarlstPmtDt": obj.setEarlstPmtDt(read_DateFormat30Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Rate421 read_Rate421(XMLStreamReader r) throws XMLStreamException {
        Rate421 obj = new Rate421();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "GrssDstrbtnRate": obj.getGrssDstrbtnRate().add(read_GrossDividendRateFormat38Choice1(r)); break;
                case "GrssIntrstRateUsdForPmt": obj.getGrssIntrstRateUsdForPmt().add(read_InterestRateUsedForPaymentFormat11Choice1(r)); break;
                case "NetDstrbtnRate": obj.getNetDstrbtnRate().add(read_NetDividendRateFormat39Choice1(r)); break;
                case "TaxCdtRate": obj.setTaxCdtRate(read_RateFormat26Choice1(r)); break;
                case "DmdRate": obj.getDmdRate().add(read_RateAndAmountFormat61Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static GrossDividendRateFormat38Choice1 read_GrossDividendRateFormat38Choice1(XMLStreamReader r) throws XMLStreamException {
        GrossDividendRateFormat38Choice1 obj = new GrossDividendRateFormat38Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTpAndAmtAndRateSts": obj.setRateTpAndAmtAndRateSts(read_RateTypeAndAmountAndStatus571(r)); break;
                case "NotSpcfdRate": obj.setNotSpcfdRate(RateType13Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateTypeAndAmountAndStatus571 read_RateTypeAndAmountAndStatus571(XMLStreamReader r) throws XMLStreamException {
        RateTypeAndAmountAndStatus571 obj = new RateTypeAndAmountAndStatus571();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTp": obj.setRateTp(read_RateType78Choice1(r)); break;
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateType78Choice1 read_RateType78Choice1(XMLStreamReader r) throws XMLStreamException {
        RateType78Choice1 obj = new RateType78Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(GrossDividendRateType7Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static InterestRateUsedForPaymentFormat11Choice1 read_InterestRateUsedForPaymentFormat11Choice1(XMLStreamReader r) throws XMLStreamException {
        InterestRateUsedForPaymentFormat11Choice1 obj = new InterestRateUsedForPaymentFormat11Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTpAndAmtAndRateSts": obj.setRateTpAndAmtAndRateSts(read_RateTypeAndAmountAndStatus241(r)); break;
                case "NotSpcfdRate": obj.setNotSpcfdRate(RateType13Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateTypeAndAmountAndStatus241 read_RateTypeAndAmountAndStatus241(XMLStreamReader r) throws XMLStreamException {
        RateTypeAndAmountAndStatus241 obj = new RateTypeAndAmountAndStatus241();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTp": obj.setRateTp(read_RateType33Choice1(r)); break;
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateType33Choice1 read_RateType33Choice1(XMLStreamReader r) throws XMLStreamException {
        RateType33Choice1 obj = new RateType33Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(RateType7Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static NetDividendRateFormat39Choice1 read_NetDividendRateFormat39Choice1(XMLStreamReader r) throws XMLStreamException {
        NetDividendRateFormat39Choice1 obj = new NetDividendRateFormat39Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "NotSpcfdRate": obj.setNotSpcfdRate(RateValueType7Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateFormat26Choice1 read_RateFormat26Choice1(XMLStreamReader r) throws XMLStreamException {
        RateFormat26Choice1 obj = new RateFormat26Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Rate": obj.setRate(new BigDecimal(r.getElementText())); break;
                case "NotSpcfdRate": obj.setNotSpcfdRate(RateValueType7Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateAndAmountFormat61Choice1 read_RateAndAmountFormat61Choice1(XMLStreamReader r) throws XMLStreamException {
        RateAndAmountFormat61Choice1 obj = new RateAndAmountFormat61Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "NotSpcfdRate": obj.setNotSpcfdRate(RateValueType7Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceDetails381 read_PriceDetails381(XMLStreamReader r) throws XMLStreamException {
        PriceDetails381 obj = new PriceDetails381();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "GncCshPricPdPerPdct": obj.setGncCshPricPdPerPdct(read_PriceFormat73Choice1(r)); break;
                case "GncCshPricRcvdPerPdct": obj.setGncCshPricRcvdPerPdct(read_PriceFormat72Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat73Choice1 read_PriceFormat73Choice1(XMLStreamReader r) throws XMLStreamException {
        PriceFormat73Choice1 obj = new PriceFormat73Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPric": obj.setAmtPric(read_AmountPrice31(r)); break;
                case "NotSpcfdPric": obj.setNotSpcfdPric(PriceValueType10Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat72Choice1 read_PriceFormat72Choice1(XMLStreamReader r) throws XMLStreamException {
        PriceFormat72Choice1 obj = new PriceFormat72Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "NotSpcfdPric": obj.setNotSpcfdPric(PriceValueType8Code.fromValue(r.getElementText())); break;
                case "AmtPricPerFinInstrmQty": obj.setAmtPricPerFinInstrmQty(read_AmountPricePerFinancialInstrumentQuantity101(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountPricePerFinancialInstrumentQuantity101 read_AmountPricePerFinancialInstrumentQuantity101(XMLStreamReader r) throws XMLStreamException {
        AmountPricePerFinancialInstrumentQuantity101 obj = new AmountPricePerFinancialInstrumentQuantity101();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricTp": obj.setAmtPricTp(AmountPriceType1Code2.fromValue(r.getElementText())); break;
                case "PricVal": obj.setPricVal(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "FinInstrmQty": obj.setFinInstrmQty(read_FinancialInstrumentQuantity33Choice3(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentQuantity33Choice3 read_FinancialInstrumentQuantity33Choice3(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentQuantity33Choice3 obj = new FinancialInstrumentQuantity33Choice3();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Unit": obj.setUnit(new BigDecimal(r.getElementText())); break;
                case "FaceAmt": obj.setFaceAmt(new BigDecimal(r.getElementText())); break;
                case "DgtlTknUnit": obj.setDgtlTknUnit(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionNarrative571 read_CorporateActionNarrative571(XMLStreamReader r) throws XMLStreamException {
        CorporateActionNarrative571 obj = new CorporateActionNarrative571();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AddtlTxt": obj.setAddtlTxt(read_UpdatedAdditionalInformation181(r)); break;
                case "NrrtvVrsn": obj.setNrrtvVrsn(read_UpdatedAdditionalInformation181(r)); break;
                case "InfConds": obj.setInfConds(read_UpdatedAdditionalInformation171(r)); break;
                case "InfToCmplyWth": obj.setInfToCmplyWth(read_UpdatedAdditionalInformation171(r)); break;
                case "SctyRstrctn": obj.setSctyRstrctn(read_UpdatedAdditionalInformation171(r)); break;
                case "TaxtnConds": obj.setTaxtnConds(read_UpdatedAdditionalInformation171(r)); break;
                case "Dsclmr": obj.setDsclmr(read_UpdatedAdditionalInformation171(r)); break;
                case "CertfctnBrkdwn": obj.setCertfctnBrkdwn(read_UpdatedAdditionalInformation171(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static UpdatedAdditionalInformation181 read_UpdatedAdditionalInformation181(XMLStreamReader r) throws XMLStreamException {
        UpdatedAdditionalInformation181 obj = new UpdatedAdditionalInformation181();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AddtlInf": obj.setAddtlInf(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static UpdatedAdditionalInformation171 read_UpdatedAdditionalInformation171(XMLStreamReader r) throws XMLStreamException {
        UpdatedAdditionalInformation171 obj = new UpdatedAdditionalInformation171();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AddtlInf": obj.getAddtlInf().add(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionNarrative561 read_CorporateActionNarrative561(XMLStreamReader r) throws XMLStreamException {
        CorporateActionNarrative561 obj = new CorporateActionNarrative561();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AddtlTxt": obj.setAddtlTxt(read_UpdatedAdditionalInformation171(r)); break;
                case "NrrtvVrsn": obj.setNrrtvVrsn(read_UpdatedAdditionalInformation171(r)); break;
                case "PrcgTxtForNxtIntrmy": obj.setPrcgTxtForNxtIntrmy(read_UpdatedAdditionalInformation171(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SupplementaryData11 read_SupplementaryData11(XMLStreamReader r) throws XMLStreamException {
        SupplementaryData11 obj = new SupplementaryData11();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Envlp": obj.setEnvlp(read_SupplementaryDataEnvelope1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SupplementaryDataEnvelope1 read_SupplementaryDataEnvelope1(XMLStreamReader r) throws XMLStreamException {
        SupplementaryDataEnvelope1 obj = new SupplementaryDataEnvelope1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                default: obj.setAny(r.getElementText()); break;
            }
        }
        return obj;
    }

    private static void skip(XMLStreamReader r) throws XMLStreamException {
        int depth = 1;
        while (depth > 0) {
            int ev = r.next();
            if (ev == XMLStreamConstants.START_ELEMENT) depth++;
            else if (ev == XMLStreamConstants.END_ELEMENT) depth--;
        }
    }
}
