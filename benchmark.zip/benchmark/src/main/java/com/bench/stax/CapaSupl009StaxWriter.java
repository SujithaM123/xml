package com.bench.stax;

import com.bench.capa.supl009.*;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.ByteArrayOutputStream;

/** Hand-written-style StAX writer for CapaSupl009 (generated once from the xjc POJOs; no reflection or JAXB marshalling at runtime). */
public final class CapaSupl009StaxWriter {

    private static final XMLOutputFactory OUTPUT_FACTORY = XMLOutputFactory.newFactory();

    private CapaSupl009StaxWriter() {
    }

    public static byte[] write(Document doc) throws XMLStreamException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        XMLStreamWriter w = OUTPUT_FACTORY.createXMLStreamWriter(out, "UTF-8");
        w.writeStartDocument("UTF-8", "1.0");
        write_Document(w, "Document", doc);
        w.writeEndDocument();
        w.flush();
        w.close();
        return out.toByteArray();
    }

    private static void write_Document(XMLStreamWriter w, String tag, Document obj) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeDefaultNamespace("urn:iso:std:iso:20022:tech:xsd:supl.009.001.11");
        if (obj.getDTCCCAPASD1() != null) write_DTCCCAPASD1V11(w, "DTCCCAPASD1", obj.getDTCCCAPASD1());
        w.writeEndElement();
    }

    private static void write_DTCCCAPASD1V11(XMLStreamWriter w, String tag, DTCCCAPASD1V11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCorpActnGnlInf() != null) write_CorporateActionGeneralInformationSD58(w, "CorpActnGnlInf", obj.getCorpActnGnlInf());
        if (obj.getUndrlygScty() != null) write_FinancialInstrumentAttributesSD21(w, "UndrlygScty", obj.getUndrlygScty());
        if (obj.getCorpActnBalDtls() != null) write_CorporateActionBalanceSD4(w, "CorpActnBalDtls", obj.getCorpActnBalDtls());
        if (obj.getCorpActnDtls() != null) write_CorporateActionSD18(w, "CorpActnDtls", obj.getCorpActnDtls());
        for (CorporateActionMovementSecuritiesMovementDetailsSD5 item : obj.getCorpActnMvmntSctiesMvmntDtls()) write_CorporateActionMovementSecuritiesMovementDetailsSD5(w, "CorpActnMvmntSctiesMvmntDtls", item);
        for (CorporateActionMovementCashMovementDetailsSD5 item : obj.getCorpActnMvmntCshMvmntDtls()) write_CorporateActionMovementCashMovementDetailsSD5(w, "CorpActnMvmntCshMvmntDtls", item);
        for (OptionTransactionDetailsSD3 item : obj.getOptnTxDtls()) write_OptionTransactionDetailsSD3(w, "OptnTxDtls", item);
        w.writeEndElement();
    }

    private static void write_CorporateActionGeneralInformationSD58(XMLStreamWriter w, String tag, CorporateActionGeneralInformationSD58 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getEvtGrp() != null) writeLeaf(w, "EvtGrp", obj.getEvtGrp().value());
        if (obj.getEvtTp() != null) writeLeaf(w, "EvtTp", obj.getEvtTp().value());
        if (obj.getSubEvtTp() != null) writeLeaf(w, "SubEvtTp", obj.getSubEvtTp().value());
        if (obj.getRedId() != null) writeLeaf(w, "RedId", obj.getRedId());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentAttributesSD21(XMLStreamWriter w, String tag, FinancialInstrumentAttributesSD21 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getOrgtgSctyId() != null) write_OtherIdentification2(w, "OrgtgSctyId", obj.getOrgtgSctyId());
        if (obj.isMnyMktInstrmFlg() != null) writeLeaf(w, "MnyMktInstrmFlg", String.valueOf(obj.isMnyMktInstrmFlg()));
        w.writeEndElement();
    }

    private static void write_OtherIdentification2(XMLStreamWriter w, String tag, OtherIdentification2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        if (obj.getSfx() != null) writeLeaf(w, "Sfx", obj.getSfx());
        if (obj.getTp() != null) write_IdentificationSource4Choice(w, "Tp", obj.getTp());
        w.writeEndElement();
    }

    private static void write_IdentificationSource4Choice(XMLStreamWriter w, String tag, IdentificationSource4Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd());
        if (obj.getPrtry() != null) writeLeaf(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_CorporateActionBalanceSD4(XMLStreamWriter w, String tag, CorporateActionBalanceSD4 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getOrgnlBal() != null) write_SignedQuantityFormat9(w, "OrgnlBal", obj.getOrgnlBal());
        if (obj.getAdjstdBal() != null) write_SignedQuantityFormat9(w, "AdjstdBal", obj.getAdjstdBal());
        if (obj.getUpldgdBal() != null) write_SignedQuantityFormat9(w, "UpldgdBal", obj.getUpldgdBal());
        if (obj.getInvstmtUpldgdBal() != null) write_SignedQuantityFormat9(w, "InvstmtUpldgdBal", obj.getInvstmtUpldgdBal());
        if (obj.getInvstmtPldgdBal() != null) write_SignedQuantityFormat9(w, "InvstmtPldgdBal", obj.getInvstmtPldgdBal());
        if (obj.getMemoSgrtnBal() != null) write_SignedQuantityFormat9(w, "MemoSgrtnBal", obj.getMemoSgrtnBal());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat9(XMLStreamWriter w, String tag, SignedQuantityFormat9 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQty() != null) write_FinancialInstrumentQuantity15Choice(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity15Choice(XMLStreamWriter w, String tag, FinancialInstrumentQuantity15Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        if (obj.getAmtsdVal() != null) writeLeaf(w, "AmtsdVal", obj.getAmtsdVal().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionSD18(XMLStreamWriter w, String tag, CorporateActionSD18 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getLtrySeqNb() != null) writeLeaf(w, "LtrySeqNb", obj.getLtrySeqNb());
        w.writeEndElement();
    }

    private static void write_CorporateActionMovementSecuritiesMovementDetailsSD5(XMLStreamWriter w, String tag, CorporateActionMovementSecuritiesMovementDetailsSD5 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getPyoutTp() != null) writeLeaf(w, "PyoutTp", obj.getPyoutTp().value());
        if (obj.getTxQty() != null) write_FinancialInstrumentQuantity15Choice(w, "TxQty", obj.getTxQty());
        if (obj.getRsnCd() != null) writeLeaf(w, "RsnCd", obj.getRsnCd().value());
        if (obj.getSubRsnCd() != null) writeLeaf(w, "SubRsnCd", obj.getSubRsnCd().value());
        if (obj.getContraPtcptNb() != null) writeLeaf(w, "ContraPtcptNb", obj.getContraPtcptNb());
        if (obj.getEarlstPmtDt() != null) write_DateFormat48Choice(w, "EarlstPmtDt", obj.getEarlstPmtDt());
        if (obj.getTaxAdjstmntRate() != null) writeLeaf(w, "TaxAdjstmntRate", obj.getTaxAdjstmntRate().toString());
        if (obj.getRDPRefNb() != null) writeLeaf(w, "RDPRefNb", obj.getRDPRefNb());
        w.writeEndElement();
    }

    private static void write_DateFormat48Choice(XMLStreamWriter w, String tag, DateFormat48Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) write_DateAndDateTime2Choice(w, "Dt", obj.getDt());
        if (obj.getDtCd() != null) writeLeaf(w, "DtCd", obj.getDtCd().value());
        w.writeEndElement();
    }

    private static void write_DateAndDateTime2Choice(XMLStreamWriter w, String tag, DateAndDateTime2Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) writeLeaf(w, "Dt", obj.getDt().toXMLFormat());
        if (obj.getDtTm() != null) writeLeaf(w, "DtTm", obj.getDtTm().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_CorporateActionMovementCashMovementDetailsSD5(XMLStreamWriter w, String tag, CorporateActionMovementCashMovementDetailsSD5 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getPyoutTp() != null) writeLeaf(w, "PyoutTp", obj.getPyoutTp().value());
        if (obj.getTxAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "TxAmt", obj.getTxAmt());
        if (obj.getRsnCd() != null) writeLeaf(w, "RsnCd", obj.getRsnCd().value());
        if (obj.getSubRsnCd() != null) writeLeaf(w, "SubRsnCd", obj.getSubRsnCd().value());
        if (obj.getContraPtcptNb() != null) writeLeaf(w, "ContraPtcptNb", obj.getContraPtcptNb());
        if (obj.getEarlstPmtDt() != null) write_DateFormat48Choice(w, "EarlstPmtDt", obj.getEarlstPmtDt());
        if (obj.getRDPRefNb() != null) writeLeaf(w, "RDPRefNb", obj.getRDPRefNb());
        if (obj.getTaxAdjstmntRate() != null) writeLeaf(w, "TaxAdjstmntRate", obj.getTaxAdjstmntRate().toString());
        if (obj.getTxQty() != null) write_FinancialInstrumentQuantity15Choice(w, "TxQty", obj.getTxQty());
        w.writeEndElement();
    }

    private static void write_RestrictedFINActiveCurrencyAndAmount(XMLStreamWriter w, String tag, RestrictedFINActiveCurrencyAndAmount obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCcy() != null) w.writeAttribute("Ccy", obj.getCcy());
        w.writeCharacters(obj.getValue().toString());
        w.writeEndElement();
    }

    private static void write_OptionTransactionDetailsSD3(XMLStreamWriter w, String tag, OptionTransactionDetailsSD3 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPlcAndNm() != null) writeLeaf(w, "PlcAndNm", obj.getPlcAndNm());
        if (obj.getTxId() != null) writeLeaf(w, "TxId", obj.getTxId());
        if (obj.getTxSeqNb() != null) writeLeaf(w, "TxSeqNb", obj.getTxSeqNb());
        if (obj.getTxIdDt() != null) writeLeaf(w, "TxIdDt", obj.getTxIdDt().toXMLFormat());
        if (obj.getTxIdQty() != null) write_FinancialInstrumentQuantity15Choice(w, "TxIdQty", obj.getTxIdQty());
        if (obj.getEntitldAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "EntitldAmt", obj.getEntitldAmt());
        if (obj.getEntitldQty() != null) write_FinancialInstrumentQuantity15Choice(w, "EntitldQty", obj.getEntitldQty());
        if (obj.getAgtNtrdQty() != null) write_FinancialInstrumentQuantity15Choice(w, "AgtNtrdQty", obj.getAgtNtrdQty());
        if (obj.getAgtRmngQty() != null) write_FinancialInstrumentQuantity15Choice(w, "AgtRmngQty", obj.getAgtRmngQty());
        if (obj.getCstmrRefId() != null) writeLeaf(w, "CstmrRefId", obj.getCstmrRefId());
        w.writeEndElement();
    }

    private static void writeLeaf(XMLStreamWriter w, String tag, String text) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeCharacters(text);
        w.writeEndElement();
    }
}
