# bench-stax

A benchmark for hand-written StAX XML processing of 4 real-world ISO 20022 / SWIFT corporate
action messages, built step by step. No CM, no mapper, no JRules, no Kafka -- just XSD -> POJO
-> hand-written StAX reader/writer -> JMH.

## The 4 message types

All 4 XSDs live in `xsd/` and are self-contained (no imports between them).

| Type key       | Message        | What it is                                                                 |
|----------------|----------------|-----------------------------------------------------------------------------|
| `capa_seev035` | seev.035.001.16 | Corporate Action Movement **Preliminary Advice** (CAPA)                    |
| `capa_supl009` | supl.009.001.11 | DTCC supplementary data sent alongside a CAPA message                      |
| `caco_seev036` | seev.036.001.16 | Corporate Action Movement **Confirmation** (CACO)                          |
| `caco_supl011` | supl.011.001.11 | DTCC supplementary data sent alongside a CACO message                      |

Each XSD compiles to its own Java package via xjc: `com.bench.capa.seev035`,
`com.bench.capa.supl009`, `com.bench.caco.seev036`, `com.bench.caco.supl011`.

## How it's built, step by step

**1. XSD -> POJO (xjc).** `pom.xml` runs the `jaxb-maven-plugin` (xjc) at build time, once per
XSD, each into its own package under `target/generated-sources/`. These classes are plain data
holders -- in the benchmark they are *never* marshalled/unmarshalled by JAXB, only read and
written field-by-field by hand-written code.

**2. Sample XML generator** (`com.bench.generator`). Rather than guessing values, this walks
each XSD's *own* structure directly with XSOM (a schema object model) -- not the generated Java
classes -- so it sees the real facets: enumerations, regex patterns, min/max lengths, digit
counts. For every leaf value it picks something realistic (real currency codes, valid dates,
pattern-valid ISINs, business-sounding narrative text) and writes valid XML with a plain StAX
writer. Repeating (`maxOccurs > 1`) elements are repeated more or less depending on the target
size tier, with a damping factor per nesting level so repeats don't explode combinatorially.
Every generated file is immediately validated against its XSD, and the actual byte size vs. the
tier's target (and the % difference, when an exact match isn't feasible) is recorded in
`results/sample_manifest.json`.

5 size tiers x 4 types x 5 variants = **100 sample files**:

| Tier     | Target size | Folder     |
|----------|------------:|------------|
| Small    | ~10 KB      | `small`    |
| Medium   | ~100 KB     | `medium`   |
| Large    | ~1 MB       | `large`    |
| X-Large  | ~5 MB       | `xlarge`   |
| XXL      | ~10 MB      | `xxl`      |

Calibrating a single "repeat factor" to hit a byte target isn't linear: these schemas nest
several `maxOccurs="unbounded"` lists inside each other, so output size compounds roughly as
`factor^N` for `N` nested unbounded levels, not `factor^1`. An early version of this generator
used a flat `sqrt(ratio)` correction per retry, which either converged too slowly (landed 40%
under target on "medium" and never caught up within the retry budget) or overshot by orders of
magnitude and exhausted the heap (an `OutOfMemoryError` generating "xlarge") -- because a cheap
single-point guess can't tell linear growth from cubic growth. The fix: after the first two
attempts, fit an empirical power law `size ~= C * factor^e` from the actual two data points and
solve for the factor that should hit the target from *that*, with two independent safety clamps
(never more than 4x factor change per attempt; never let even a pessimistic exponent-6
projection of the next attempt exceed a 50 MB hard ceiling) so a bad extrapolation can degrade
gracefully instead of blowing past available heap.

> **Heap note:** generating the 5 MB/10 MB tiers needs more heap than Maven's default JVM gives
> `exec:java` (it runs in-process). Either set `MAVEN_OPTS=-Xmx3g` before `mvn exec:java`, or run
> the generator as a plain `java -Xmx3g -cp ...` process (see commands below) -- the actual
> StAX reader/writer benchmark itself needs no such accommodation.

**3 & 4. Hand-written StAX reader/writer, generated once** (`com.bench.codegen` ->
`com.bench.stax`). Hand-coding ~280 nested classes across 4 schemas by hand is a lot of
mechanical, repetitive work -- so instead there's a one-time source generator
(`StaxCodeGenerator`) that reflects on the *already-compiled* xjc classes (their `@XmlType`
`propOrder`, `@XmlElement`/`@XmlAttribute` names, field types) and emits plain `.java` source:
one `read_<Type>`/`write_<Type>` method per nested class, using only `XMLStreamReader` /
`XMLStreamWriter` calls -- no reflection, no JAXB marshal/unmarshal in the generated code itself.
This is exactly the code a person would type by hand; the generator just never gets a field name
wrong. Run it once, commit the output, done -- `com.bench.stax.*StaxReader` / `*StaxWriter`,
8 files, ~4800 lines.

**Round-trip check** (`com.bench.check.RoundTripCheck`). For every one of the 100 sample files:
XML -> POJO -> XML, validates the regenerated XML against the XSD, reads the regenerated XML
into a *second* POJO, and deep-compares the two POJO graphs field by field (this check tool
*does* use reflection -- that's fine, it's test tooling, not the benchmarked path). All 100 must
pass before the benchmarks are trusted. All of this runs outside any timed benchmark method.

**5. JMH benchmarks** (`src/jmh/java/com/bench/StaxBenchmark.java`):
- `b3_xmlToPojo` -- XML bytes -> POJO (the reader)
- `b6_pojoToXml` -- POJO -> XML bytes (the writer; the POJO is built in `@Setup`, so only
  writing is timed)
- `roundTrip` -- XML bytes -> POJO -> XML bytes

Parameterized by message type (all 4) and size (all 5 tiers) = 20 combinations, each run in both
`AverageTime` and `Throughput` mode. Sample bytes are loaded in `@Setup(Level.Trial)` (untimed);
file I/O never happens inside a `@Benchmark` method.

**GC count and GC time -- two independent sources, both JVM-fork-level.**
1. **`-prof gc`** (pass it on the command line): JMH's own profiler, which itself reads
   `GarbageCollectorMXBean`/`MemoryPoolMXBean` deltas around each measurement iteration. This is
   the primary, authoritative source and is what feeds the "GC count" / "GC time ms" columns in
   the main summary table.
2. **A supplementary manual capture**, independent of `-prof gc`: `@Setup(Level.Iteration)` /
   `@TearDown(Level.Iteration)` snapshot the sum of `GarbageCollectorMXBean.getCollectionCount()`
   / `getCollectionTime()` across all collectors, compute the delta, and append one row per
   iteration (including warmup) to `results/gc_manual.csv`, tagged with the exact benchmark name
   via JMH's injected `BenchmarkParams`. Nothing is forced inside a timed method -- no
   `System.gc()` calls, no GC-triggering code in `@Benchmark` methods.

Both are JVM-fork-level counters: they can include GC activity from JIT warmup, JMH's own
bookkeeping, or (for the manual capture) warmup iterations, not only the specific benchmarked
operation. Neither is claimed to be exclusively attributable to one operation. If a given
iteration genuinely triggers no GC, both sources report 0, not a fabricated value.

**Space & peak heap.** `com.bench.load.SpaceReport` measures input XML size, in-memory POJO size
(via JOL's `GraphLayout.parseInstance(...).totalSize()`), and output XML size, for every type x
size combination. `com.bench.load.PeakHeapLoadTest` processes 10,000 messages per type (using the
"medium" sample -- 10,000 x the "xxl" sample would mean processing ~100 GB of XML, which isn't a
reasonable load-test design) and records peak heap via `MemoryPoolMXBean`.

## Exact commands

```bash
# 1. Generate POJOs from the 4 XSDs (xjc)
mvn generate-sources
mvn compile

# 2. Generate + validate the 100 sample XMLs (5 files x 5 sizes x 4 types) into samples/
#    Needs more heap than Maven's default exec:java JVM gives for the 5MB/10MB tiers:
MAVEN_OPTS=-Xmx3g mvn exec:java -Dexec.mainClass=com.bench.generator.GenerateSamples
#    (equivalently, build a classpath and run plain `java -Xmx3g -cp ... com.bench.generator.GenerateSamples`)

# 3/4. (Re-)generate the hand-written-style StAX reader/writer source from the compiled POJOs
#      -- only needed if you change an XSD; the output is already committed under
#      src/main/java/com/bench/stax/
mvn exec:java -Dexec.mainClass=com.bench.codegen.StaxCodeGenerator
mvn compile

# Round-trip check: XML -> POJO -> XML, validate + compare, for all 100 samples
mvn exec:java -Dexec.mainClass=com.bench.check.RoundTripCheck

# 5. Build the runnable benchmark jar
mvn package

# Run the full JMH suite as specified (G1, 1g heap, 1 thread, warmup 5, measurement 5, 2 forks,
# -prof gc, JSON output) -- this covers all 4 types x 5 sizes x 3 benchmarks x 2 modes (120 runs),
# so it will take a while (expect an hour or more, dominated by the xlarge/xxl round trips).
java -Xms1g -Xmx1g -XX:+UseG1GC -jar target/benchmarks.jar \
  -wi 5 -i 5 -f 2 -prof gc -rf json -rff results/benchmark.json

# Space report (input/POJO/output sizes, all 5 tiers) and peak-heap load test (10,000 msgs/type)
mvn exec:java -Dexec.mainClass=com.bench.load.SpaceReport
mvn exec:java -Dexec.mainClass=com.bench.load.PeakHeapLoadTest

# Turn results/*.json (+ gc_manual.csv) into the summary tables
python scripts/summarize_results.py
```

### Re-running with different threads / GC / heap

The JVM flags go before `-jar`; JMH's own `-t` sets benchmark threads.

```bash
# 4 and 8 threads
java -Xms1g -Xmx1g -XX:+UseG1GC -jar target/benchmarks.jar -t 4 -wi 5 -i 5 -f 2 -prof gc -rf json -rff results/benchmark_t4.json
java -Xms1g -Xmx1g -XX:+UseG1GC -jar target/benchmarks.jar -t 8 -wi 5 -i 5 -f 2 -prof gc -rf json -rff results/benchmark_t8.json

# Parallel GC and ZGC
java -Xms1g -Xmx1g -XX:+UseParallelGC -jar target/benchmarks.jar -wi 5 -i 5 -f 2 -prof gc -rf json -rff results/benchmark_parallelgc.json
java -Xms1g -Xmx1g -XX:+UseZGC      -jar target/benchmarks.jar -wi 5 -i 5 -f 2 -prof gc -rf json -rff results/benchmark_zgc.json

# Heap 512m and 2g
java -Xms512m -Xmx512m -XX:+UseG1GC -jar target/benchmarks.jar -wi 5 -i 5 -f 2 -prof gc -rf json -rff results/benchmark_512m.json
java -Xms2g   -Xmx2g   -XX:+UseG1GC -jar target/benchmarks.jar -wi 5 -i 5 -f 2 -prof gc -rf json -rff results/benchmark_2g.json
```

`scripts/summarize_results.py` reads every `*.json` in `results/` (except `space.json` and
`heap.json`, which have their own tables, and `gc_manual.csv`, which has its own table too), so
you can drop several run variants in there and get one combined summary, or point it at a
different directory: `python scripts/summarize_results.py results/some_other_dir`.

## Project layout

```
bench-stax/
  pom.xml
  xsd/                          4 XSD files (seev.035, seev.036, supl.009, supl.011)
  samples/<type>/<size>/        100 generated + XSD-validated sample XMLs (5 sizes x 4 types x 5 variants)
  src/main/java/com/bench/
    generator/                  XSD-driven sample XML generator (uses XSOM)
    codegen/                    one-time reflection-based StAX source generator (build tool)
    stax/                       generated StAX readers/writers (plain, no reflection/JAXB)
    check/                      round-trip check (XML -> POJO -> XML, validate + deep-compare)
    load/                       SpaceReport (JOL) and PeakHeapLoadTest (MemoryPoolMXBean)
  src/jmh/java/com/bench/       JMH benchmark (B3, B6, round trip)
  scripts/
    summarize_results.py        turns results/*.json (+ gc_manual.csv) into the summary tables
  results/                      JMH JSON + space.json + heap.json + gc_manual.csv + sample_manifest.json land here
```

## What changed when this grew from 3 sizes/60 files to 5 sizes/100 files

This project started with 3 size tiers (~2 KB/~50 KB/~1 MB, 60 files) and was later extended to
5 tiers (~10 KB/~100 KB/~1 MB/~5 MB/~10 MB, 100 files) plus the supplementary GC-MXBean capture.
Everything from steps 1-4 (xjc POJOs, the StAX reader/writer codegen and its output, the
round-trip checker) was reused completely unchanged -- they're generic over whatever size
folders exist. What actually changed:
- `SizeTier.java`: 3 tiers -> 5, with updated targets.
- `SampleXmlGenerator.java`: the calibration loop (see above) -- the old flat `sqrt(ratio)`
  correction couldn't handle the 5 MB/10 MB targets safely.
- `GenerateSamples.java`: added target-vs-actual %diff reporting and `results/sample_manifest.json`.
- `StaxBenchmark.java`: added `xlarge`/`xxl` to the size `@Param`, added the manual
  `GarbageCollectorMXBean` delta capture.
- `SpaceReport.java`: extended to all 5 size tiers.
- `scripts/summarize_results.py`: added the `gc_manual.csv` table.
- `PeakHeapLoadTest.java`: unchanged (still uses the "medium" sample for the 10,000-message run).
