package com.bench.generator;

/** The 5 sample sizes requested, with an approximate target byte size and starting repeat factor. */
public enum SizeTier {
    SMALL("small", 10_000, 4, true),
    MEDIUM("medium", 100_000, 14, true),
    LARGE("large", 1_000_000, 60, true),
    XLARGE("xlarge", 5_000_000, 65, true),
    XXL("xxl", 10_000_000, 65, true);

    public final String folderName;
    public final int targetBytes;
    public final int initialRepeatFactor;
    public final boolean includeOptionalScalars;

    SizeTier(String folderName, int targetBytes, int initialRepeatFactor, boolean includeOptionalScalars) {
        this.folderName = folderName;
        this.targetBytes = targetBytes;
        this.initialRepeatFactor = initialRepeatFactor;
        this.includeOptionalScalars = includeOptionalScalars;
    }
}
