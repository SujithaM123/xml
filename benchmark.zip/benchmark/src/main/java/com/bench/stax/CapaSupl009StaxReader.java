package com.bench.stax;

import com.bench.capa.supl009.*;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.datatype.DatatypeFactory;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.BigInteger;

/** Hand-written-style StAX reader for CapaSupl009 (generated once from the xjc POJOs; no reflection or JAXB unmarshalling at runtime). */
public final class CapaSupl009StaxReader {

    private static final XMLInputFactory INPUT_FACTORY = XMLInputFactory.newFactory();
    private static final DatatypeFactory DATATYPE_FACTORY;
    static {
        try {
            DATATYPE_FACTORY = DatatypeFactory.newInstance();
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private CapaSupl009StaxReader() {
    }

    public static Document read(byte[] xml) throws XMLStreamException {
        XMLStreamReader r = INPUT_FACTORY.createXMLStreamReader(new ByteArrayInputStream(xml));
        r.nextTag();
        Document doc = read_Document(r);
        r.close();
        return doc;
    }

    private static Document read_Document(XMLStreamReader r) throws XMLStreamException {
        Document obj = new Document();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "DTCCCAPASD1": obj.setDTCCCAPASD1(read_DTCCCAPASD1V11(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DTCCCAPASD1V11 read_DTCCCAPASD1V11(XMLStreamReader r) throws XMLStreamException {
        DTCCCAPASD1V11 obj = new DTCCCAPASD1V11();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CorpActnGnlInf": obj.setCorpActnGnlInf(read_CorporateActionGeneralInformationSD58(r)); break;
                case "UndrlygScty": obj.setUndrlygScty(read_FinancialInstrumentAttributesSD21(r)); break;
                case "CorpActnBalDtls": obj.setCorpActnBalDtls(read_CorporateActionBalanceSD4(r)); break;
                case "CorpActnDtls": obj.setCorpActnDtls(read_CorporateActionSD18(r)); break;
                case "CorpActnMvmntSctiesMvmntDtls": obj.getCorpActnMvmntSctiesMvmntDtls().add(read_CorporateActionMovementSecuritiesMovementDetailsSD5(r)); break;
                case "CorpActnMvmntCshMvmntDtls": obj.getCorpActnMvmntCshMvmntDtls().add(read_CorporateActionMovementCashMovementDetailsSD5(r)); break;
                case "OptnTxDtls": obj.getOptnTxDtls().add(read_OptionTransactionDetailsSD3(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionGeneralInformationSD58 read_CorporateActionGeneralInformationSD58(XMLStreamReader r) throws XMLStreamException {
        CorporateActionGeneralInformationSD58 obj = new CorporateActionGeneralInformationSD58();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PlcAndNm": obj.setPlcAndNm(r.getElementText()); break;
                case "EvtGrp": obj.setEvtGrp(EventGroup1Code.fromValue(r.getElementText())); break;
                case "EvtTp": obj.setEvtTp(ExtendedEventType6Code.fromValue(r.getElementText())); break;
                case "SubEvtTp": obj.setSubEvtTp(DTCCSubEventType11Code.fromValue(r.getElementText())); break;
                case "RedId": obj.setRedId(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentAttributesSD21 read_FinancialInstrumentAttributesSD21(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentAttributesSD21 obj = new FinancialInstrumentAttributesSD21();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PlcAndNm": obj.setPlcAndNm(r.getElementText()); break;
                case "OrgtgSctyId": obj.setOrgtgSctyId(read_OtherIdentification2(r)); break;
                case "MnyMktInstrmFlg": obj.setMnyMktInstrmFlg(Boolean.parseBoolean(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static OtherIdentification2 read_OtherIdentification2(XMLStreamReader r) throws XMLStreamException {
        OtherIdentification2 obj = new OtherIdentification2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Id": obj.setId(r.getElementText()); break;
                case "Sfx": obj.setSfx(r.getElementText()); break;
                case "Tp": obj.setTp(read_IdentificationSource4Choice(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static IdentificationSource4Choice read_IdentificationSource4Choice(XMLStreamReader r) throws XMLStreamException {
        IdentificationSource4Choice obj = new IdentificationSource4Choice();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(r.getElementText()); break;
                case "Prtry": obj.setPrtry(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionBalanceSD4 read_CorporateActionBalanceSD4(XMLStreamReader r) throws XMLStreamException {
        CorporateActionBalanceSD4 obj = new CorporateActionBalanceSD4();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PlcAndNm": obj.setPlcAndNm(r.getElementText()); break;
                case "OrgnlBal": obj.setOrgnlBal(read_SignedQuantityFormat9(r)); break;
                case "AdjstdBal": obj.setAdjstdBal(read_SignedQuantityFormat9(r)); break;
                case "UpldgdBal": obj.setUpldgdBal(read_SignedQuantityFormat9(r)); break;
                case "InvstmtUpldgdBal": obj.setInvstmtUpldgdBal(read_SignedQuantityFormat9(r)); break;
                case "InvstmtPldgdBal": obj.setInvstmtPldgdBal(read_SignedQuantityFormat9(r)); break;
                case "MemoSgrtnBal": obj.setMemoSgrtnBal(read_SignedQuantityFormat9(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat9 read_SignedQuantityFormat9(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat9 obj = new SignedQuantityFormat9();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code.fromValue(r.getElementText())); break;
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity15Choice(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentQuantity15Choice read_FinancialInstrumentQuantity15Choice(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentQuantity15Choice obj = new FinancialInstrumentQuantity15Choice();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Unit": obj.setUnit(new BigDecimal(r.getElementText())); break;
                case "FaceAmt": obj.setFaceAmt(new BigDecimal(r.getElementText())); break;
                case "AmtsdVal": obj.setAmtsdVal(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionSD18 read_CorporateActionSD18(XMLStreamReader r) throws XMLStreamException {
        CorporateActionSD18 obj = new CorporateActionSD18();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PlcAndNm": obj.setPlcAndNm(r.getElementText()); break;
                case "LtrySeqNb": obj.setLtrySeqNb(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionMovementSecuritiesMovementDetailsSD5 read_CorporateActionMovementSecuritiesMovementDetailsSD5(XMLStreamReader r) throws XMLStreamException {
        CorporateActionMovementSecuritiesMovementDetailsSD5 obj = new CorporateActionMovementSecuritiesMovementDetailsSD5();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PlcAndNm": obj.setPlcAndNm(r.getElementText()); break;
                case "CdtDbtInd": obj.setCdtDbtInd(CreditDebitCode.fromValue(r.getElementText())); break;
                case "PyoutTp": obj.setPyoutTp(DTCCPayoutType4Code.fromValue(r.getElementText())); break;
                case "TxQty": obj.setTxQty(read_FinancialInstrumentQuantity15Choice(r)); break;
                case "RsnCd": obj.setRsnCd(DTCAdjustmentPaymentType4Code.fromValue(r.getElementText())); break;
                case "SubRsnCd": obj.setSubRsnCd(DTCAdjustmentPaymentSubReason2Code.fromValue(r.getElementText())); break;
                case "ContraPtcptNb": obj.setContraPtcptNb(r.getElementText()); break;
                case "EarlstPmtDt": obj.setEarlstPmtDt(read_DateFormat48Choice(r)); break;
                case "TaxAdjstmntRate": obj.setTaxAdjstmntRate(new BigDecimal(r.getElementText())); break;
                case "RDPRefNb": obj.setRDPRefNb(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateFormat48Choice read_DateFormat48Choice(XMLStreamReader r) throws XMLStreamException {
        DateFormat48Choice obj = new DateFormat48Choice();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Dt": obj.setDt(read_DateAndDateTime2Choice(r)); break;
                case "DtCd": obj.setDtCd(DateType8Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateAndDateTime2Choice read_DateAndDateTime2Choice(XMLStreamReader r) throws XMLStreamException {
        DateAndDateTime2Choice obj = new DateAndDateTime2Choice();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Dt": obj.setDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                case "DtTm": obj.setDtTm(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionMovementCashMovementDetailsSD5 read_CorporateActionMovementCashMovementDetailsSD5(XMLStreamReader r) throws XMLStreamException {
        CorporateActionMovementCashMovementDetailsSD5 obj = new CorporateActionMovementCashMovementDetailsSD5();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PlcAndNm": obj.setPlcAndNm(r.getElementText()); break;
                case "CdtDbtInd": obj.setCdtDbtInd(CreditDebitCode.fromValue(r.getElementText())); break;
                case "PyoutTp": obj.setPyoutTp(DTCCPayoutType5Code.fromValue(r.getElementText())); break;
                case "TxAmt": obj.setTxAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "RsnCd": obj.setRsnCd(DTCAdjustmentPaymentType4Code.fromValue(r.getElementText())); break;
                case "SubRsnCd": obj.setSubRsnCd(DTCAdjustmentPaymentSubReason2Code.fromValue(r.getElementText())); break;
                case "ContraPtcptNb": obj.setContraPtcptNb(r.getElementText()); break;
                case "EarlstPmtDt": obj.setEarlstPmtDt(read_DateFormat48Choice(r)); break;
                case "RDPRefNb": obj.setRDPRefNb(r.getElementText()); break;
                case "TaxAdjstmntRate": obj.setTaxAdjstmntRate(new BigDecimal(r.getElementText())); break;
                case "TxQty": obj.setTxQty(read_FinancialInstrumentQuantity15Choice(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RestrictedFINActiveCurrencyAndAmount read_RestrictedFINActiveCurrencyAndAmount(XMLStreamReader r) throws XMLStreamException {
        RestrictedFINActiveCurrencyAndAmount obj = new RestrictedFINActiveCurrencyAndAmount();
        obj.setCcy(r.getAttributeValue(null, "Ccy"));
        obj.setValue(new BigDecimal(r.getElementText()));
        return obj;
    }

    private static OptionTransactionDetailsSD3 read_OptionTransactionDetailsSD3(XMLStreamReader r) throws XMLStreamException {
        OptionTransactionDetailsSD3 obj = new OptionTransactionDetailsSD3();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PlcAndNm": obj.setPlcAndNm(r.getElementText()); break;
                case "TxId": obj.setTxId(r.getElementText()); break;
                case "TxSeqNb": obj.setTxSeqNb(r.getElementText()); break;
                case "TxIdDt": obj.setTxIdDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                case "TxIdQty": obj.setTxIdQty(read_FinancialInstrumentQuantity15Choice(r)); break;
                case "EntitldAmt": obj.setEntitldAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "EntitldQty": obj.setEntitldQty(read_FinancialInstrumentQuantity15Choice(r)); break;
                case "AgtNtrdQty": obj.setAgtNtrdQty(read_FinancialInstrumentQuantity15Choice(r)); break;
                case "AgtRmngQty": obj.setAgtRmngQty(read_FinancialInstrumentQuantity15Choice(r)); break;
                case "CstmrRefId": obj.setCstmrRefId(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static void skip(XMLStreamReader r) throws XMLStreamException {
        int depth = 1;
        while (depth > 0) {
            int ev = r.next();
            if (ev == XMLStreamConstants.START_ELEMENT) depth++;
            else if (ev == XMLStreamConstants.END_ELEMENT) depth--;
        }
    }
}
