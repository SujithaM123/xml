package com.bench.stax;

import com.bench.caco.seev036.*;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.datatype.DatatypeFactory;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.BigInteger;

/** Hand-written-style StAX reader for CacoSeev036 (generated once from the xjc POJOs; no reflection or JAXB unmarshalling at runtime). */
public final class CacoSeev036StaxReader {

    private static final XMLInputFactory INPUT_FACTORY = XMLInputFactory.newFactory();
    private static final DatatypeFactory DATATYPE_FACTORY;
    static {
        try {
            DATATYPE_FACTORY = DatatypeFactory.newInstance();
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private CacoSeev036StaxReader() {
    }

    public static Document read(byte[] xml) throws XMLStreamException {
        XMLStreamReader r = INPUT_FACTORY.createXMLStreamReader(new ByteArrayInputStream(xml));
        r.nextTag();
        Document doc = read_Document(r);
        r.close();
        return doc;
    }

    private static Document read_Document(XMLStreamReader r) throws XMLStreamException {
        Document obj = new Document();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CorpActnMvmntConf": obj.setCorpActnMvmntConf(read_CorporateActionMovementConfirmationV16(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionMovementConfirmationV16 read_CorporateActionMovementConfirmationV16(XMLStreamReader r) throws XMLStreamException {
        CorporateActionMovementConfirmationV16 obj = new CorporateActionMovementConfirmationV16();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Pgntn": obj.setPgntn(read_Pagination1(r)); break;
                case "MvmntConfId": obj.setMvmntConfId(r.getElementText()); break;
                case "MvmntPrlimryAdvcId": obj.setMvmntPrlimryAdvcId(read_DocumentIdentification311(r)); break;
                case "CorpActnGnlInf": obj.setCorpActnGnlInf(read_CorporateActionGeneralInformation1791(r)); break;
                case "AcctDtls": obj.setAcctDtls(read_AccountAndBalance581(r)); break;
                case "CorpActnDtls": obj.setCorpActnDtls(read_CorporateAction851(r)); break;
                case "CorpActnConfDtls": obj.setCorpActnConfDtls(read_CorporateActionOption2331(r)); break;
                case "AddtlInf": obj.setAddtlInf(read_CorporateActionNarrative311(r)); break;
                case "SplmtryData": obj.getSplmtryData().add(read_SupplementaryData11(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Pagination1 read_Pagination1(XMLStreamReader r) throws XMLStreamException {
        Pagination1 obj = new Pagination1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PgNb": obj.setPgNb(r.getElementText()); break;
                case "LastPgInd": obj.setLastPgInd(Boolean.parseBoolean(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DocumentIdentification311 read_DocumentIdentification311(XMLStreamReader r) throws XMLStreamException {
        DocumentIdentification311 obj = new DocumentIdentification311();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Id": obj.setId(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionGeneralInformation1791 read_CorporateActionGeneralInformation1791(XMLStreamReader r) throws XMLStreamException {
        CorporateActionGeneralInformation1791 obj = new CorporateActionGeneralInformation1791();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CorpActnEvtId": obj.setCorpActnEvtId(r.getElementText()); break;
                case "OffclCorpActnEvtId": obj.setOffclCorpActnEvtId(r.getElementText()); break;
                case "EvtTp": obj.setEvtTp(read_CorporateActionEventType109Choice1(r)); break;
                case "FinInstrmId": obj.setFinInstrmId(read_SecurityIdentification191(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionEventType109Choice1 read_CorporateActionEventType109Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionEventType109Choice1 obj = new CorporateActionEventType109Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionEventType37Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SecurityIdentification191 read_SecurityIdentification191(XMLStreamReader r) throws XMLStreamException {
        SecurityIdentification191 obj = new SecurityIdentification191();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ISIN": obj.setISIN(r.getElementText()); break;
                case "OthrId": obj.getOthrId().add(read_OtherIdentification11(r)); break;
                case "Desc": obj.setDesc(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static OtherIdentification11 read_OtherIdentification11(XMLStreamReader r) throws XMLStreamException {
        OtherIdentification11 obj = new OtherIdentification11();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Id": obj.setId(r.getElementText()); break;
                case "Tp": obj.setTp(read_IdentificationSource3Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static IdentificationSource3Choice1 read_IdentificationSource3Choice1(XMLStreamReader r) throws XMLStreamException {
        IdentificationSource3Choice1 obj = new IdentificationSource3Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(r.getElementText()); break;
                case "Prtry": obj.setPrtry(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AccountAndBalance581 read_AccountAndBalance581(XMLStreamReader r) throws XMLStreamException {
        AccountAndBalance581 obj = new AccountAndBalance581();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "SfkpgAcct": obj.setSfkpgAcct(r.getElementText()); break;
                case "Bal": obj.setBal(read_CorporateActionBalanceDetails411(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionBalanceDetails411 read_CorporateActionBalanceDetails411(XMLStreamReader r) throws XMLStreamException {
        CorporateActionBalanceDetails411 obj = new CorporateActionBalanceDetails411();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ConfdBal": obj.setConfdBal(read_BalanceFormat11Choice1(r)); break;
                case "TtlElgblBal": obj.setTtlElgblBal(read_TotalEligibleBalanceFormat101(r)); break;
                case "BrrwdBal": obj.setBrrwdBal(read_BalanceFormat11Choice1(r)); break;
                case "CollInBal": obj.setCollInBal(read_BalanceFormat11Choice1(r)); break;
                case "CollOutBal": obj.setCollOutBal(read_BalanceFormat11Choice1(r)); break;
                case "OnLnBal": obj.setOnLnBal(read_BalanceFormat11Choice1(r)); break;
                case "PdgDlvryBal": obj.setPdgDlvryBal(read_BalanceFormat12Choice1(r)); break;
                case "PdgRctBal": obj.setPdgRctBal(read_BalanceFormat12Choice1(r)); break;
                case "StlmPosBal": obj.setStlmPosBal(read_BalanceFormat12Choice1(r)); break;
                case "AfctdBal": obj.setAfctdBal(read_BalanceFormat11Choice2(r)); break;
                case "UafctdBal": obj.setUafctdBal(read_BalanceFormat11Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat11Choice1 read_BalanceFormat11Choice1(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat11Choice1 obj = new BalanceFormat11Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat111(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat111 read_SignedQuantityFormat111(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat111 obj = new SignedQuantityFormat111();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code.fromValue(r.getElementText())); break;
                case "QtyChc": obj.setQtyChc(read_Quantity48Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity48Choice1 read_Quantity48Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity48Choice1 obj = new Quantity48Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentQuantity33Choice1 read_FinancialInstrumentQuantity33Choice1(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentQuantity33Choice1 obj = new FinancialInstrumentQuantity33Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Unit": obj.setUnit(new BigDecimal(r.getElementText())); break;
                case "FaceAmt": obj.setFaceAmt(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static TotalEligibleBalanceFormat101 read_TotalEligibleBalanceFormat101(XMLStreamReader r) throws XMLStreamException {
        TotalEligibleBalanceFormat101 obj = new TotalEligibleBalanceFormat101();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_Quantity49Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity49Choice1 read_Quantity49Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity49Choice1 obj = new Quantity49Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "QtyChc": obj.setQtyChc(read_Quantity50Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity50Choice1 read_Quantity50Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity50Choice1 obj = new Quantity50Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "SgndQty": obj.setSgndQty(read_SignedQuantityFormat101(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat101 read_SignedQuantityFormat101(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat101 obj = new SignedQuantityFormat101();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code.fromValue(r.getElementText())); break;
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat12Choice1 read_BalanceFormat12Choice1(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat12Choice1 obj = new BalanceFormat12Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat111(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static BalanceFormat11Choice2 read_BalanceFormat11Choice2(XMLStreamReader r) throws XMLStreamException {
        BalanceFormat11Choice2 obj = new BalanceFormat11Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Bal": obj.setBal(read_SignedQuantityFormat112(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SignedQuantityFormat112 read_SignedQuantityFormat112(XMLStreamReader r) throws XMLStreamException {
        SignedQuantityFormat112 obj = new SignedQuantityFormat112();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ShrtLngPos": obj.setShrtLngPos(ShortLong1Code1.fromValue(r.getElementText())); break;
                case "QtyChc": obj.setQtyChc(read_Quantity48Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateAction851 read_CorporateAction851(XMLStreamReader r) throws XMLStreamException {
        CorporateAction851 obj = new CorporateAction851();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "DtDtls": obj.setDtDtls(read_CorporateActionDate861(r)); break;
                case "EvtStag": obj.setEvtStag(read_CorporateActionEventStageFormat14Choice1(r)); break;
                case "AddtlBizPrcInd": obj.getAddtlBizPrcInd().add(read_AdditionalBusinessProcessFormat23Choice1(r)); break;
                case "IntrmdtSctiesDstrbtnTp": obj.setIntrmdtSctiesDstrbtnTp(read_IntermediateSecuritiesDistributionTypeFormat15Choice1(r)); break;
                case "LtryTp": obj.setLtryTp(read_LotteryTypeFormat4Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionDate861 read_CorporateActionDate861(XMLStreamReader r) throws XMLStreamException {
        CorporateActionDate861 obj = new CorporateActionDate861();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RcrdDt": obj.setRcrdDt(read_DateFormat30Choice1(r)); break;
                case "ExDvddDt": obj.setExDvddDt(read_DateFormat30Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateFormat30Choice1 read_DateFormat30Choice1(XMLStreamReader r) throws XMLStreamException {
        DateFormat30Choice1 obj = new DateFormat30Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Dt": obj.setDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionEventStageFormat14Choice1 read_CorporateActionEventStageFormat14Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionEventStageFormat14Choice1 obj = new CorporateActionEventStageFormat14Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionEventStage4Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AdditionalBusinessProcessFormat23Choice1 read_AdditionalBusinessProcessFormat23Choice1(XMLStreamReader r) throws XMLStreamException {
        AdditionalBusinessProcessFormat23Choice1 obj = new AdditionalBusinessProcessFormat23Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(AdditionalBusinessProcess12Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static IntermediateSecuritiesDistributionTypeFormat15Choice1 read_IntermediateSecuritiesDistributionTypeFormat15Choice1(XMLStreamReader r) throws XMLStreamException {
        IntermediateSecuritiesDistributionTypeFormat15Choice1 obj = new IntermediateSecuritiesDistributionTypeFormat15Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(IntermediateSecurityDistributionType5Code1.fromValue(r.getElementText())); break;
                case "Prtry": obj.setPrtry(read_GenericIdentification301(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static GenericIdentification301 read_GenericIdentification301(XMLStreamReader r) throws XMLStreamException {
        GenericIdentification301 obj = new GenericIdentification301();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Id": obj.setId(r.getElementText()); break;
                case "Issr": obj.setIssr(r.getElementText()); break;
                case "SchmeNm": obj.setSchmeNm(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static LotteryTypeFormat4Choice1 read_LotteryTypeFormat4Choice1(XMLStreamReader r) throws XMLStreamException {
        LotteryTypeFormat4Choice1 obj = new LotteryTypeFormat4Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(LotteryType1Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionOption2331 read_CorporateActionOption2331(XMLStreamReader r) throws XMLStreamException {
        CorporateActionOption2331 obj = new CorporateActionOption2331();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "OptnNb": obj.setOptnNb(read_OptionNumber1Choice1(r)); break;
                case "OptnTp": obj.setOptnTp(read_CorporateActionOption33Choice1(r)); break;
                case "OptnFeatrs": obj.getOptnFeatrs().add(read_OptionFeaturesFormat29Choice1(r)); break;
                case "RateAndAmtDtls": obj.setRateAndAmtDtls(read_CorporateActionRate1201(r)); break;
                case "PricDtls": obj.setPricDtls(read_CorporateActionPrice841(r)); break;
                case "SctiesMvmntDtls": obj.getSctiesMvmntDtls().add(read_SecuritiesOption1121(r)); break;
                case "CshMvmntDtls": obj.getCshMvmntDtls().add(read_CashOption1051(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static OptionNumber1Choice1 read_OptionNumber1Choice1(XMLStreamReader r) throws XMLStreamException {
        OptionNumber1Choice1 obj = new OptionNumber1Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Nb": obj.setNb(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionOption33Choice1 read_CorporateActionOption33Choice1(XMLStreamReader r) throws XMLStreamException {
        CorporateActionOption33Choice1 obj = new CorporateActionOption33Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(CorporateActionOption12Code1.fromValue(r.getElementText())); break;
                case "Prtry": obj.setPrtry(read_GenericIdentification301(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static OptionFeaturesFormat29Choice1 read_OptionFeaturesFormat29Choice1(XMLStreamReader r) throws XMLStreamException {
        OptionFeaturesFormat29Choice1 obj = new OptionFeaturesFormat29Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(OptionFeatures14Code1.fromValue(r.getElementText())); break;
                case "Prtry": obj.setPrtry(read_GenericIdentification301(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionRate1201 read_CorporateActionRate1201(XMLStreamReader r) throws XMLStreamException {
        CorporateActionRate1201 obj = new CorporateActionRate1201();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PrratnRate": obj.setPrratnRate(new BigDecimal(r.getElementText())); break;
                case "TaxblIncmPerDvddShr": obj.getTaxblIncmPerDvddShr().add(read_RateTypeAndAmountAndStatus261(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateTypeAndAmountAndStatus261 read_RateTypeAndAmountAndStatus261(XMLStreamReader r) throws XMLStreamException {
        RateTypeAndAmountAndStatus261 obj = new RateTypeAndAmountAndStatus261();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTp": obj.setRateTp(read_RateType36Choice1(r)); break;
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "RateSts": obj.setRateSts(read_RateStatus3Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateType36Choice1 read_RateType36Choice1(XMLStreamReader r) throws XMLStreamException {
        RateType36Choice1 obj = new RateType36Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(DividendRateType1Code.fromValue(r.getElementText())); break;
                case "Prtry": obj.setPrtry(read_GenericIdentification301(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RestrictedFINActiveCurrencyAnd13DecimalAmount read_RestrictedFINActiveCurrencyAnd13DecimalAmount(XMLStreamReader r) throws XMLStreamException {
        RestrictedFINActiveCurrencyAnd13DecimalAmount obj = new RestrictedFINActiveCurrencyAnd13DecimalAmount();
        obj.setCcy(r.getAttributeValue(null, "Ccy"));
        obj.setValue(new BigDecimal(r.getElementText()));
        return obj;
    }

    private static RateStatus3Choice1 read_RateStatus3Choice1(XMLStreamReader r) throws XMLStreamException {
        RateStatus3Choice1 obj = new RateStatus3Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(RateStatus1Code.fromValue(r.getElementText())); break;
                case "Prtry": obj.setPrtry(read_GenericIdentification301(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionPrice841 read_CorporateActionPrice841(XMLStreamReader r) throws XMLStreamException {
        CorporateActionPrice841 obj = new CorporateActionPrice841();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "OverSbcptDpstPric": obj.setOverSbcptDpstPric(read_PriceFormat77Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat77Choice1 read_PriceFormat77Choice1(XMLStreamReader r) throws XMLStreamException {
        PriceFormat77Choice1 obj = new PriceFormat77Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPric": obj.setAmtPric(read_AmountPrice31(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountPrice31 read_AmountPrice31(XMLStreamReader r) throws XMLStreamException {
        AmountPrice31 obj = new AmountPrice31();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricTp": obj.setAmtPricTp(AmountPriceType1Code1.fromValue(r.getElementText())); break;
                case "PricVal": obj.setPricVal(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SecuritiesOption1121 read_SecuritiesOption1121(XMLStreamReader r) throws XMLStreamException {
        SecuritiesOption1121 obj = new SecuritiesOption1121();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "FinInstrmId": obj.setFinInstrmId(read_SecurityIdentification191(r)); break;
                case "CdtDbtInd": obj.setCdtDbtInd(CreditDebitCode.fromValue(r.getElementText())); break;
                case "TempFinInstrmInd": obj.setTempFinInstrmInd(read_TemporaryFinancialInstrumentIndicator3Choice1(r)); break;
                case "NewSctiesIssncInd": obj.setNewSctiesIssncInd(NewSecuritiesIssuanceType6Code.fromValue(r.getElementText())); break;
                case "PstngQty": obj.setPstngQty(read_Quantity51Choice1(r)); break;
                case "FrctnDspstn": obj.setFrctnDspstn(read_FractionDispositionType27Choice1(r)); break;
                case "DtDtls": obj.setDtDtls(read_SecurityDate251(r)); break;
                case "RateDtls": obj.setRateDtls(read_CorporateActionRate1251(r)); break;
                case "PricDtls": obj.setPricDtls(read_CorporateActionPrice831(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static TemporaryFinancialInstrumentIndicator3Choice1 read_TemporaryFinancialInstrumentIndicator3Choice1(XMLStreamReader r) throws XMLStreamException {
        TemporaryFinancialInstrumentIndicator3Choice1 obj = new TemporaryFinancialInstrumentIndicator3Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "TempInd": obj.setTempInd(Boolean.parseBoolean(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Quantity51Choice1 read_Quantity51Choice1(XMLStreamReader r) throws XMLStreamException {
        Quantity51Choice1 obj = new Quantity51Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty": obj.setQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FractionDispositionType27Choice1 read_FractionDispositionType27Choice1(XMLStreamReader r) throws XMLStreamException {
        FractionDispositionType27Choice1 obj = new FractionDispositionType27Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(FractionDispositionType11Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SecurityDate251 read_SecurityDate251(XMLStreamReader r) throws XMLStreamException {
        SecurityDate251 obj = new SecurityDate251();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PstngDt": obj.setPstngDt(read_DateAndDateTime2Choice(r)); break;
                case "PmtDt": obj.setPmtDt(read_DateFormat30Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static DateAndDateTime2Choice read_DateAndDateTime2Choice(XMLStreamReader r) throws XMLStreamException {
        DateAndDateTime2Choice obj = new DateAndDateTime2Choice();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Dt": obj.setDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                case "DtTm": obj.setDtTm(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionRate1251 read_CorporateActionRate1251(XMLStreamReader r) throws XMLStreamException {
        CorporateActionRate1251 obj = new CorporateActionRate1251();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AddtlQtyForExstgScties": obj.setAddtlQtyForExstgScties(read_RatioFormat20Choice1(r)); break;
                case "NewToOd": obj.setNewToOd(read_RatioFormat19Choice1(r)); break;
                case "TaxCdtRate": obj.setTaxCdtRate(read_RateFormat27Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RatioFormat20Choice1 read_RatioFormat20Choice1(XMLStreamReader r) throws XMLStreamException {
        RatioFormat20Choice1 obj = new RatioFormat20Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "QtyToQty": obj.setQtyToQty(read_QuantityToQuantityRatio11(r)); break;
                case "AmtToAmt": obj.setAmtToAmt(read_AmountToAmountRatio21(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static QuantityToQuantityRatio11 read_QuantityToQuantityRatio11(XMLStreamReader r) throws XMLStreamException {
        QuantityToQuantityRatio11 obj = new QuantityToQuantityRatio11();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Qty1": obj.setQty1(new BigDecimal(r.getElementText())); break;
                case "Qty2": obj.setQty2(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountToAmountRatio21 read_AmountToAmountRatio21(XMLStreamReader r) throws XMLStreamException {
        AmountToAmountRatio21 obj = new AmountToAmountRatio21();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt1": obj.setAmt1(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "Amt2": obj.setAmt2(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RatioFormat19Choice1 read_RatioFormat19Choice1(XMLStreamReader r) throws XMLStreamException {
        RatioFormat19Choice1 obj = new RatioFormat19Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "QtyToQty": obj.setQtyToQty(read_QuantityToQuantityRatio11(r)); break;
                case "AmtToAmt": obj.setAmtToAmt(read_AmountToAmountRatio21(r)); break;
                case "AmtToQty": obj.setAmtToQty(read_AmountAndQuantityRatio41(r)); break;
                case "QtyToAmt": obj.setQtyToAmt(read_AmountAndQuantityRatio41(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountAndQuantityRatio41 read_AmountAndQuantityRatio41(XMLStreamReader r) throws XMLStreamException {
        AmountAndQuantityRatio41 obj = new AmountAndQuantityRatio41();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "Qty": obj.setQty(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateFormat27Choice1 read_RateFormat27Choice1(XMLStreamReader r) throws XMLStreamException {
        RateFormat27Choice1 obj = new RateFormat27Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Rate": obj.setRate(new BigDecimal(r.getElementText())); break;
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionPrice831 read_CorporateActionPrice831(XMLStreamReader r) throws XMLStreamException {
        CorporateActionPrice831 obj = new CorporateActionPrice831();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CshInLieuOfShrPric": obj.setCshInLieuOfShrPric(read_PriceFormat77Choice2(r)); break;
                case "GncCshPricRcvdPerPdct": obj.setGncCshPricRcvdPerPdct(read_PriceFormat76Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat77Choice2 read_PriceFormat77Choice2(XMLStreamReader r) throws XMLStreamException {
        PriceFormat77Choice2 obj = new PriceFormat77Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PctgPric": obj.setPctgPric(read_PercentagePrice2(r)); break;
                case "AmtPric": obj.setAmtPric(read_AmountPrice32(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PercentagePrice2 read_PercentagePrice2(XMLStreamReader r) throws XMLStreamException {
        PercentagePrice2 obj = new PercentagePrice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PctgPricTp": obj.setPctgPricTp(PriceRateType3Code.fromValue(r.getElementText())); break;
                case "PricVal": obj.setPricVal(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountPrice32 read_AmountPrice32(XMLStreamReader r) throws XMLStreamException {
        AmountPrice32 obj = new AmountPrice32();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricTp": obj.setAmtPricTp(AmountPriceType1Code.fromValue(r.getElementText())); break;
                case "PricVal": obj.setPricVal(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat76Choice1 read_PriceFormat76Choice1(XMLStreamReader r) throws XMLStreamException {
        PriceFormat76Choice1 obj = new PriceFormat76Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricPerFinInstrmQty": obj.setAmtPricPerFinInstrmQty(read_AmountPricePerFinancialInstrumentQuantity101(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountPricePerFinancialInstrumentQuantity101 read_AmountPricePerFinancialInstrumentQuantity101(XMLStreamReader r) throws XMLStreamException {
        AmountPricePerFinancialInstrumentQuantity101 obj = new AmountPricePerFinancialInstrumentQuantity101();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricTp": obj.setAmtPricTp(AmountPriceType1Code2.fromValue(r.getElementText())); break;
                case "PricVal": obj.setPricVal(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "FinInstrmQty": obj.setFinInstrmQty(read_FinancialInstrumentQuantity33Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CashOption1051 read_CashOption1051(XMLStreamReader r) throws XMLStreamException {
        CashOption1051 obj = new CashOption1051();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "CdtDbtInd": obj.setCdtDbtInd(CreditDebitCode.fromValue(r.getElementText())); break;
                case "AmtDtls": obj.setAmtDtls(read_CorporateActionAmounts731(r)); break;
                case "DtDtls": obj.setDtDtls(read_CorporateActionDate991(r)); break;
                case "RateAndAmtDtls": obj.setRateAndAmtDtls(read_Rate411(r)); break;
                case "PricDtls": obj.setPricDtls(read_PriceDetails371(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionAmounts731 read_CorporateActionAmounts731(XMLStreamReader r) throws XMLStreamException {
        CorporateActionAmounts731 obj = new CorporateActionAmounts731();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PstngAmt": obj.setPstngAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "NetAmt": obj.setNetAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "SlctnFees": obj.setSlctnFees(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "CshInLieuOfShr": obj.setCshInLieuOfShr(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "CptlGn": obj.setCptlGn(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "IntrstAmt": obj.setIntrstAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "ChrgsAmt": obj.setChrgsAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "AcrdIntrstAmt": obj.setAcrdIntrstAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "DmdAmt": obj.setDmdAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "AdjstdSbcptAmt": obj.setAdjstdSbcptAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                case "RfnddSbcptAmt": obj.setRfnddSbcptAmt(read_RestrictedFINActiveCurrencyAndAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RestrictedFINActiveCurrencyAndAmount read_RestrictedFINActiveCurrencyAndAmount(XMLStreamReader r) throws XMLStreamException {
        RestrictedFINActiveCurrencyAndAmount obj = new RestrictedFINActiveCurrencyAndAmount();
        obj.setCcy(r.getAttributeValue(null, "Ccy"));
        obj.setValue(new BigDecimal(r.getElementText()));
        return obj;
    }

    private static CorporateActionDate991 read_CorporateActionDate991(XMLStreamReader r) throws XMLStreamException {
        CorporateActionDate991 obj = new CorporateActionDate991();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "PstngDt": obj.setPstngDt(read_DateAndDateTime2Choice(r)); break;
                case "PmtDt": obj.setPmtDt(DATATYPE_FACTORY.newXMLGregorianCalendar(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static Rate411 read_Rate411(XMLStreamReader r) throws XMLStreamException {
        Rate411 obj = new Rate411();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "ChrgsFees": obj.setChrgsFees(read_RateAndAmountFormat59Choice1(r)); break;
                case "GrssDstrbtnRate": obj.getGrssDstrbtnRate().add(read_GrossDividendRateFormat37Choice1(r)); break;
                case "GrssIntrstRateUsdForPmt": obj.getGrssIntrstRateUsdForPmt().add(read_InterestRateUsedForPaymentFormat12Choice1(r)); break;
                case "NetDstrbtnRate": obj.getNetDstrbtnRate().add(read_NetDividendRateFormat40Choice1(r)); break;
                case "TaxCdtRate": obj.setTaxCdtRate(read_RateFormat27Choice1(r)); break;
                case "DmdRate": obj.getDmdRate().add(read_RateAndAmountFormat62Choice1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateAndAmountFormat59Choice1 read_RateAndAmountFormat59Choice1(XMLStreamReader r) throws XMLStreamException {
        RateAndAmountFormat59Choice1 obj = new RateAndAmountFormat59Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Rate": obj.setRate(new BigDecimal(r.getElementText())); break;
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static GrossDividendRateFormat37Choice1 read_GrossDividendRateFormat37Choice1(XMLStreamReader r) throws XMLStreamException {
        GrossDividendRateFormat37Choice1 obj = new GrossDividendRateFormat37Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTpAndAmtAndRateSts": obj.setRateTpAndAmtAndRateSts(read_RateTypeAndAmountAndStatus571(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateTypeAndAmountAndStatus571 read_RateTypeAndAmountAndStatus571(XMLStreamReader r) throws XMLStreamException {
        RateTypeAndAmountAndStatus571 obj = new RateTypeAndAmountAndStatus571();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTp": obj.setRateTp(read_RateType78Choice1(r)); break;
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateType78Choice1 read_RateType78Choice1(XMLStreamReader r) throws XMLStreamException {
        RateType78Choice1 obj = new RateType78Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(GrossDividendRateType7Code1.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static InterestRateUsedForPaymentFormat12Choice1 read_InterestRateUsedForPaymentFormat12Choice1(XMLStreamReader r) throws XMLStreamException {
        InterestRateUsedForPaymentFormat12Choice1 obj = new InterestRateUsedForPaymentFormat12Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTpAndAmtAndRateSts": obj.setRateTpAndAmtAndRateSts(read_RateTypeAndAmountAndStatus241(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateTypeAndAmountAndStatus241 read_RateTypeAndAmountAndStatus241(XMLStreamReader r) throws XMLStreamException {
        RateTypeAndAmountAndStatus241 obj = new RateTypeAndAmountAndStatus241();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "RateTp": obj.setRateTp(read_RateType33Choice1(r)); break;
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateType33Choice1 read_RateType33Choice1(XMLStreamReader r) throws XMLStreamException {
        RateType33Choice1 obj = new RateType33Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Cd": obj.setCd(RateType7Code.fromValue(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static NetDividendRateFormat40Choice1 read_NetDividendRateFormat40Choice1(XMLStreamReader r) throws XMLStreamException {
        NetDividendRateFormat40Choice1 obj = new NetDividendRateFormat40Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static RateAndAmountFormat62Choice1 read_RateAndAmountFormat62Choice1(XMLStreamReader r) throws XMLStreamException {
        RateAndAmountFormat62Choice1 obj = new RateAndAmountFormat62Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Amt": obj.setAmt(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceDetails371 read_PriceDetails371(XMLStreamReader r) throws XMLStreamException {
        PriceDetails371 obj = new PriceDetails371();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "GncCshPricPdPerPdct": obj.setGncCshPricPdPerPdct(read_PriceFormat75Choice1(r)); break;
                case "GncCshPricRcvdPerPdct": obj.setGncCshPricRcvdPerPdct(read_PriceFormat76Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat75Choice1 read_PriceFormat75Choice1(XMLStreamReader r) throws XMLStreamException {
        PriceFormat75Choice1 obj = new PriceFormat75Choice1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPric": obj.setAmtPric(read_AmountPrice31(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static PriceFormat76Choice2 read_PriceFormat76Choice2(XMLStreamReader r) throws XMLStreamException {
        PriceFormat76Choice2 obj = new PriceFormat76Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricPerFinInstrmQty": obj.setAmtPricPerFinInstrmQty(read_AmountPricePerFinancialInstrumentQuantity102(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static AmountPricePerFinancialInstrumentQuantity102 read_AmountPricePerFinancialInstrumentQuantity102(XMLStreamReader r) throws XMLStreamException {
        AmountPricePerFinancialInstrumentQuantity102 obj = new AmountPricePerFinancialInstrumentQuantity102();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AmtPricTp": obj.setAmtPricTp(AmountPriceType1Code2.fromValue(r.getElementText())); break;
                case "PricVal": obj.setPricVal(read_RestrictedFINActiveCurrencyAnd13DecimalAmount(r)); break;
                case "FinInstrmQty": obj.setFinInstrmQty(read_FinancialInstrumentQuantity33Choice2(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static FinancialInstrumentQuantity33Choice2 read_FinancialInstrumentQuantity33Choice2(XMLStreamReader r) throws XMLStreamException {
        FinancialInstrumentQuantity33Choice2 obj = new FinancialInstrumentQuantity33Choice2();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Unit": obj.setUnit(new BigDecimal(r.getElementText())); break;
                case "FaceAmt": obj.setFaceAmt(new BigDecimal(r.getElementText())); break;
                case "DgtlTknUnit": obj.setDgtlTknUnit(new BigDecimal(r.getElementText())); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static CorporateActionNarrative311 read_CorporateActionNarrative311(XMLStreamReader r) throws XMLStreamException {
        CorporateActionNarrative311 obj = new CorporateActionNarrative311();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "AddtlTxt": obj.getAddtlTxt().add(r.getElementText()); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SupplementaryData11 read_SupplementaryData11(XMLStreamReader r) throws XMLStreamException {
        SupplementaryData11 obj = new SupplementaryData11();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                case "Envlp": obj.setEnvlp(read_SupplementaryDataEnvelope1(r)); break;
                default: skip(r); break;
            }
        }
        return obj;
    }

    private static SupplementaryDataEnvelope1 read_SupplementaryDataEnvelope1(XMLStreamReader r) throws XMLStreamException {
        SupplementaryDataEnvelope1 obj = new SupplementaryDataEnvelope1();
        for (int ev = r.next(); ev != XMLStreamConstants.END_ELEMENT; ev = r.next()) {
            if (ev != XMLStreamConstants.START_ELEMENT) continue;
            switch (r.getLocalName()) {
                default: obj.setAny(r.getElementText()); break;
            }
        }
        return obj;
    }

    private static void skip(XMLStreamReader r) throws XMLStreamException {
        int depth = 1;
        while (depth > 0) {
            int ev = r.next();
            if (ev == XMLStreamConstants.START_ELEMENT) depth++;
            else if (ev == XMLStreamConstants.END_ELEMENT) depth--;
        }
    }
}
