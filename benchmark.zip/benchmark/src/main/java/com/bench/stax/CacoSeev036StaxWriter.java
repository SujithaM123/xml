package com.bench.stax;

import com.bench.caco.seev036.*;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.ByteArrayOutputStream;

/** Hand-written-style StAX writer for CacoSeev036 (generated once from the xjc POJOs; no reflection or JAXB marshalling at runtime). */
public final class CacoSeev036StaxWriter {

    private static final XMLOutputFactory OUTPUT_FACTORY = XMLOutputFactory.newFactory();

    private CacoSeev036StaxWriter() {
    }

    public static byte[] write(Document doc) throws XMLStreamException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        XMLStreamWriter w = OUTPUT_FACTORY.createXMLStreamWriter(out, "UTF-8");
        w.writeStartDocument("UTF-8", "1.0");
        write_Document(w, "Document", doc);
        w.writeEndDocument();
        w.flush();
        w.close();
        return out.toByteArray();
    }

    private static void write_Document(XMLStreamWriter w, String tag, Document obj) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeDefaultNamespace("urn:iso:std:iso:20022:tech:xsd:seev.036.001.16");
        if (obj.getCorpActnMvmntConf() != null) write_CorporateActionMovementConfirmationV16(w, "CorpActnMvmntConf", obj.getCorpActnMvmntConf());
        w.writeEndElement();
    }

    private static void write_CorporateActionMovementConfirmationV16(XMLStreamWriter w, String tag, CorporateActionMovementConfirmationV16 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPgntn() != null) write_Pagination1(w, "Pgntn", obj.getPgntn());
        if (obj.getMvmntConfId() != null) writeLeaf(w, "MvmntConfId", obj.getMvmntConfId());
        if (obj.getMvmntPrlimryAdvcId() != null) write_DocumentIdentification311(w, "MvmntPrlimryAdvcId", obj.getMvmntPrlimryAdvcId());
        if (obj.getCorpActnGnlInf() != null) write_CorporateActionGeneralInformation1791(w, "CorpActnGnlInf", obj.getCorpActnGnlInf());
        if (obj.getAcctDtls() != null) write_AccountAndBalance581(w, "AcctDtls", obj.getAcctDtls());
        if (obj.getCorpActnDtls() != null) write_CorporateAction851(w, "CorpActnDtls", obj.getCorpActnDtls());
        if (obj.getCorpActnConfDtls() != null) write_CorporateActionOption2331(w, "CorpActnConfDtls", obj.getCorpActnConfDtls());
        if (obj.getAddtlInf() != null) write_CorporateActionNarrative311(w, "AddtlInf", obj.getAddtlInf());
        for (SupplementaryData11 item : obj.getSplmtryData()) write_SupplementaryData11(w, "SplmtryData", item);
        w.writeEndElement();
    }

    private static void write_Pagination1(XMLStreamWriter w, String tag, Pagination1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPgNb() != null) writeLeaf(w, "PgNb", obj.getPgNb());
        writeLeaf(w, "LastPgInd", String.valueOf(obj.isLastPgInd()));
        w.writeEndElement();
    }

    private static void write_DocumentIdentification311(XMLStreamWriter w, String tag, DocumentIdentification311 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        w.writeEndElement();
    }

    private static void write_CorporateActionGeneralInformation1791(XMLStreamWriter w, String tag, CorporateActionGeneralInformation1791 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCorpActnEvtId() != null) writeLeaf(w, "CorpActnEvtId", obj.getCorpActnEvtId());
        if (obj.getOffclCorpActnEvtId() != null) writeLeaf(w, "OffclCorpActnEvtId", obj.getOffclCorpActnEvtId());
        if (obj.getEvtTp() != null) write_CorporateActionEventType109Choice1(w, "EvtTp", obj.getEvtTp());
        if (obj.getFinInstrmId() != null) write_SecurityIdentification191(w, "FinInstrmId", obj.getFinInstrmId());
        w.writeEndElement();
    }

    private static void write_CorporateActionEventType109Choice1(XMLStreamWriter w, String tag, CorporateActionEventType109Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_SecurityIdentification191(XMLStreamWriter w, String tag, SecurityIdentification191 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getISIN() != null) writeLeaf(w, "ISIN", obj.getISIN());
        for (OtherIdentification11 item : obj.getOthrId()) write_OtherIdentification11(w, "OthrId", item);
        if (obj.getDesc() != null) writeLeaf(w, "Desc", obj.getDesc());
        w.writeEndElement();
    }

    private static void write_OtherIdentification11(XMLStreamWriter w, String tag, OtherIdentification11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        if (obj.getTp() != null) write_IdentificationSource3Choice1(w, "Tp", obj.getTp());
        w.writeEndElement();
    }

    private static void write_IdentificationSource3Choice1(XMLStreamWriter w, String tag, IdentificationSource3Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd());
        if (obj.getPrtry() != null) writeLeaf(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_AccountAndBalance581(XMLStreamWriter w, String tag, AccountAndBalance581 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getSfkpgAcct() != null) writeLeaf(w, "SfkpgAcct", obj.getSfkpgAcct());
        if (obj.getBal() != null) write_CorporateActionBalanceDetails411(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_CorporateActionBalanceDetails411(XMLStreamWriter w, String tag, CorporateActionBalanceDetails411 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getConfdBal() != null) write_BalanceFormat11Choice1(w, "ConfdBal", obj.getConfdBal());
        if (obj.getTtlElgblBal() != null) write_TotalEligibleBalanceFormat101(w, "TtlElgblBal", obj.getTtlElgblBal());
        if (obj.getBrrwdBal() != null) write_BalanceFormat11Choice1(w, "BrrwdBal", obj.getBrrwdBal());
        if (obj.getCollInBal() != null) write_BalanceFormat11Choice1(w, "CollInBal", obj.getCollInBal());
        if (obj.getCollOutBal() != null) write_BalanceFormat11Choice1(w, "CollOutBal", obj.getCollOutBal());
        if (obj.getOnLnBal() != null) write_BalanceFormat11Choice1(w, "OnLnBal", obj.getOnLnBal());
        if (obj.getPdgDlvryBal() != null) write_BalanceFormat12Choice1(w, "PdgDlvryBal", obj.getPdgDlvryBal());
        if (obj.getPdgRctBal() != null) write_BalanceFormat12Choice1(w, "PdgRctBal", obj.getPdgRctBal());
        if (obj.getStlmPosBal() != null) write_BalanceFormat12Choice1(w, "StlmPosBal", obj.getStlmPosBal());
        if (obj.getAfctdBal() != null) write_BalanceFormat11Choice2(w, "AfctdBal", obj.getAfctdBal());
        if (obj.getUafctdBal() != null) write_BalanceFormat11Choice2(w, "UafctdBal", obj.getUafctdBal());
        w.writeEndElement();
    }

    private static void write_BalanceFormat11Choice1(XMLStreamWriter w, String tag, BalanceFormat11Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat111(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat111(XMLStreamWriter w, String tag, SignedQuantityFormat111 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQtyChc() != null) write_Quantity48Choice1(w, "QtyChc", obj.getQtyChc());
        w.writeEndElement();
    }

    private static void write_Quantity48Choice1(XMLStreamWriter w, String tag, Quantity48Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity33Choice1(XMLStreamWriter w, String tag, FinancialInstrumentQuantity33Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        w.writeEndElement();
    }

    private static void write_TotalEligibleBalanceFormat101(XMLStreamWriter w, String tag, TotalEligibleBalanceFormat101 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_Quantity49Choice1(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_Quantity49Choice1(XMLStreamWriter w, String tag, Quantity49Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQtyChc() != null) write_Quantity50Choice1(w, "QtyChc", obj.getQtyChc());
        w.writeEndElement();
    }

    private static void write_Quantity50Choice1(XMLStreamWriter w, String tag, Quantity50Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getSgndQty() != null) write_SignedQuantityFormat101(w, "SgndQty", obj.getSgndQty());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat101(XMLStreamWriter w, String tag, SignedQuantityFormat101 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_BalanceFormat12Choice1(XMLStreamWriter w, String tag, BalanceFormat12Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat111(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_BalanceFormat11Choice2(XMLStreamWriter w, String tag, BalanceFormat11Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getBal() != null) write_SignedQuantityFormat112(w, "Bal", obj.getBal());
        w.writeEndElement();
    }

    private static void write_SignedQuantityFormat112(XMLStreamWriter w, String tag, SignedQuantityFormat112 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getShrtLngPos() != null) writeLeaf(w, "ShrtLngPos", obj.getShrtLngPos().value());
        if (obj.getQtyChc() != null) write_Quantity48Choice1(w, "QtyChc", obj.getQtyChc());
        w.writeEndElement();
    }

    private static void write_CorporateAction851(XMLStreamWriter w, String tag, CorporateAction851 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDtDtls() != null) write_CorporateActionDate861(w, "DtDtls", obj.getDtDtls());
        if (obj.getEvtStag() != null) write_CorporateActionEventStageFormat14Choice1(w, "EvtStag", obj.getEvtStag());
        for (AdditionalBusinessProcessFormat23Choice1 item : obj.getAddtlBizPrcInd()) write_AdditionalBusinessProcessFormat23Choice1(w, "AddtlBizPrcInd", item);
        if (obj.getIntrmdtSctiesDstrbtnTp() != null) write_IntermediateSecuritiesDistributionTypeFormat15Choice1(w, "IntrmdtSctiesDstrbtnTp", obj.getIntrmdtSctiesDstrbtnTp());
        if (obj.getLtryTp() != null) write_LotteryTypeFormat4Choice1(w, "LtryTp", obj.getLtryTp());
        w.writeEndElement();
    }

    private static void write_CorporateActionDate861(XMLStreamWriter w, String tag, CorporateActionDate861 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRcrdDt() != null) write_DateFormat30Choice1(w, "RcrdDt", obj.getRcrdDt());
        if (obj.getExDvddDt() != null) write_DateFormat30Choice1(w, "ExDvddDt", obj.getExDvddDt());
        w.writeEndElement();
    }

    private static void write_DateFormat30Choice1(XMLStreamWriter w, String tag, DateFormat30Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) writeLeaf(w, "Dt", obj.getDt().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_CorporateActionEventStageFormat14Choice1(XMLStreamWriter w, String tag, CorporateActionEventStageFormat14Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_AdditionalBusinessProcessFormat23Choice1(XMLStreamWriter w, String tag, AdditionalBusinessProcessFormat23Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_IntermediateSecuritiesDistributionTypeFormat15Choice1(XMLStreamWriter w, String tag, IntermediateSecuritiesDistributionTypeFormat15Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        if (obj.getPrtry() != null) write_GenericIdentification301(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_GenericIdentification301(XMLStreamWriter w, String tag, GenericIdentification301 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getId() != null) writeLeaf(w, "Id", obj.getId());
        if (obj.getIssr() != null) writeLeaf(w, "Issr", obj.getIssr());
        if (obj.getSchmeNm() != null) writeLeaf(w, "SchmeNm", obj.getSchmeNm());
        w.writeEndElement();
    }

    private static void write_LotteryTypeFormat4Choice1(XMLStreamWriter w, String tag, LotteryTypeFormat4Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_CorporateActionOption2331(XMLStreamWriter w, String tag, CorporateActionOption2331 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getOptnNb() != null) write_OptionNumber1Choice1(w, "OptnNb", obj.getOptnNb());
        if (obj.getOptnTp() != null) write_CorporateActionOption33Choice1(w, "OptnTp", obj.getOptnTp());
        for (OptionFeaturesFormat29Choice1 item : obj.getOptnFeatrs()) write_OptionFeaturesFormat29Choice1(w, "OptnFeatrs", item);
        if (obj.getRateAndAmtDtls() != null) write_CorporateActionRate1201(w, "RateAndAmtDtls", obj.getRateAndAmtDtls());
        if (obj.getPricDtls() != null) write_CorporateActionPrice841(w, "PricDtls", obj.getPricDtls());
        for (SecuritiesOption1121 item : obj.getSctiesMvmntDtls()) write_SecuritiesOption1121(w, "SctiesMvmntDtls", item);
        for (CashOption1051 item : obj.getCshMvmntDtls()) write_CashOption1051(w, "CshMvmntDtls", item);
        w.writeEndElement();
    }

    private static void write_OptionNumber1Choice1(XMLStreamWriter w, String tag, OptionNumber1Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getNb() != null) writeLeaf(w, "Nb", obj.getNb());
        w.writeEndElement();
    }

    private static void write_CorporateActionOption33Choice1(XMLStreamWriter w, String tag, CorporateActionOption33Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        if (obj.getPrtry() != null) write_GenericIdentification301(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_OptionFeaturesFormat29Choice1(XMLStreamWriter w, String tag, OptionFeaturesFormat29Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        if (obj.getPrtry() != null) write_GenericIdentification301(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_CorporateActionRate1201(XMLStreamWriter w, String tag, CorporateActionRate1201 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPrratnRate() != null) writeLeaf(w, "PrratnRate", obj.getPrratnRate().toString());
        for (RateTypeAndAmountAndStatus261 item : obj.getTaxblIncmPerDvddShr()) write_RateTypeAndAmountAndStatus261(w, "TaxblIncmPerDvddShr", item);
        w.writeEndElement();
    }

    private static void write_RateTypeAndAmountAndStatus261(XMLStreamWriter w, String tag, RateTypeAndAmountAndStatus261 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTp() != null) write_RateType36Choice1(w, "RateTp", obj.getRateTp());
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        if (obj.getRateSts() != null) write_RateStatus3Choice1(w, "RateSts", obj.getRateSts());
        w.writeEndElement();
    }

    private static void write_RateType36Choice1(XMLStreamWriter w, String tag, RateType36Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        if (obj.getPrtry() != null) write_GenericIdentification301(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_RestrictedFINActiveCurrencyAnd13DecimalAmount(XMLStreamWriter w, String tag, RestrictedFINActiveCurrencyAnd13DecimalAmount obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCcy() != null) w.writeAttribute("Ccy", obj.getCcy());
        w.writeCharacters(obj.getValue().toString());
        w.writeEndElement();
    }

    private static void write_RateStatus3Choice1(XMLStreamWriter w, String tag, RateStatus3Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        if (obj.getPrtry() != null) write_GenericIdentification301(w, "Prtry", obj.getPrtry());
        w.writeEndElement();
    }

    private static void write_CorporateActionPrice841(XMLStreamWriter w, String tag, CorporateActionPrice841 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getOverSbcptDpstPric() != null) write_PriceFormat77Choice1(w, "OverSbcptDpstPric", obj.getOverSbcptDpstPric());
        w.writeEndElement();
    }

    private static void write_PriceFormat77Choice1(XMLStreamWriter w, String tag, PriceFormat77Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPric() != null) write_AmountPrice31(w, "AmtPric", obj.getAmtPric());
        w.writeEndElement();
    }

    private static void write_AmountPrice31(XMLStreamWriter w, String tag, AmountPrice31 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricTp() != null) writeLeaf(w, "AmtPricTp", obj.getAmtPricTp().value());
        if (obj.getPricVal() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "PricVal", obj.getPricVal());
        w.writeEndElement();
    }

    private static void write_SecuritiesOption1121(XMLStreamWriter w, String tag, SecuritiesOption1121 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getFinInstrmId() != null) write_SecurityIdentification191(w, "FinInstrmId", obj.getFinInstrmId());
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getTempFinInstrmInd() != null) write_TemporaryFinancialInstrumentIndicator3Choice1(w, "TempFinInstrmInd", obj.getTempFinInstrmInd());
        if (obj.getNewSctiesIssncInd() != null) writeLeaf(w, "NewSctiesIssncInd", obj.getNewSctiesIssncInd().value());
        if (obj.getPstngQty() != null) write_Quantity51Choice1(w, "PstngQty", obj.getPstngQty());
        if (obj.getFrctnDspstn() != null) write_FractionDispositionType27Choice1(w, "FrctnDspstn", obj.getFrctnDspstn());
        if (obj.getDtDtls() != null) write_SecurityDate251(w, "DtDtls", obj.getDtDtls());
        if (obj.getRateDtls() != null) write_CorporateActionRate1251(w, "RateDtls", obj.getRateDtls());
        if (obj.getPricDtls() != null) write_CorporateActionPrice831(w, "PricDtls", obj.getPricDtls());
        w.writeEndElement();
    }

    private static void write_TemporaryFinancialInstrumentIndicator3Choice1(XMLStreamWriter w, String tag, TemporaryFinancialInstrumentIndicator3Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.isTempInd() != null) writeLeaf(w, "TempInd", String.valueOf(obj.isTempInd()));
        w.writeEndElement();
    }

    private static void write_Quantity51Choice1(XMLStreamWriter w, String tag, Quantity51Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "Qty", obj.getQty());
        w.writeEndElement();
    }

    private static void write_FractionDispositionType27Choice1(XMLStreamWriter w, String tag, FractionDispositionType27Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_SecurityDate251(XMLStreamWriter w, String tag, SecurityDate251 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPstngDt() != null) write_DateAndDateTime2Choice(w, "PstngDt", obj.getPstngDt());
        if (obj.getPmtDt() != null) write_DateFormat30Choice1(w, "PmtDt", obj.getPmtDt());
        w.writeEndElement();
    }

    private static void write_DateAndDateTime2Choice(XMLStreamWriter w, String tag, DateAndDateTime2Choice obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getDt() != null) writeLeaf(w, "Dt", obj.getDt().toXMLFormat());
        if (obj.getDtTm() != null) writeLeaf(w, "DtTm", obj.getDtTm().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_CorporateActionRate1251(XMLStreamWriter w, String tag, CorporateActionRate1251 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAddtlQtyForExstgScties() != null) write_RatioFormat20Choice1(w, "AddtlQtyForExstgScties", obj.getAddtlQtyForExstgScties());
        if (obj.getNewToOd() != null) write_RatioFormat19Choice1(w, "NewToOd", obj.getNewToOd());
        if (obj.getTaxCdtRate() != null) write_RateFormat27Choice1(w, "TaxCdtRate", obj.getTaxCdtRate());
        w.writeEndElement();
    }

    private static void write_RatioFormat20Choice1(XMLStreamWriter w, String tag, RatioFormat20Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQtyToQty() != null) write_QuantityToQuantityRatio11(w, "QtyToQty", obj.getQtyToQty());
        if (obj.getAmtToAmt() != null) write_AmountToAmountRatio21(w, "AmtToAmt", obj.getAmtToAmt());
        w.writeEndElement();
    }

    private static void write_QuantityToQuantityRatio11(XMLStreamWriter w, String tag, QuantityToQuantityRatio11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQty1() != null) writeLeaf(w, "Qty1", obj.getQty1().toString());
        if (obj.getQty2() != null) writeLeaf(w, "Qty2", obj.getQty2().toString());
        w.writeEndElement();
    }

    private static void write_AmountToAmountRatio21(XMLStreamWriter w, String tag, AmountToAmountRatio21 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt1() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt1", obj.getAmt1());
        if (obj.getAmt2() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt2", obj.getAmt2());
        w.writeEndElement();
    }

    private static void write_RatioFormat19Choice1(XMLStreamWriter w, String tag, RatioFormat19Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getQtyToQty() != null) write_QuantityToQuantityRatio11(w, "QtyToQty", obj.getQtyToQty());
        if (obj.getAmtToAmt() != null) write_AmountToAmountRatio21(w, "AmtToAmt", obj.getAmtToAmt());
        if (obj.getAmtToQty() != null) write_AmountAndQuantityRatio41(w, "AmtToQty", obj.getAmtToQty());
        if (obj.getQtyToAmt() != null) write_AmountAndQuantityRatio41(w, "QtyToAmt", obj.getQtyToAmt());
        w.writeEndElement();
    }

    private static void write_AmountAndQuantityRatio41(XMLStreamWriter w, String tag, AmountAndQuantityRatio41 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        if (obj.getQty() != null) writeLeaf(w, "Qty", obj.getQty().toString());
        w.writeEndElement();
    }

    private static void write_RateFormat27Choice1(XMLStreamWriter w, String tag, RateFormat27Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRate() != null) writeLeaf(w, "Rate", obj.getRate().toString());
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_CorporateActionPrice831(XMLStreamWriter w, String tag, CorporateActionPrice831 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCshInLieuOfShrPric() != null) write_PriceFormat77Choice2(w, "CshInLieuOfShrPric", obj.getCshInLieuOfShrPric());
        if (obj.getGncCshPricRcvdPerPdct() != null) write_PriceFormat76Choice1(w, "GncCshPricRcvdPerPdct", obj.getGncCshPricRcvdPerPdct());
        w.writeEndElement();
    }

    private static void write_PriceFormat77Choice2(XMLStreamWriter w, String tag, PriceFormat77Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPctgPric() != null) write_PercentagePrice2(w, "PctgPric", obj.getPctgPric());
        if (obj.getAmtPric() != null) write_AmountPrice32(w, "AmtPric", obj.getAmtPric());
        w.writeEndElement();
    }

    private static void write_PercentagePrice2(XMLStreamWriter w, String tag, PercentagePrice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPctgPricTp() != null) writeLeaf(w, "PctgPricTp", obj.getPctgPricTp().value());
        if (obj.getPricVal() != null) writeLeaf(w, "PricVal", obj.getPricVal().toString());
        w.writeEndElement();
    }

    private static void write_AmountPrice32(XMLStreamWriter w, String tag, AmountPrice32 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricTp() != null) writeLeaf(w, "AmtPricTp", obj.getAmtPricTp().value());
        if (obj.getPricVal() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "PricVal", obj.getPricVal());
        w.writeEndElement();
    }

    private static void write_PriceFormat76Choice1(XMLStreamWriter w, String tag, PriceFormat76Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricPerFinInstrmQty() != null) write_AmountPricePerFinancialInstrumentQuantity101(w, "AmtPricPerFinInstrmQty", obj.getAmtPricPerFinInstrmQty());
        w.writeEndElement();
    }

    private static void write_AmountPricePerFinancialInstrumentQuantity101(XMLStreamWriter w, String tag, AmountPricePerFinancialInstrumentQuantity101 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricTp() != null) writeLeaf(w, "AmtPricTp", obj.getAmtPricTp().value());
        if (obj.getPricVal() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "PricVal", obj.getPricVal());
        if (obj.getFinInstrmQty() != null) write_FinancialInstrumentQuantity33Choice1(w, "FinInstrmQty", obj.getFinInstrmQty());
        w.writeEndElement();
    }

    private static void write_CashOption1051(XMLStreamWriter w, String tag, CashOption1051 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCdtDbtInd() != null) writeLeaf(w, "CdtDbtInd", obj.getCdtDbtInd().value());
        if (obj.getAmtDtls() != null) write_CorporateActionAmounts731(w, "AmtDtls", obj.getAmtDtls());
        if (obj.getDtDtls() != null) write_CorporateActionDate991(w, "DtDtls", obj.getDtDtls());
        if (obj.getRateAndAmtDtls() != null) write_Rate411(w, "RateAndAmtDtls", obj.getRateAndAmtDtls());
        if (obj.getPricDtls() != null) write_PriceDetails371(w, "PricDtls", obj.getPricDtls());
        w.writeEndElement();
    }

    private static void write_CorporateActionAmounts731(XMLStreamWriter w, String tag, CorporateActionAmounts731 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPstngAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "PstngAmt", obj.getPstngAmt());
        if (obj.getNetAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "NetAmt", obj.getNetAmt());
        if (obj.getSlctnFees() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "SlctnFees", obj.getSlctnFees());
        if (obj.getCshInLieuOfShr() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "CshInLieuOfShr", obj.getCshInLieuOfShr());
        if (obj.getCptlGn() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "CptlGn", obj.getCptlGn());
        if (obj.getIntrstAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "IntrstAmt", obj.getIntrstAmt());
        if (obj.getChrgsAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "ChrgsAmt", obj.getChrgsAmt());
        if (obj.getAcrdIntrstAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "AcrdIntrstAmt", obj.getAcrdIntrstAmt());
        if (obj.getDmdAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "DmdAmt", obj.getDmdAmt());
        if (obj.getAdjstdSbcptAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "AdjstdSbcptAmt", obj.getAdjstdSbcptAmt());
        if (obj.getRfnddSbcptAmt() != null) write_RestrictedFINActiveCurrencyAndAmount(w, "RfnddSbcptAmt", obj.getRfnddSbcptAmt());
        w.writeEndElement();
    }

    private static void write_RestrictedFINActiveCurrencyAndAmount(XMLStreamWriter w, String tag, RestrictedFINActiveCurrencyAndAmount obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCcy() != null) w.writeAttribute("Ccy", obj.getCcy());
        w.writeCharacters(obj.getValue().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionDate991(XMLStreamWriter w, String tag, CorporateActionDate991 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getPstngDt() != null) write_DateAndDateTime2Choice(w, "PstngDt", obj.getPstngDt());
        if (obj.getPmtDt() != null) writeLeaf(w, "PmtDt", obj.getPmtDt().toXMLFormat());
        w.writeEndElement();
    }

    private static void write_Rate411(XMLStreamWriter w, String tag, Rate411 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getChrgsFees() != null) write_RateAndAmountFormat59Choice1(w, "ChrgsFees", obj.getChrgsFees());
        for (GrossDividendRateFormat37Choice1 item : obj.getGrssDstrbtnRate()) write_GrossDividendRateFormat37Choice1(w, "GrssDstrbtnRate", item);
        for (InterestRateUsedForPaymentFormat12Choice1 item : obj.getGrssIntrstRateUsdForPmt()) write_InterestRateUsedForPaymentFormat12Choice1(w, "GrssIntrstRateUsdForPmt", item);
        for (NetDividendRateFormat40Choice1 item : obj.getNetDstrbtnRate()) write_NetDividendRateFormat40Choice1(w, "NetDstrbtnRate", item);
        if (obj.getTaxCdtRate() != null) write_RateFormat27Choice1(w, "TaxCdtRate", obj.getTaxCdtRate());
        for (RateAndAmountFormat62Choice1 item : obj.getDmdRate()) write_RateAndAmountFormat62Choice1(w, "DmdRate", item);
        w.writeEndElement();
    }

    private static void write_RateAndAmountFormat59Choice1(XMLStreamWriter w, String tag, RateAndAmountFormat59Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRate() != null) writeLeaf(w, "Rate", obj.getRate().toString());
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_GrossDividendRateFormat37Choice1(XMLStreamWriter w, String tag, GrossDividendRateFormat37Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTpAndAmtAndRateSts() != null) write_RateTypeAndAmountAndStatus571(w, "RateTpAndAmtAndRateSts", obj.getRateTpAndAmtAndRateSts());
        w.writeEndElement();
    }

    private static void write_RateTypeAndAmountAndStatus571(XMLStreamWriter w, String tag, RateTypeAndAmountAndStatus571 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTp() != null) write_RateType78Choice1(w, "RateTp", obj.getRateTp());
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_RateType78Choice1(XMLStreamWriter w, String tag, RateType78Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_InterestRateUsedForPaymentFormat12Choice1(XMLStreamWriter w, String tag, InterestRateUsedForPaymentFormat12Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTpAndAmtAndRateSts() != null) write_RateTypeAndAmountAndStatus241(w, "RateTpAndAmtAndRateSts", obj.getRateTpAndAmtAndRateSts());
        w.writeEndElement();
    }

    private static void write_RateTypeAndAmountAndStatus241(XMLStreamWriter w, String tag, RateTypeAndAmountAndStatus241 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getRateTp() != null) write_RateType33Choice1(w, "RateTp", obj.getRateTp());
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_RateType33Choice1(XMLStreamWriter w, String tag, RateType33Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getCd() != null) writeLeaf(w, "Cd", obj.getCd().value());
        w.writeEndElement();
    }

    private static void write_NetDividendRateFormat40Choice1(XMLStreamWriter w, String tag, NetDividendRateFormat40Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_RateAndAmountFormat62Choice1(XMLStreamWriter w, String tag, RateAndAmountFormat62Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmt() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "Amt", obj.getAmt());
        w.writeEndElement();
    }

    private static void write_PriceDetails371(XMLStreamWriter w, String tag, PriceDetails371 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getGncCshPricPdPerPdct() != null) write_PriceFormat75Choice1(w, "GncCshPricPdPerPdct", obj.getGncCshPricPdPerPdct());
        if (obj.getGncCshPricRcvdPerPdct() != null) write_PriceFormat76Choice2(w, "GncCshPricRcvdPerPdct", obj.getGncCshPricRcvdPerPdct());
        w.writeEndElement();
    }

    private static void write_PriceFormat75Choice1(XMLStreamWriter w, String tag, PriceFormat75Choice1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPric() != null) write_AmountPrice31(w, "AmtPric", obj.getAmtPric());
        w.writeEndElement();
    }

    private static void write_PriceFormat76Choice2(XMLStreamWriter w, String tag, PriceFormat76Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricPerFinInstrmQty() != null) write_AmountPricePerFinancialInstrumentQuantity102(w, "AmtPricPerFinInstrmQty", obj.getAmtPricPerFinInstrmQty());
        w.writeEndElement();
    }

    private static void write_AmountPricePerFinancialInstrumentQuantity102(XMLStreamWriter w, String tag, AmountPricePerFinancialInstrumentQuantity102 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAmtPricTp() != null) writeLeaf(w, "AmtPricTp", obj.getAmtPricTp().value());
        if (obj.getPricVal() != null) write_RestrictedFINActiveCurrencyAnd13DecimalAmount(w, "PricVal", obj.getPricVal());
        if (obj.getFinInstrmQty() != null) write_FinancialInstrumentQuantity33Choice2(w, "FinInstrmQty", obj.getFinInstrmQty());
        w.writeEndElement();
    }

    private static void write_FinancialInstrumentQuantity33Choice2(XMLStreamWriter w, String tag, FinancialInstrumentQuantity33Choice2 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getUnit() != null) writeLeaf(w, "Unit", obj.getUnit().toString());
        if (obj.getFaceAmt() != null) writeLeaf(w, "FaceAmt", obj.getFaceAmt().toString());
        if (obj.getDgtlTknUnit() != null) writeLeaf(w, "DgtlTknUnit", obj.getDgtlTknUnit().toString());
        w.writeEndElement();
    }

    private static void write_CorporateActionNarrative311(XMLStreamWriter w, String tag, CorporateActionNarrative311 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        for (String item : obj.getAddtlTxt()) writeLeaf(w, "AddtlTxt", item);
        w.writeEndElement();
    }

    private static void write_SupplementaryData11(XMLStreamWriter w, String tag, SupplementaryData11 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getEnvlp() != null) write_SupplementaryDataEnvelope1(w, "Envlp", obj.getEnvlp());
        w.writeEndElement();
    }

    private static void write_SupplementaryDataEnvelope1(XMLStreamWriter w, String tag, SupplementaryDataEnvelope1 obj) throws XMLStreamException {
        w.writeStartElement(tag);
        if (obj.getAny() != null) writeLeaf(w, "SplmtryInfo", String.valueOf(obj.getAny()));
        w.writeEndElement();
    }

    private static void writeLeaf(XMLStreamWriter w, String tag, String text) throws XMLStreamException {
        w.writeStartElement(tag);
        w.writeCharacters(text);
        w.writeEndElement();
    }
}
