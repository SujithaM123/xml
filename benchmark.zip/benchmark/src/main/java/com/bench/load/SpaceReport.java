package com.bench.load;

import com.bench.stax.*;
import org.openjdk.jol.info.GraphLayout;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Function;

/**
 * For each (message type x size), measures input XML size, in-memory POJO size (JOL), and
 * output XML size, and writes them to results/space.json for the summary script.
 */
public final class SpaceReport {

    private record TypeBinding(String typeKey, Function<byte[], Object> read, Function<Object, byte[]> write) {
    }

    private static final List<TypeBinding> BINDINGS = List.of(
            new TypeBinding("capa_seev035",
                    bytes -> unchecked(() -> CapaSeev035StaxReader.read(bytes)),
                    obj -> unchecked(() -> CapaSeev035StaxWriter.write((com.bench.capa.seev035.Document) obj))),
            new TypeBinding("capa_supl009",
                    bytes -> unchecked(() -> CapaSupl009StaxReader.read(bytes)),
                    obj -> unchecked(() -> CapaSupl009StaxWriter.write((com.bench.capa.supl009.Document) obj))),
            new TypeBinding("caco_seev036",
                    bytes -> unchecked(() -> CacoSeev036StaxReader.read(bytes)),
                    obj -> unchecked(() -> CacoSeev036StaxWriter.write((com.bench.caco.seev036.Document) obj))),
            new TypeBinding("caco_supl011",
                    bytes -> unchecked(() -> CacoSupl011StaxReader.read(bytes)),
                    obj -> unchecked(() -> CacoSupl011StaxWriter.write((com.bench.caco.supl011.Document) obj)))
    );

    private static final String[] SIZES = {"small", "medium", "large", "xlarge", "xxl"};

    public static void main(String[] args) throws Exception {
        StringBuilder json = new StringBuilder("[\n");
        boolean first = true;

        System.out.println("Type           Size     InputKB   PojoKB    OutputKB");
        System.out.println("----           ----     -------   ------    --------");

        for (TypeBinding binding : BINDINGS) {
            for (String size : SIZES) {
                Path file = Path.of("samples", binding.typeKey(), size, "sample_1.xml");
                byte[] input = Files.readAllBytes(file);
                Object pojo = binding.read().apply(input);
                long pojoBytes = GraphLayout.parseInstance(pojo).totalSize();
                byte[] output = binding.write().apply(pojo);

                double inputKB = input.length / 1024.0;
                double pojoKB = pojoBytes / 1024.0;
                double outputKB = output.length / 1024.0;

                System.out.printf("%-14s %-8s %-9.2f %-9.2f %-9.2f%n", binding.typeKey(), size, inputKB, pojoKB, outputKB);

                if (!first) json.append(",\n");
                first = false;
                json.append(String.format(java.util.Locale.ROOT,
                        "  {\"type\": \"%s\", \"size\": \"%s\", \"inputKB\": %.3f, \"pojoKB\": %.3f, \"outputKB\": %.3f}",
                        binding.typeKey(), size, inputKB, pojoKB, outputKB));
            }
        }
        json.append("\n]\n");

        new File("results").mkdirs();
        Files.writeString(Path.of("results", "space.json"), json.toString());
        System.out.println("\nWritten to results/space.json");
    }

    private interface ThrowingSupplier<T> {
        T get() throws Exception;
    }

    private static <T> T unchecked(ThrowingSupplier<T> supplier) {
        try {
            return supplier.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
