package com.bench.generator;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Thin wrapper around {@link XMLStreamWriter} that adds a newline + indentation before each
 * start/end tag, so generated sample XMLs are human-readable without any extra pretty-printing
 * pass. Only wraps the handful of methods {@link SampleXmlGenerator} actually calls.
 *
 * <p>An element that only ever holds text (a leaf) gets its closing tag right after the text,
 * with no extra whitespace -- only elements that contain child elements get their own indented
 * closing tag, tracked via a per-depth "had a child element" flag.</p>
 */
final class IndentingXmlWriter {

    private static final String INDENT_UNIT = "  ";

    private final XMLStreamWriter out;
    private final Deque<Boolean> hasChildElement = new ArrayDeque<>();
    private int depth = 0;

    IndentingXmlWriter(XMLStreamWriter out) {
        this.out = out;
    }

    void writeStartDocument(String encoding, String version) throws XMLStreamException {
        out.writeStartDocument(encoding, version);
    }

    void writeStartElement(String localName) throws XMLStreamException {
        if (!hasChildElement.isEmpty()) {
            hasChildElement.pop();
            hasChildElement.push(true); // this element now has at least one child element
        }
        if (depth > 0) {
            out.writeCharacters("\n" + INDENT_UNIT.repeat(depth));
        }
        out.writeStartElement(localName);
        hasChildElement.push(false);
        depth++;
    }

    void writeDefaultNamespace(String namespaceUri) throws XMLStreamException {
        out.writeDefaultNamespace(namespaceUri);
    }

    void writeAttribute(String localName, String value) throws XMLStreamException {
        out.writeAttribute(localName, value);
    }

    void writeCharacters(String text) throws XMLStreamException {
        out.writeCharacters(text);
    }

    void writeEndElement() throws XMLStreamException {
        depth--;
        boolean hadChildElement = hasChildElement.pop();
        if (hadChildElement) {
            out.writeCharacters("\n" + INDENT_UNIT.repeat(depth));
        }
        out.writeEndElement();
    }

    void writeEndDocument() throws XMLStreamException {
        out.writeEndDocument();
    }

    void flush() throws XMLStreamException {
        out.flush();
    }

    void close() throws XMLStreamException {
        out.close();
    }
}
