#!/usr/bin/env python3
"""
Turns the JMH JSON results (results/*.json) plus results/space.json and results/heap.json
into the 3 plain-text summary tables requested:
  1. Benchmark | Type | Size | Avg us | Msg/sec | Alloc KB/msg | GC count | GC time ms
  2. Type | Size | Input KB | POJO KB | Output KB
  3. Type | Peak heap MB

Usage: python scripts/summarize_results.py [results_dir]
"""
import json
import sys
import glob
import os
from collections import defaultdict

RESULTS_DIR = sys.argv[1] if len(sys.argv) > 1 else "results"

THROUGHPUT_TO_PER_SEC = {
    "ops/ns": 1e9, "ops/us": 1e6, "ops/ms": 1e3, "ops/s": 1.0, "ops/sec": 1.0, "ops/min": 1.0 / 60,
}
TIME_TO_MICROS = {
    "ns/op": 1e-3, "us/op": 1.0, "ms/op": 1e3, "s/op": 1e6,
}


def to_per_sec(score, unit):
    return score * THROUGHPUT_TO_PER_SEC.get(unit, 1.0)


def to_micros(score, unit):
    return score * TIME_TO_MICROS.get(unit, 1.0)


NON_JMH_RESULT_FILES = {"space.json", "heap.json", "sample_manifest.json"}


def load_jmh_entries(results_dir):
    entries = []
    for path in glob.glob(os.path.join(results_dir, "*.json")):
        name = os.path.basename(path)
        if name in NON_JMH_RESULT_FILES:
            continue
        with open(path) as fh:
            try:
                data = json.load(fh)
            except json.JSONDecodeError:
                continue
        if isinstance(data, list):
            # Only keep entries that actually look like JMH benchmark results, so any other
            # stray JSON file in results/ (e.g. a future report) doesn't break the summary.
            entries.extend(e for e in data if isinstance(e, dict) and "benchmark" in e and "mode" in e)
    return entries


def print_table(headers, rows, widths=None):
    if widths is None:
        widths = [max(len(str(h)), *(len(str(r[i])) for r in rows)) + 2 if rows else len(str(h)) + 2
                  for i, h in enumerate(headers)]
    line = "".join(str(h).ljust(w) for h, w in zip(headers, widths))
    print(line)
    print("-" * len(line))
    for r in rows:
        print("".join(str(c).ljust(w) for c, w in zip(r, widths)))
    print()


def main():
    entries = load_jmh_entries(RESULTS_DIR)
    if not entries:
        print(f"No JMH result JSON files found in {RESULTS_DIR}/ (looked for *.json, excluding space.json/heap.json)")
    rows = defaultdict(dict)
    for e in entries:
        bench = e["benchmark"].rsplit(".", 1)[-1]
        params = e.get("params", {})
        type_ = params.get("type", "?")
        size = params.get("size", "?")
        key = (bench, type_, size)
        mode = e["mode"]
        pm = e["primaryMetric"]
        sm = e.get("secondaryMetrics", {})
        if mode == "avgt":
            rows[key]["avg_us"] = to_micros(pm["score"], pm["scoreUnit"])
            if "gc.alloc.rate.norm" in sm:
                rows[key]["alloc_kb"] = sm["gc.alloc.rate.norm"]["score"] / 1024.0
            if "gc.count" in sm:
                rows[key]["gc_count"] = sm["gc.count"]["score"]
            if "gc.time" in sm:
                rows[key]["gc_time_ms"] = sm["gc.time"]["score"]
        elif mode == "thrpt":
            rows[key]["msg_per_sec"] = to_per_sec(pm["score"], pm["scoreUnit"])

    print("=== Benchmark summary ===\n")
    headers = ["Benchmark", "Type", "Size", "Avg us", "Msg/sec", "Alloc KB/msg", "GC count", "GC time ms"]
    table = []
    for (bench, type_, size) in sorted(rows):
        r = rows[(bench, type_, size)]
        table.append([
            bench, type_, size,
            f"{r.get('avg_us', float('nan')):.2f}",
            f"{r.get('msg_per_sec', float('nan')):.1f}",
            f"{r.get('alloc_kb', float('nan')):.2f}",
            f"{r.get('gc_count', float('nan')):.2f}",
            f"{r.get('gc_time_ms', float('nan')):.2f}",
        ])
    print_table(headers, table)

    space_path = os.path.join(RESULTS_DIR, "space.json")
    if os.path.exists(space_path):
        with open(space_path) as fh:
            space = json.load(fh)
        print("=== Space summary ===\n")
        headers = ["Type", "Size", "Input KB", "POJO KB", "Output KB"]
        table = [[s["type"], s["size"], f"{s['inputKB']:.2f}", f"{s['pojoKB']:.2f}", f"{s['outputKB']:.2f}"]
                 for s in space]
        print_table(headers, table)

    heap_path = os.path.join(RESULTS_DIR, "heap.json")
    if os.path.exists(heap_path):
        with open(heap_path) as fh:
            heap = json.load(fh)
        print("=== Peak heap summary ===\n")
        headers = ["Type", "Messages", "Peak heap MB"]
        table = [[h["type"], h["messages"], f"{h['peakHeapMB']:.2f}"] for h in heap]
        print_table(headers, table)

    gc_manual_path = os.path.join(RESULTS_DIR, "gc_manual.csv")
    if os.path.exists(gc_manual_path):
        import csv
        gc_rows = defaultdict(lambda: {"count_sum": 0.0, "time_sum": 0.0, "n": 0})
        with open(gc_manual_path, newline="") as fh:
            for row in csv.DictReader(fh):
                bench = row["benchmark"].rsplit(".", 1)[-1]
                key = (bench, row["type"], row["size"])
                gc_rows[key]["count_sum"] += float(row["gcCountDelta"])
                gc_rows[key]["time_sum"] += float(row["gcTimeMsDelta"])
                gc_rows[key]["n"] += 1
        print("=== Supplementary manual GC delta (GarbageCollectorMXBean, per iteration incl. warmup) ===")
        print("JVM-fork-level counters -- not exclusively attributable to one operation.\n")
        headers = ["Benchmark", "Type", "Size", "Iterations", "AvgGCcount/iter", "AvgGCtimeMs/iter"]
        table = []
        for (bench, type_, size), agg in sorted(gc_rows.items()):
            n = agg["n"]
            table.append([bench, type_, size, n, f"{agg['count_sum']/n:.3f}", f"{agg['time_sum']/n:.3f}"])
        print_table(headers, table)


if __name__ == "__main__":
    main()
