package com.bench.check;

import com.bench.stax.*;

import javax.xml.XMLConstants;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Function;

/**
 * For every generated sample XML: XML -&gt; POJO -&gt; XML, validates the regenerated XML
 * against its XSD, and deep-compares the two POJO graphs field by field. All must pass before
 * the JMH benchmarks are trusted.
 *
 * <p>Uses reflection only here, in the check tool -- never in the StAX reader/writer path that
 * is actually benchmarked.</p>
 */
public final class RoundTripCheck {

    private record TypeBinding(String typeKey, String xsdFileName, Function<byte[], Object> read,
                                Function<Object, byte[]> write) {
    }

    private static final List<TypeBinding> BINDINGS = List.of(
            new TypeBinding("capa_seev035", "SR_2025_Corporate_Action_CAPA_seev_035_001_16.xsd",
                    bytes -> unchecked(() -> CapaSeev035StaxReader.read(bytes)),
                    obj -> unchecked(() -> CapaSeev035StaxWriter.write((com.bench.capa.seev035.Document) obj))),
            new TypeBinding("capa_supl009", "SR_2025_Corporate_Action_CAPA_Extension_supl_009_001_11.xsd",
                    bytes -> unchecked(() -> CapaSupl009StaxReader.read(bytes)),
                    obj -> unchecked(() -> CapaSupl009StaxWriter.write((com.bench.capa.supl009.Document) obj))),
            new TypeBinding("caco_seev036", "SR_2025_Corporate_Action_CACO_seev_036_001_16.xsd",
                    bytes -> unchecked(() -> CacoSeev036StaxReader.read(bytes)),
                    obj -> unchecked(() -> CacoSeev036StaxWriter.write((com.bench.caco.seev036.Document) obj))),
            new TypeBinding("caco_supl011", "SR_2025_Corporate_Action_CACO_Extension_supl_011_001_11.xsd",
                    bytes -> unchecked(() -> CacoSupl011StaxReader.read(bytes)),
                    obj -> unchecked(() -> CacoSupl011StaxWriter.write((com.bench.caco.supl011.Document) obj)))
    );

    private interface ThrowingSupplier<T> {
        T get() throws Exception;
    }

    private static <T> T unchecked(ThrowingSupplier<T> supplier) {
        try {
            return supplier.get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) throws Exception {
        File xsdDir = new File("xsd");
        File samplesDir = new File("samples");
        SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

        int passed = 0, failed = 0;
        System.out.println("Type           Size     File                XsdValid  FieldsMatch  Result");
        System.out.println("----           ----     ----                --------  -----------  ------");

        for (TypeBinding binding : BINDINGS) {
            Schema schema = schemaFactory.newSchema(new File(xsdDir, binding.xsdFileName()));
            File typeDir = new File(samplesDir, binding.typeKey());
            for (File sizeDir : sortedDirs(typeDir)) {
                for (File file : sortedFiles(sizeDir)) {
                    byte[] original = Files.readAllBytes(file.toPath());

                    Object pojo1 = binding.read().apply(original);
                    byte[] regenerated = binding.write().apply(pojo1);
                    boolean xsdValid = validate(schema, regenerated);
                    Object pojo2 = binding.read().apply(regenerated);
                    boolean fieldsMatch = deepEquals(pojo1, pojo2);

                    boolean ok = xsdValid && fieldsMatch;
                    if (ok) passed++; else failed++;

                    System.out.printf("%-14s %-8s %-19s %-9s %-12s %s%n",
                            binding.typeKey(), sizeDir.getName(), file.getName(),
                            xsdValid ? "PASS" : "FAIL", fieldsMatch ? "PASS" : "FAIL", ok ? "PASS" : "FAIL");
                }
            }
        }

        System.out.println();
        System.out.println("Total passed: " + passed + ", failed: " + failed);
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static File[] sortedDirs(File dir) {
        File[] arr = dir.listFiles(File::isDirectory);
        if (arr == null) return new File[0];
        java.util.Arrays.sort(arr);
        return arr;
    }

    private static File[] sortedFiles(File dir) {
        File[] arr = dir.listFiles(File::isFile);
        if (arr == null) return new File[0];
        java.util.Arrays.sort(arr);
        return arr;
    }

    private static boolean validate(Schema schema, byte[] xml) {
        try {
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(new ByteArrayInputStream(xml)));
            return true;
        } catch (Exception e) {
            System.err.println("  xsd validation error: " + e.getMessage());
            return false;
        }
    }

    private static boolean deepEquals(Object a, Object b) {
        if (a == b) {
            return true;
        }
        if (a == null || b == null) {
            return false;
        }
        if (a instanceof List<?> la) {
            List<?> lb = (List<?>) b;
            if (la.size() != lb.size()) {
                return false;
            }
            for (int i = 0; i < la.size(); i++) {
                if (!deepEquals(la.get(i), lb.get(i))) {
                    return false;
                }
            }
            return true;
        }
        if (a instanceof BigDecimal da) {
            return b instanceof BigDecimal db && da.compareTo(db) == 0;
        }
        if (a instanceof XMLGregorianCalendar ca) {
            return b instanceof XMLGregorianCalendar cb && ca.toXMLFormat().equals(cb.toXMLFormat());
        }
        if (a instanceof String || a instanceof Boolean || a instanceof BigInteger || a.getClass().isEnum()) {
            return a.equals(b);
        }
        if (!a.getClass().getName().startsWith("com.bench.")) {
            return a.equals(b);
        }
        if (a.getClass() != b.getClass()) {
            return false;
        }
        try {
            for (Field f : a.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                if (!deepEquals(f.get(a), f.get(b))) {
                    System.err.println("  field mismatch: " + a.getClass().getSimpleName() + "." + f.getName());
                    return false;
                }
            }
            return true;
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
