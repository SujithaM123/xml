package com.bench.generator;

import com.sun.xml.xsom.*;
import com.sun.xml.xsom.parser.XSOMParser;

import javax.xml.stream.XMLOutputFactory;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.math.BigInteger;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

/**
 * Walks an XSD's own structure (via XSOM) and writes a schema-valid sample XML document for it.
 * Driven directly from the schema -- not from the xjc-generated POJOs -- so it also captures
 * facets (patterns, enumerations, lengths) that xjc does not preserve on the Java classes.
 */
public final class SampleXmlGenerator {

    private static final int MAX_DEPTH = 60;
    private static final XMLOutputFactory XML_OUTPUT_FACTORY = XMLOutputFactory.newFactory();

    private final MessageSpec spec;
    private final XSElementDecl rootElement;

    private int repeatFactor;
    private boolean includeOptionalScalars;
    private int unboundedAncestors;
    private int depth;
    private final Deque<String> typeStack = new ArrayDeque<>();
    private String currentHint = "";

    public SampleXmlGenerator(File xsdDirectory, MessageSpec spec) throws Exception {
        this.spec = spec;
        XSOMParser parser = new XSOMParser(javax.xml.parsers.SAXParserFactory.newInstance());
        parser.parse(new File(xsdDirectory, spec.xsdFileName()));
        XSSchemaSet schemaSet = parser.getResult();
        XSSchema schema = schemaSet.getSchema(spec.targetNamespace());
        this.rootElement = schema.getElementDecl(spec.rootElementLocalName());
        if (this.rootElement == null) {
            throw new IllegalStateException("Root element " + spec.rootElementLocalName()
                    + " not found in namespace " + spec.targetNamespace());
        }
    }

    /**
     * Generates one sample, adaptively tuning the repeat factor to land near the tier's target
     * size. Growth per nesting level is damped (see {@link #writeParticle}), so output size is
     * NOT linear in the repeat factor -- a flat sqrt(ratio) correction either stalls (correcting
     * too little, as seen on "medium") or overshoots into an OutOfMemoryError (correcting too
     * much, as seen on "xlarge"). Instead this fits an empirical power law
     * {@code size ~= C * factor^e} from the last two (factor, size) data points and solves for
     * the factor that should hit the target, clamped to at most 4x growth/shrink per attempt so
     * a bad extrapolation can't runaway into an OOM.
     */
    public byte[] generateForTier(SizeTier tier, Random rnd) throws Exception {
        int factor = Math.max(1, tier.initialRepeatFactor);
        byte[] best = null;
        long bestDiff = Long.MAX_VALUE;
        int prevFactor = -1;
        long prevSize = -1;

        for (int attempt = 0; attempt < 14; attempt++) {
            byte[] xml = generateOnce(factor, tier.includeOptionalScalars, rnd);
            long size = xml.length;
            long diff = Math.abs(size - tier.targetBytes);
            if (diff < bestDiff) {
                bestDiff = diff;
                best = xml;
            }

            boolean closeEnough = size >= tier.targetBytes * 0.7 && size <= tier.targetBytes * 1.4;
            if (closeEnough) {
                break;
            }
            if (factor <= 1 && size > tier.targetBytes) {
                break; // already minimal and still over target: can't shrink further
            }
            if (factor >= 2_000_000 && size < tier.targetBytes) {
                break; // hit the hard safety cap, structurally can't grow more
            }

            int nextFactor;
            if (prevFactor > 0 && prevFactor != factor && prevSize > 0 && prevSize != size) {
                double exponent = Math.log((double) size / prevSize) / Math.log((double) factor / prevFactor);
                if (exponent > 0.05) {
                    double ratio = (double) tier.targetBytes / size;
                    nextFactor = (int) Math.ceil(factor * Math.pow(ratio, 1.0 / exponent));
                } else {
                    nextFactor = factor * 4; // growth has stalled; force a bigger jump
                }
            } else if (size > tier.targetBytes) {
                // No empirical exponent yet, but already over target: halving is always safe
                // (shrinking can never OOM).
                nextFactor = Math.max(1, factor / 2);
            } else {
                // No empirical exponent yet and under target: nested unbounded lists can make
                // growth super-linear (two 3-deep unbounded lists compound to ~factor^3), so a
                // ratio-based guess here can overshoot by orders of magnitude and exhaust the
                // heap before a second, well-calibrated data point is ever collected. Take one
                // safe, fixed small step instead; every later step uses the real measured
                // exponent from two actual data points.
                nextFactor = factor * 2;
            }

            // Safety clamp #1: never grow/shrink by more than 4x in one attempt.
            int maxGrow = (int) Math.min(2_000_000L, (long) factor * 4);
            int minShrink = Math.max(1, factor / 4);
            nextFactor = Math.max(minShrink, Math.min(nextFactor, maxGrow));
            nextFactor = Math.max(1, Math.min(nextFactor, 2_000_000));
            if (nextFactor == factor) {
                nextFactor = Math.min(maxGrow, factor + 1);
            }

            // Safety clamp #2: nested unbounded lists compound multiplicatively (N levels deep
            // gives output ~ factor^N even after per-level damping, since damping only shrinks
            // the constant, not the exponent), so growth can be strongly super-linear. Project
            // the NEXT attempt's size pessimistically (exponent 6, comfortably above any
            // realistic nesting depth in these schemas) and clamp nextFactor so that even the
            // pessimistic projection stays under a hard absolute ceiling -- this is what
            // actually prevents a single attempt from exhausting the heap, independent of
            // whether the primary formula's fitted exponent happens to be right.
            final double hardCeilingBytes = 50_000_000.0; // no sample ever legitimately needs more than this
            final double pessimisticExponent = 6.0;
            if (size > 0 && nextFactor > factor) {
                double growthRatio = (double) nextFactor / factor;
                double pessimisticProjection = size * Math.pow(growthRatio, pessimisticExponent);
                if (pessimisticProjection > hardCeilingBytes) {
                    double allowedGrowthRatio = Math.pow(hardCeilingBytes / size, 1.0 / pessimisticExponent);
                    nextFactor = Math.max(factor, (int) Math.floor(factor * allowedGrowthRatio));
                }
            }

            prevFactor = factor;
            prevSize = size;
            factor = nextFactor;
        }
        return best;
    }

    private byte[] generateOnce(int factor, boolean includeOptionalScalars, Random rnd) throws Exception {
        this.repeatFactor = factor;
        this.includeOptionalScalars = includeOptionalScalars;
        this.unboundedAncestors = 0;
        this.depth = 0;
        this.typeStack.clear();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        IndentingXmlWriter w = new IndentingXmlWriter(XML_OUTPUT_FACTORY.createXMLStreamWriter(out, "UTF-8"));
        w.writeStartDocument("UTF-8", "1.0");
        w.writeStartElement(spec.rootElementLocalName());
        w.writeDefaultNamespace(spec.targetNamespace());
        writeTypeContent(w, rootElement.getType(), rnd);
        w.writeEndElement();
        w.writeEndDocument();
        w.flush();
        w.close();
        return out.toByteArray();
    }

    private void writeTypeContent(IndentingXmlWriter w, XSType type, Random rnd) throws Exception {
        if (depth > MAX_DEPTH) {
            return;
        }
        if (type.isSimpleType()) {
            w.writeCharacters(LeafValueFactory.generate(type.asSimpleType(), currentHint, rnd));
            return;
        }
        XSComplexType ct = type.asComplexType();
        for (XSAttributeUse au : ct.getAttributeUses()) {
            XSAttributeDecl decl = au.getDecl();
            w.writeAttribute(decl.getName(), LeafValueFactory.generate(decl.getType(), decl.getName(), rnd));
        }
        XSContentType content = ct.getContentType();
        XSSimpleType simpleContent = content.asSimpleType();
        if (simpleContent != null) {
            w.writeCharacters(LeafValueFactory.generate(simpleContent, currentHint, rnd));
            return;
        }
        XSParticle particle = content.asParticle();
        if (particle != null) {
            String typeName = type.getName();
            boolean pushed = typeName != null && !typeStack.contains(typeName);
            if (typeName != null) {
                if (!pushed) {
                    return; // recursion guard: this complex type is already an ancestor, stop descending
                }
                typeStack.push(typeName);
            }
            depth++;
            try {
                writeParticle(w, particle, rnd);
            } finally {
                depth--;
                if (pushed) {
                    typeStack.pop();
                }
            }
        }
    }

    private void writeParticle(IndentingXmlWriter w, XSParticle particle, Random rnd) throws Exception {
        int min = particle.getMinOccurs().intValue();
        BigInteger maxBig = particle.getMaxOccurs();
        boolean unbounded = maxBig.intValue() == XSParticle.UNBOUNDED;
        int max = unbounded ? Integer.MAX_VALUE : maxBig.intValue();

        int count;
        boolean repeating = max > 1;
        if (!repeating) {
            count = (min > 0 || includeOptionalScalars) ? 1 : 0;
        } else if (min == 0 && !includeOptionalScalars) {
            count = 0;
        } else {
            int effectiveFactor = Math.max(1, repeatFactor >> unboundedAncestors);
            count = Math.max(min, Math.min(max, effectiveFactor));
            count = Math.max(count, 1);
        }

        if (repeating) {
            unboundedAncestors++;
        }
        try {
            for (int i = 0; i < count; i++) {
                writeTerm(w, particle.getTerm(), rnd);
            }
        } finally {
            if (repeating) {
                unboundedAncestors--;
            }
        }
    }

    private void writeTerm(IndentingXmlWriter w, XSTerm term, Random rnd) throws Exception {
        if (term.isModelGroup()) {
            XSModelGroup mg = term.asModelGroup();
            if (mg.getCompositor() == XSModelGroup.Compositor.CHOICE) {
                XSParticle[] children = mg.getChildren();
                if (children.length > 0) {
                    writeParticle(w, children[0], rnd);
                }
            } else {
                for (XSParticle child : mg.getChildren()) {
                    writeParticle(w, child, rnd);
                }
            }
        } else if (term.isElementDecl()) {
            XSElementDecl decl = term.asElementDecl();
            String savedHint = currentHint;
            currentHint = decl.getName();
            w.writeStartElement(decl.getName());
            writeTypeContent(w, decl.getType(), rnd);
            w.writeEndElement();
            currentHint = savedHint;
        } else if (term.isWildcard()) {
            w.writeStartElement("SplmtryInfo");
            w.writeCharacters(LeafValueFactory.wildcardText(rnd));
            w.writeEndElement();
        }
    }
}
